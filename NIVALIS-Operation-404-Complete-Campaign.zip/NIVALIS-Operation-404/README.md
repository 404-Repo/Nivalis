# NIVALIS: OPERATION 404

Beyond the last transmission, the compound is still listening. Descend beneath the ice. Find what keeps it awake.

A three-chapter first-person journey through a frozen machine outpost, a buried control station, and the consequence of shutting it down. Stealth, environmental puzzles and a final confrontation unfold as one continuous operation.

1. **COMPOUND / INFILTRATE** — sever the surveillance uplinks and descend in the service lift. An unspotted, no-kill run remains possible.
2. **LOWER STATION / SUBSURFACE** — restore auxiliary power and shut down the command core. The shutdown destroys the remaining patrols and activates Warden's independent failsafe.
3. **WARDEN / RECKONING** — emerge at the same service lift and defeat the three-phase boss.

The campaign has one cinematic black title, automatic lift handoffs, one final completion, shared settings and shared mementos.

## Play

Open **PLAY.html** in a current desktop browser with WebGL enabled. It embeds the complete campaign, including all three chapters, fonts, geometry and sound synthesis. It makes no runtime asset requests. A local HTTP server is the most reliable option if a browser restricts local HTML, pointer capture or saved progress.

Sound is enabled by default. The main title and all three pause screens share a sustained cassette-textured drone without arpeggios. If a browser blocks autoplay, the first click, tap or key press starts audio automatically. The menu drone fades out when play resumes and respects the shared mute and score-volume settings.

With Node.js installed, run `node tools/serve.mjs` and open `http://localhost:8080/`. No package installation is needed. You can choose a different port: `node tools/serve.mjs 8085`.

## Upload

For a lean upload, use the **contents of dist/** on any static website host. Its `index.html` is the entry point. You can also upload the complete extracted delivery folder: the root `index.html` loads its chapters from the included `dist/` folder. `/game/` in the lean upload redirects to the campaign entry point for compatibility. There is no server, account system, API key or external asset dependency. The local Sites hosting identity is deliberately excluded from the delivery ZIP.

## Progress

START begins on HARD. CONTINUE returns to the beginning of the most recently reached chapter. Checkpoints are written when a chapter is completed; restarting or dying retries the current chapter. Health, ammunition and chapter objectives reset to their authored defaults at each chapter boundary. Mementos and accessibility/audio settings persist across chapters and new operations.

Progress lives in the browser on the current origin. It does not synchronize between devices, browsers, the offline file and hosted copies. If browser storage is unavailable, the campaign still works with progress held for the current session.

## Edit and rebuild

- `index.html`, `style.css`: main title, campaign dialogs, travel captions and final completion.
- `campaign.js`: scene lifecycle, transitions, inputs and shared preferences.
- `campaign-state.js`: checkpoint validation and ordered campaign progression.
- `title-audio.js`: sustained title drone, tape coloration, and audio lifecycle.
- `chapters/compound`, `chapters/lower`, `chapters/warden`: editable chapter source, assets, engine modules and original licenses.
- `chapters/*/engine/campaign-bridge.js`: narrow adapter between each chapter and the campaign shell.

Run `python3 tools/build.py` after source changes. This recreates `dist/` and `PLAY.html` using the Python standard library. Each chapter keeps a separate ES-module and WebGL context. Only the active chapter's scene/audio graph is alive; the previous context is explicitly disposed on transition. The next chapter's embedded document is prefetched during lift travel. Source scenes retain their existing materials, lighting, sounds, combat and puzzle logic.

## Checks

```
node tools/check-campaign.mjs
node tools/check-menu-audio.mjs
node chapters/compound/tools/check-lift.mjs --compound-route --compound-combat --access-alert
node chapters/lower/tools/check.mjs
node chapters/warden/tools/check-warden.mjs
```

See `QA.md` for integration coverage and limitations. The local-only `development/campaign-review.html` fixture stages the first lift and final victory, then walks the complete basement using normal movement/puzzle inputs. It is excluded from the playable website and delivery ZIP.

## Credits

Three.js r140, local title and bunker fonts, and their licenses are retained under each chapter's `vendor/` and `THIRD_PARTY_NOTICES.txt`. The soundtrack and effects are synthesized locally. The campaign retains its existing approved level assets; the main title uses typography on pure black.

## Release privacy

Build and packaging commands scan the release inputs and embedded code for known credential patterns, local home paths, machine email addresses, retired hosting URLs and private configuration files. ZIP comments and extra metadata are rejected. Packaging validates a temporary ZIP before replacing the existing delivery. Licenses and third-party credits remain intact.

Run `python3 tools/test_privacy.py` to exercise the guard. The rules are deliberately focused and complement GitHub secret scanning; they do not guarantee that every possible secret or identifying detail can be detected.

For this repository's maintainer, `.privacy-policy.json` lists the approved public commit identity. Future maintainers should set their own public name and GitHub private email in that policy and local Git configuration. To enable the local check before Git uploads a push, run `git config --local core.hooksPath .githooks`. It inspects the outgoing commits and archives; Git hooks must be enabled separately in every clone. Existing remote history is not rewritten by these checks.

The combined campaign owns chapter progression. Isolated chapter source pages replay locally when completed and no longer redirect to retired deployments.
