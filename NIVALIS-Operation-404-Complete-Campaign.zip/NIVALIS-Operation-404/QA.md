# Campaign delivery checks — 18 September 2026

## Automated checks

- Campaign ordering, duplicate and out-of-order completion protection, chapter checkpoint serialization, invalid/corrupt save rejection, completed-run state and bounded shared settings passed.
- All JavaScript parses successfully. All three embedded ES-module graphs resolve their local imports. Portable PLAY.html has no external script, stylesheet or font dependency.
- Compound: original layout, service lift geometry, ladder, aiming, drone responses, witnessed/unseen takedowns, persistent alerts and restart passed. The input-driven Hard route completed in 117.1 simulated seconds with three uplinks, eight surviving patrols, zero shots, zero alerts and Ghost status.
- Lower Station: grounded assets, recoverable overloads, both prerequisite orders, optional hints, circuit solution, one-shot shutdown cue ordering, smooth warning lights, reduced flashing and reset passed.
- Warden: the 229 compound colliders and retained world assets match the approved baseline. All three phases, repair interruption, grounded gold beam, telegraphed sweep/strike alternation, cover, reinforcements, arrival lift and restart passed. The input-driven Hard fight completed in 53.6 simulated seconds with 45 core hits and two reloads; death/restart checks also passed.
- Continuity verification only normalizes the explicit campaign storage adapter in `human_traces.js`; it still checks the underlying world source against the standalone baseline.

## Browser integration checks

Tested in the Codex in-app Chromium browser using the local static build and the embedded PLAY.html served over localhost:

- Original campaign handoff checks used the live 3D main title; no individual chapter title flash. The final delivery replaces the main title with the approved opaque black VOID design.
- START, death/TRY AGAIN, chapter pause, common settings and MAIN TITLE navigation.
- Actual Compound lift closing/descent triggered the campaign handoff and a Chapter 02 checkpoint. For this transition test only, the player and completed uplinks were staged at the lift; the separate full Compound route above uses movement/interactions.
- Complete Lower Station route used normal movement and puzzle inputs: terminal gate, cartridge, overload/recovery, crew note, optional hints, invalid routing, valid shutdown, pause/resume during shutdown, ordered patrol destruction/Warden alarm, and the return lift. It arrived automatically in Warden with a Chapter 03 checkpoint, no intermediate end/title screen and one active chapter iframe.
- A staged Warden victory displayed the single final campaign completion. The summary retained reports from all three chapters. Actual boss combat is covered by the input-driven simulation above.
- Portable build loaded all three chapters. CONTINUE after a page reload opened Lower Station and Warden at their authored starts. Shared mute, reduced flashing and reduced camera motion persisted and applied to the basement and Warden.
- Simulated an incomplete chapter document in the portable QA fixture: a recoverable error retained the checkpoint; restoring the document and choosing RETRY CHAPTER correctly entered Lower Station.
- Old chapter render loops are stopped and audio contexts explicitly closed at handoff. A fresh iframe owns the next chapter. A brief synthesized travel bed bridges scene initialization.

## Scope and limits

Final delivery changes: the one-sided MAINTENANCE / OVERRIDE shelf sign was removed from Lower Station. The approved black title and sustained cassette drone are included in both the static build and embedded PLAY.html. The title score has fixed voice pools and no arpeggiator, observes shared mute/score settings, and fades to a suspended context when play begins. Campaign and Lower Station checks were rerun after these changes.

Title/pause audio browser checks: sound is enabled by default, with an immediate autoplay attempt and input fallback where browser policy requires activation. Compound, Lower Station and Warden each passed title playback, entering play, pause music, shared mute/unmute, zero/restored score volume, resume, repeat pause and return to title. The chapter score suspends while the same cassette drone plays, with a fixed 17-source pool. The menu drone suspends again during gameplay. Test checkpoints and settings are restored afterward; the fixture is excluded from delivery.

Audio lifecycle regression checks passed: a delayed browser autoplay approval cannot restart menu music after START or mute; rapid pause/resume cannot leave an obsolete suspension scheduled; out-of-order autoplay requests respect the latest score volume.

Progress is at chapter boundaries, not an in-room or mid-fight quick save. It is local to the browser/origin. Health and ammunition retain each chapter's original starting values. Existing standalone progress is not imported or overwritten.

This pass does not claim a fresh uninterrupted manual playthrough of every chapter, or a complete real-device mobile/browser compatibility matrix. Direct `file://` launching was not automated; the same self-contained PLAY.html was checked over HTTP and its embedded resource graph validated. If a browser restricts local HTML, use the included static server or upload `dist/`.

The development fixture and its staging controls are excluded from `dist/` and the delivery ZIP. The original three standalone directories, deployments and delivery ZIPs were not modified.

## Trackpad/campaign input correction — 18 September 2026

The return lift intentionally releases pointer capture. The campaign now requests capture again when the next chapter starts, with no-click mouse/trackpad look inside the scene if the browser refuses capture. A click retries capture. The campaign owns capture and focus transitions, so child documents no longer interpret the parent's capture as a lost game window. Forwarded keyboard events target the active chapter element rather than its Document.

Outdoor HUD visibility now changes synchronously with pause/resume, and unchanged labels retain their text nodes instead of being recreated at every HUD tick. No lighting, combat difficulty, world layout or saved checkpoint format changed.

Browser regression checks passed for Compound, Lower Station and Warden: browser-denied capture, movement with no held mouse button, pause/resume, inactive camera while paused, stable HUD visibility, unchanged objective text, child capture/focus notifications and the Q aiming alternative. A staged return-lift release/completion exercised the real campaign loading handoff to Warden; camera movement worked immediately without clicking. Warden checks also passed in embedded PLAY.html. These are event-driven browser checks, not a physical Mac trackpad hardware test. The in-app browser rejected native capture during QA, so captured movement remains covered by the existing adapter/input tests rather than a claimed new native-capture device test.

Campaign/module validation, menu-audio lifecycle checks, the full simulated Hard Warden fight, Compound movement/combat/stealth route checks and Lower Station mission/lighting checks passed after the input changes.

## Release privacy safeguards — 20 September 2026

Removed retired deployment URLs from chapter fallback actions and baseline metadata. Normal campaign transitions continue through the existing campaign adapter. Added build/package privacy checks, an opt-in pre-push check of exact outgoing Git objects, and regression tests for synthetic credentials, local paths, machine emails, encoded modules, nested chapter payloads, private filenames, ZIP metadata, identity overrides and unsafe intermediate commits. Detected values are not printed. These checks complement repository secret scanning and do not claim exhaustive detection.
