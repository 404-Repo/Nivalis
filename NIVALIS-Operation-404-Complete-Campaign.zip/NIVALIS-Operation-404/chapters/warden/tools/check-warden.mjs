import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {WardenState} from '../engine/warden-state.js';
process.chdir(fileURLToPath(new URL('..',import.meta.url)));
const baseline=JSON.parse(fs.readFileSync('chapter-03-baseline.json'));
const continuity=JSON.parse(fs.readFileSync('docs/continuity-source.json'));
const hash=s=>createHash('sha256').update(s).digest('hex');
const withoutCampaignStorage=text=>text.replace("import {campaign} from './campaign-bridge.js';\n",'').replaceAll('nivalis.campaign.mementos.v1','nivalis9.achievements.v1').replace("(campaign.enabled?campaign.mementos():JSON.parse(localStorage.getItem(HUMAN_ACHIEVEMENT_KEY)||'{}'))","JSON.parse(localStorage.getItem(HUMAN_ACHIEVEMENT_KEY)||'{}')").replace("if(campaign.enabled)campaign.mementos({version:1,unlocked:records});else ",'');
for(const [file,sha] of Object.entries(baseline.source_files)) {
  if(file.startsWith('assets/')||['engine/environment.js','engine/human_traces.js','engine/grounding.js','engine/surfaces.js','engine/security.js'].includes(file)) assert.equal(hash(file==='engine/environment.js'?fs.readFileSync(file,'utf8').replace('sun,tracks,mist,fog:scene.fog,fogProfiles,snow,sky,hemi,','sun,tracks,mist,fog:scene.fog,fogProfiles,'):file==='engine/human_traces.js'?withoutCampaignStorage(fs.readFileSync(file,'utf8')):fs.readFileSync(file)),continuity.shared_files[file]||sha,`Original world changed: ${file}`);
}
const originalLevel=fs.readFileSync('engine/level.js','utf8')
  .replace('buildLevel(scene,onProgress=()=>{},{wardenEncounter=false}={})','buildLevel(scene,onProgress=()=>{})')
  .replace("const aircraft=wardenEncounter?null:prop('heavy_drone',0,-13,{y:padY,rot:heading});","const aircraft=prop('heavy_drone',0,-13,{y:padY,rot:heading});")
  .replace('=>{if(wardenEncounter)return;const[wx,wz]=toDrone(x,z);return box','=>{const[wx,wz]=toDrone(x,z);return box')
  .replace('if(aircraft)aircraft.add(id);','aircraft.add(id);')
  .replace("aircraft:'heavy_drone',parked:!wardenEncounter","aircraft:'heavy_drone',parked:true");
assert.equal(hash(originalLevel),continuity.level1_layout_sha256,'Compound differs from the approved level-one layout beyond moving the parked aircraft');
for(const [file,sha] of Object.entries({...continuity.shared_files,...continuity.preserved_warden_files}))assert.equal(hash(file==='engine/human_traces.js'?withoutCampaignStorage(fs.readFileSync(file,'utf8')):fs.readFileSync(file)),sha,`Continuity drift: ${file}`);
const normalizedStorm=fs.readFileSync('engine/warden-storm.js','utf8').replace("    // Painted markings use a faint emissive map for readability, not a lamp.\n    if(object.name.startsWith('interior-spray-paint-'))return;\n",'');
assert.equal(hash(normalizedStorm),continuity.warden_storm_baseline_sha256);
const normalizedLift=fs.readFileSync('engine/service-lift.js','utf8').replace('let reducedFlicker=matchMedia','const reducedFlicker=matchMedia').replace('setReducedFlashing(value){reducedFlicker=!!value;updateLight(0);},','').replace('reset,parkOpen,','reset,').replace(/ \/\/ Chapter 03 arrival:[^\n]*\n function parkOpen\(\)\{[^\n]*\n/,'');
assert.equal(hash(normalizedLift),continuity.level1_lift_sha256,'The approved lift geometry must match level one');
console.log('PASS: updated level-one compound and assets match; shared heavy-drone model, scenery, storm, phase thresholds and score preserved.');

const r=new WardenState();r.hit(Infinity);r.hit(-10);assert.equal(r.health,3000);
r.hit(100000);assert.equal(r.phase,2);assert.equal(r.health,1950);assert(r.beginRepair());assert(!r.beginRepair());
r.update(100);assert.equal(r.healed,300);assert.equal(r.health,2250);assert.equal(r.phase,2);assert(!r.repairing);
r.hit(100000);assert.equal(r.phase,3);assert.equal(r.health,900);assert(!r.beginRepair());r.hit(100000);assert(r.defeated);
r.reset();r.hit(1050);r.beginRepair();r.update(1);for(let i=0;i<3;i++)r.hit(60,true);assert(r.interrupted);const interrupted=r.health;r.update(100);assert.equal(r.health,interrupted);r.reset();assert.equal(r.healed,0);assert.equal(r.phase,1);
console.log('PASS: phase thresholds, capped repairs, interruption, victory and reset.');

const ctx={exports:{},module:{exports:{}},console};vm.runInNewContext(fs.readFileSync('vendor/three.min.js','utf8'),ctx);globalThis.THREE=ctx.exports;
const gradient={addColorStop(){}};
const drawing=new Proxy({measureText:t=>({width:String(t).length*8}),createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),createLinearGradient:()=>gradient,createRadialGradient:()=>gradient},{get:(o,k)=>k in o?o[k]:()=>{}});
globalThis.document={baseURI:new URL('../',import.meta.url).href,createElement:()=>({width:256,height:256,getContext:()=>drawing})};
globalThis.window={__NIVALIS_SURFACE_PILOT__:false};
const {buildLevel}=await import('../engine/level.js');
const original=await buildLevel(new THREE.Scene());
const scene=new THREE.Scene(),level=await buildLevel(scene,()=>{},{wardenEncounter:true});
const clean=a=>JSON.parse(JSON.stringify(a,(key,value)=>key==='textureUUID'?undefined:value));
assert.deepEqual(clean(level.colliders),clean(original.colliders.filter(c=>!c.type.startsWith('parked-drone'))));
for(const key of ['surfaces','ramps','spawn','bounds','mapShapes','containerLabels','naturalFeatures'])assert.deepEqual(clean(level[key]),clean(original[key]),`Layout mismatch: ${key}`);
assert.deepEqual(level.terminals.map(t=>[t.id,t.x,t.y,t.z]),original.terminals.map(t=>[t.id,t.x,t.y,t.z]));
assert.equal(level.extraction.x,original.extraction.x);assert.equal(level.extraction.z,original.extraction.z);
console.log(`PASS: ${level.colliders.length} unchanged compound colliders, all floors, routes and objectives.`);

const {makeWarden}=await import('../engine/warden.js');
let blocked=false,supportY=0,shots=[],escorts=0,victories=0;
const noop=()=>{};
const boss=await makeWarden(scene,level,{wallDistance:(_o,_d,max)=>blocked?0:max,floorAt:()=>supportY,fire:(a,b,opts)=>shots.push({a,b,opts}),escorts:()=>escorts++,notify:noop,audio:{alarm:noop,tone:noop,kill:noop},onDefeat:()=>victories++});
assert.equal(boss.wreckage.sites.length,8);
for(let site=0;site<8;site++){
  const parts=boss.wreckage.fragments.filter(f=>f.site===site);
  assert.equal(parts.filter(f=>f.kind.startsWith('rotor')).length,4,'Each wreck must have four detached rotors');
  assert(parts.length>=12,'Each wreck must visibly break into multiple parts');
  for(const f of parts){assert(Math.abs(f.minY-f.floor-.002)<.0001,`Floating wreck fragment: ${site}/${f.kind}`);assert(f.maxY-f.floor<1,'Wreckage stays low to its support surface');}
  assert(Math.max(...parts.map(f=>f.z))-Math.min(...parts.map(f=>f.z))>2,'Debris must be scattered');
  if(site===3||site===4)for(const f of parts)assert.equal(f.floor,3.27,'Elevated debris rests on the actual deck');
}
boss.wreckage.group.traverse(m=>{if(m.material?.emissive)assert.equal(m.material.emissive.getHex(),0,'Destroyed drone optics must be dark');});
assert(level.prototypes.drone.children.some(m=>m.material?.emissive?.getHex()>0),'Wreckage must not alter the live drone materials');
console.log(`PASS: eight scattered wrecks, ${boss.wreckage.fragments.length} grounded fragments, dark optics and preserved live drones.`);
const player={x:4,y:0,z:38,height:1.78},state={mode:'combat',difficulty:'tactical'};
const tick=seconds=>{for(let i=0;i<Math.round(seconds*60);i++)boss.update(1/60,player,state);};
boss.start();tick(11.5);assert.equal(shots.length,0,'Launch must provide grace time');assert(!boss.status().acquired,'Reveal never acquires the player');assert(Math.abs(boss.rig.position.x+11)<.01,'Reveal crosses beside the relay mast');
const beam=scene.getObjectByName('Warden targeting beam'),tube=scene.getObjectByName('Warden targeting beam volume');
for(let i=0;i<900&&!beam.visible;i++)boss.update(1/60,player,state);
assert(beam.visible&&tube.visible,'The aiming warning must render');
for(const [height,floor] of [[0,0],[3.27,3.27],[4.6,3.27]]){
 player.y=height;supportY=floor;tick(1/60);
 const p=beam.geometry.attributes.position,end=new THREE.Vector3().fromBufferAttribute(p,1),origin=new THREE.Vector3().fromBufferAttribute(p,0);
 assert(Math.abs(end.y-floor-.025)<.00001,'Beam reaches the supporting floor on ground, decks and jumps');
 tube.updateMatrixWorld(true);const tubeEnd=tube.localToWorld(new THREE.Vector3(0,.5,0));
 assert(tubeEnd.distanceTo(end)<.0001,'Gold volume must reach the same endpoint as its line');
 assert(Math.abs(tube.scale.y-origin.distanceTo(end))<.0001,'Beam must not have a shortened gap');
}
blocked=true;tick(1/60);assert(!beam.visible&&!tube.visible,'Cover cancels both beam layers');
blocked=false;player.y=supportY=0;tick(6);assert(shots.length>0,'WARDEN must attack visible players');
console.log('PASS: gold warning reaches ground and raised floors, stays grounded during jumps, and cancels behind cover.');
boss.reset();boss.start();shots=[];blocked=true;tick(25);assert.equal(shots.length,0,'Solid shelter blocks acquisition');blocked=false;
boss.rules.hit(1050);tick(5);assert.equal(escorts,1,'Exactly one pair of escorts');assert(boss.rules.repairing);tick(15);assert.equal(boss.rules.healed,300);assert.equal(escorts,1);assert.equal(boss.rules.phase,2);
boss.rules.hit(100000);tick(20);assert.equal(boss.rules.phase,3);assert(shots.some(s=>s.opts.splash===3),'Overload must launch marked ground strikes');
boss.rules.health=8;boss.hit({weak:false});assert.equal(victories,1);assert(boss.status().defeated);const stopped=shots.length;tick(10);assert.equal(shots.length,stopped);boss.hit({weak:true});assert.equal(victories,1);
boss.reset();boss.start();state.mode='recon';shots=[];tick(25);assert.equal(shots.length,0,'Recon must not fire');
console.log('PASS: live controller launch, cover, reinforcements, strikes, defeat and recon.');

// Attack contract: a fixed, floor-aligned lane, a full warning, then a bounded
// traverse. Cover is rechecked for every shot, including cover entered late.
state.mode='combat';
function reachSweep(){boss.start();blocked=false;shots=[];player.x=4;player.z=38;tick(12.1);boss.rules.hit(100000);boss.rules.hit(100000);for(let i=0;i<1200&&boss.status().mode!=='sweep-aim';i++)tick(1/60);assert.equal(boss.status().mode,'sweep-aim');}
reachSweep();const lane=boss.status().sweepTargets;assert.equal(lane.length,9);assert.equal(shots.length,0);
player.z+=7;tick(2.6);assert.equal(shots.length,0,'Sweep gives 2.8 seconds before damage');assert.deepEqual(boss.status().sweepTargets,lane,'Lane must not follow an escaping player');
tick(3.5);assert.equal(shots.length,9);shots.forEach((shot,i)=>{assert.deepEqual(shot.b.toArray(),lane[i]);assert.equal(shot.opts.splash,1.35);assert.equal(shot.opts.damage,32);});
tick(12);assert(shots.some(s=>s.opts.splash===3),'The next overload attack is a ground strike');
reachSweep();blocked=true;tick(7);assert.equal(shots.length,0,'Cover entered after marking blocks every sweep shot');blocked=false;
boss.reset();assert(!scene.getObjectByName('Warden sweep lane').visible,'Restart clears the lane');
console.log('PASS: committed nine-shot sweep, full warning, escape, late cover, strike alternation and reset.');

// Run the audio scheduler against a monotonic audio clock, including rapid
// phase changes. Validate automation timing without depending on audio hardware.
const param=()=>({value:0,setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){},setTargetAtTime(){},cancelScheduledValues(){},cancelAndHoldAtTime(){},setValueCurveAtTime(){}});
const node=()=>({gain:param(),frequency:param(),Q:param(),delayTime:param(),pan:param(),threshold:param(),knee:param(),ratio:param(),attack:param(),release:param(),connect(){},disconnect(){},start(){},stop(){},setPeriodicWave(){}});
const audioCtx={currentTime:0,sampleRate:44100,destination:node(),createGain:node,createBiquadFilter:node,createOscillator:node,createBufferSource:node,createStereoPanner:node,createDelay:node,createConvolver:node,createDynamicsCompressor:node,createPeriodicWave:()=>({}),createBuffer:(_c,len)=>({getChannelData:()=>new Float32Array(len)})};
const {WardenCombatScore}=await import('../engine/warden-score.js');const score=new WardenCombatScore(audioCtx,node());const sourceCount=score.sources.length;
for(const phase of [1,2,3,0,1]){score.setBossPhase(phase);assert.equal(score.bpm,[80,128,140,152][phase]);for(let i=0;i<100;i++){audioCtx.currentTime+=.1;score.update({tension:.8},audioCtx.currentTime);}for(const a of score.arps){assert(a.played>0);assert.equal(a.skipped,0);assert(Number.isFinite(score.nextTime));assert(score.nextTime>=audioCtx.currentTime);assert.equal(score.sources.length,sourceCount);}}
const {WardenAudio}=await import('../engine/warden-audio.js');const spatial=new WardenAudio(audioCtx,node());for(const phase of [1,2,3,0]){spatial.update({boss:{position:[12,15,-10],phase,rotorPower:phase?1:0},listener:{x:0,y:0,z:0,yaw:0},occluded:phase===2});for(const kind of ['aim','strike','sweep']){spatial.cue(kind,2.8);spatial.cancel();}assert.equal(spatial.sources.length,8);}spatial.dispose();
score.dispose();console.log('PASS: 128 / 140 / 152 BPM, fixed voice pools, release and replay.');

// Exercise the real main-loop actions with a headless DOM/renderer. Geometry,
// collisions, health, mission interactions and restart logic remain real.
class Element {
 constructor(){this.handlers=new Map();this.style={};this.value='';this.children=[];this.width=650;this.height=650;this.parentElement={clientWidth:500};const classes=new Set();this.classList={add:(...s)=>s.forEach(x=>classes.add(x)),remove:(...s)=>s.forEach(x=>classes.delete(x)),contains:s=>classes.has(s),toggle:(s,on)=>{on??=!classes.has(s);on?classes.add(s):classes.delete(s);}};}
 getContext(){return drawing;} addEventListener(type,handler){if(!this.handlers.has(type))this.handlers.set(type,[]);this.handlers.get(type).push(handler);} closest(){return null;} appendChild(e){this.children.push(e);} querySelector(){return new Element();} querySelectorAll(){return [];} setAttribute(){} dispatchEvent(){} matches(){return false;} getBoundingClientRect(){return {left:0,top:0,width:1400,height:900};}
}
const elements=new Map();
document.getElementById=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};document.createElement=()=>new Element();document.querySelector=selector=>document.getElementById(selector);document.querySelectorAll=()=>[];const inputHandlers=new Map();document.addEventListener=(type,fn)=>{if(!inputHandlers.has(type))inputHandlers.set(type,[]);inputHandlers.get(type).push(fn);};document.body=new Element();document.documentElement=new Element();
window.addEventListener=()=>{};globalThis.innerWidth=1400;globalThis.innerHeight=900;globalThis.devicePixelRatio=1;window.devicePixelRatio=1;
globalThis.location={search:""};globalThis.matchMedia=()=>({matches:false});globalThis.requestAnimationFrame=()=>{};
document.body.dataset={chapter:'warden'};document.fonts={ready:Promise.resolve()};globalThis.ResizeObserver=class{observe(){}};
Object.defineProperty(globalThis,'navigator',{value:{maxTouchPoints:0},configurable:true});
globalThis.localStorage={getItem:()=>null,setItem(){}};
THREE.WebGLRenderer=class {constructor(){this.shadowMap={};this.capabilities={getMaxAnisotropy:()=>4};this.info={render:{calls:0,triangles:0}};}setPixelRatio(){}setSize(){}render(){}clearDepth(){}};
await import('../main.js');
for(let i=0;i<100&&!window.__READY__;i++)await new Promise(resolve=>setTimeout(resolve,5));
assert(window.__READY__,elements.get('error-message')?.textContent||'Main game failed to boot');
const game=window.__DEBUG__;assert.equal(game.state.difficulty,'veteran','Title START must default to hard combat');game.start('combat',false);
const expectedSpawn={x:game.level.extraction.x,z:game.level.extraction.z+4.25};
function checkArrival(){
 assert.equal(game.player.x,expectedSpawn.x);assert.equal(game.player.z,expectedSpawn.z);assert.equal(game.player.y,0);
 assert.equal(game.player.yaw,Math.PI,'Face from the lift into the compound');
 const resolved=game.resolvePosition(game.player.x,game.player.z);
 assert(Math.hypot(resolved.x-game.player.x,resolved.z-game.player.z)<.001,'Arrival clears the lift and container colliders');
 assert.equal(game.floorAt(game.player.x,game.player.z),0,'Arrival stands on the ground beyond the threshold ramp');
}
checkArrival();
for(let i=0;i<672;i++)game.simulate(1/60);
const arrivalEye=new THREE.Vector3(game.player.x,game.player.height,game.player.z),revealCenter=game.boss.rig.position.clone().add(new THREE.Vector3(0,1,0)),revealRay=revealCenter.clone().sub(arrivalEye),revealDistance=revealRay.length();
assert(game.wallDistance(arrivalEye,revealRay.normalize(),revealDistance)>=revealDistance-.1,'The launch silhouette clears the relay mast from the lift');
const revealCamera=new THREE.PerspectiveCamera(76,.65,.1,200);revealCamera.position.copy(arrivalEye);revealCamera.lookAt(arrivalEye.clone().add(new THREE.Vector3(0,0,1)));revealCamera.updateMatrixWorld(true);
const projected=revealCenter.clone().project(revealCamera);assert(Math.abs(projected.x)<.9&&Math.abs(projected.y)<.9,'Reveal remains in a narrow portrait view');
assert(!game.boss.status().acquired&&game.projectiles.length===0,'No acquisition during the visible reveal');game.start('combat',false);
assert.equal(game.security.cameras.filter(c=>c.online).length,0);assert.equal(game.enemies.length,0);assert(game.level.terminals.every(t=>t.done));assert.equal(game.player.shield,80);
assert.equal(game.serviceLift.mode,'parked','Chapter 03 lift starts open and inactive');
assert(game.level.colliders.find(c=>c.type==='lift-doors').minY>90,'Open doorway has no invisible blocker');
game.teleport(4,-67,.406);game.keys.add('KeyE');game.interact(2);
assert.equal(game.serviceLift.mode,'parked');assert(!game.serviceLift.begin(game.player),'Open cabin cannot descend');
assert(elements.get('interaction').classList.contains('hidden'),'No lift interaction prompt appears');
for(let i=0;i<100&&!game.boss.status().defeated;i++)game.boss.hit({weak:true});
assert(game.boss.status().defeated);assert(!game.state.over,'Victory waits until the crash settles');
game.keys.clear();for(let i=0;i<180;i++)game.simulate(1/60);assert(game.boss.status().settled&&!game.state.over,'Allow dust and rotors to settle after impact');
game.keys.clear();for(let i=0;i<420&&!game.state.over;i++)game.simulate(1/60);
assert(game.state.won&&game.boss.status().settled,'The settled Warden crash completes Chapter 03');
assert.equal(game.serviceLift.mode,'parked','Lift stays open and inactive after victory');
assert(!game.serviceLift.begin(game.player));
game.start('combat',false);assert(!game.state.over);assert.equal(game.boss.status().phase,1);assert.equal(game.boss.status().health,3000);assert.equal(game.boss.status().healed,0);assert.equal(game.state.reserve,540);assert.equal(game.enemies.length,0);assert(game.security.cameras.every(c=>!c.online));
const wall=game.level.colliders.find(c=>c.type==='wall');game.teleport(wall.x+2,wall.z);
const bolt=new THREE.Mesh(new THREE.SphereGeometry(.1),new THREE.MeshBasicMaterial());bolt.position.set(wall.x-2,1.2,wall.z);
game.projectiles.push({mesh:bolt,pos:bolt.position,previous:bolt.position.clone(),dir:new THREE.Vector3(1,0,0),speed:40,life:4,damage:30,source:'warden'});game.updateProjectiles(.2);assert.equal(game.player.shield,80,'A wall must stop actual WARDEN projectile damage');assert.equal(game.projectiles.length,0);
game.damage(200,'warden');assert(game.state.over&&!game.state.won);game.start('combat',false);assert.equal(game.player.health,100);assert.equal(game.player.shield,80);
console.log('PASS: real game boot, offline grid, open inactive lift, crash victory, wall protection, death and restart.');

assert.equal(game.humanWorld.tags[0].decal.material.color.getHex(),0xffffff,'Emergency fixtures must not recolour the graffiti pigment');
assert.equal(game.humanWorld.tags[0].decal.material.emissiveIntensity,.13);
const storm=game.storm;assert.equal(storm.snapshot().flakes,4800);assert(storm.snapshot().roofMasks>=8);assert(storm.fixtures.length>0);
for(const f of storm.fixtures){assert(f.material.emissive.r>f.material.emissive.g*5);assert(f.material.emissive.r>f.material.emissive.b*5);}
assert.equal(game.environment.snow.visible,false);assert.equal(game.environment.fogProfiles.atmospheric.density,.026);
assert(game.environment.hemi.color.r>game.environment.hemi.color.g*8);assert(game.environment.hemi.intensity>1);
assert(game.environment.fog.color.r>game.environment.fog.color.g*3);
storm.setReducedFlashing(true);game.environment.update(.1,game.player,0);storm.update(.1,game.player,0);const brightness=storm.fixtures.map(f=>f.material.emissiveIntensity);
game.environment.update(.1,game.player,4);storm.update(.1,game.player,4);assert.deepEqual(storm.fixtures.map(f=>f.material.emissiveIntensity),brightness);
const snapshots=JSON.stringify(game.level.colliders);storm.setQuality('low');assert.equal(storm.snapshot().flakes,2400);assert.equal(JSON.stringify(game.level.colliders),snapshots);
game.atmosphere.setReducedFlashing(true);game.atmosphere.update(.1,game.player,4,0);for(const light of [...game.atmosphere.pool,...game.atmosphere.fills])assert(light.color.r>light.color.g*5);
console.log('PASS: red fixtures and beams, blizzard quality limits, roof masks, steady reduced-flashing mode.');

// End-to-end input-path simulation. No teleport, direct damage, phase, or health
// edits in this run. Deterministic aim is a test driver, not manual play proof.
const canvas=elements.get('world');
function event(type,props={}){for(const fn of inputHandlers.get(type)||[])fn({target:canvas,preventDefault(){},repeat:false,button:0,clientX:320,clientY:240,...props});}
function ui(id,type='click'){for(const fn of elements.get(id).handlers.get(type)||[])fn({target:elements.get(id)});}
function key(code,on){event(on?'keydown':'keyup',{code});}
function lookAt(point){const dx=point.x-game.player.x,dz=point.z-game.player.z,dy=point.y-game.player.y-game.player.height,yaw=Math.atan2(-dx,-dz),pitch=Math.max(-1.4,Math.min(1.4,Math.atan2(dy,Math.hypot(dx,dz)))),turn=Math.atan2(Math.sin(yaw-game.player.yaw),Math.cos(yaw-game.player.yaw));event('mousedown',{button:2});event('mousemove',{clientX:320-turn/(.0021*game.state.sensitivity*(1+(game.adsConfig.sensitivity-1)*game.state.ads)),clientY:240-(pitch-game.player.pitch)/(.0021*game.state.sensitivity*(1+(game.adsConfig.sensitivity-1)*game.state.ads))});}
const keyInput=(code,on)=>key(code,on),gameTick=seconds=>{for(let i=0;i<Math.round(seconds*60)&&!game.state.over;i++)game.simulate(1/60);};
ui('restart');for(let i=0;i<100&&!game.boss.status().defeated;i++)game.boss.hit({weak:true});key('KeyE',true);gameTick(3);assert(!game.state.over,'Holding E through impact cannot skip the ending');key('KeyE',false);key('KeyE',true);assert(game.state.won,'A fresh E press skips the settled aftermath');key('KeyE',false);ui('restart');
await (await import('./check-warden-continuity.mjs')).checkContinuity({g:game,key:keyInput,tick:gameTick,ui,inputHandlers});
function walkTo(goal){
const walkable=(x,z)=>!game.level.colliders.some(c=>{if(c.minY>1.78||c.maxY<.05)return false;const a=c.angle||0,dx=x-c.x,dz=z-c.z,lx=dx*Math.cos(a)-dz*Math.sin(a),lz=dx*Math.sin(a)+dz*Math.cos(a);return Math.abs(lx)<c.w/2+.48&&Math.abs(lz)<c.d/2+.48;});
const start=[Math.round(game.player.x),Math.round(game.player.z)],queue=[start],parents=new Map([[start.join(','),null]]);let end=null;
for(let i=0;i<queue.length;i++){const at=queue[i];if(at[0]===goal[0]&&at[1]===goal[1]){end=at;break;}for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const n=[at[0]+dx,at[1]+dz],k=n.join(',');if(n[0]<-41||n[0]>41||n[1]<-77||n[1]>44||parents.has(k)||!walkable(...n))continue;parents.set(k,at);queue.push(n);}}
assert(end,'Destination has a continuous ground route');const route=[];for(let at=end;at;at=parents.get(at.join(',')))route.unshift(at);
for(const [x,z] of route){for(let i=0;i<120&&Math.hypot(x-game.player.x,z-game.player.z)>.15;i++){lookAt(new THREE.Vector3(x,game.player.y+game.player.height,z));event('mouseup',{button:2});key('KeyW',true);game.simulate(1/60);}key('KeyW',false);}
return route;
}
// Exercise the shipping Hard profile through normal inputs. Deterministic aim
// validates the route and combat rules; it does not certify human difficulty.
ui('deploy');assert.equal(game.state.difficulty,'veteran');
key('KeyW',true);key('ShiftLeft',true);for(let i=0;i<180;i++)game.simulate(1/60);key('KeyW',false);key('ShiftLeft',false);assert(game.player.z>expectedSpawn.z+12,'Normal movement must leave the lift and advance into the compound');
const arrivalRoute=walkTo([4,18]);assert(Math.hypot(game.player.x-4,game.player.z-18)<.4,'Lift arrival connects to the combat yard by normal walking');
console.log('PASS: lift start, collision-free threshold, outward orientation and '+arrivalRoute.length+' input-driven waypoints to the combat yard.');
let overloadPatterns=new Set(),repairSeen=false,coreHits=0,reloads=0,phases=new Set(),previousAmmo=game.state.ammo;
const point=new THREE.Vector3(),core=game.boss.rig.children.find(c=>c.userData.weakpoint);
for(let frame=0;frame<18000&&!game.boss.status().defeated&&!game.state.over;frame++){
 const bs=game.boss.status();phases.add(bs.phase);repairSeen ||= bs.repairing;
 const escort=game.enemies.find(e=>e.alive);
 if(escort&&!bs.repairing)point.set(escort.x,escort.y+.54,escort.z);
 else if(bs.vulnerable)core.getWorldPosition(point);
 else point.copy(game.boss.rig.position).add(new THREE.Vector3(0,1.9,0));
 if(bs.phase===3&&['sweep','strike'].includes(bs.mode))overloadPatterns.add(bs.mode);
 lookAt(point);event(bs.phase===3&&!overloadPatterns.has('strike')?'mouseup':'mousedown');
 key('KeyD',['aim','burst'].includes(bs.mode));key('KeyS',['sweep-aim','sweep','strike'].includes(bs.mode));
 const before=game.boss.rules.health;game.simulate(1/60);if(before-game.boss.rules.health>30)coreHits++;
 if(game.state.ammo>previousAmmo)reloads++;previousAmmo=game.state.ammo;
}
event('mouseup');event('mouseup',{button:2});key('KeyD',false);key('KeyS',false);
assert(!game.state.over,`Input fight died at ${game.state.time}s, boss ${game.boss.rules.health}`);
assert(game.boss.status().defeated,`Input-driven gunfire must defeat the boss: ${JSON.stringify({boss:game.boss.status(),player:game.player,ammo:game.state.ammo,reserve:game.state.reserve})}`);assert.deepEqual([...phases],[1,2,3]);assert(repairSeen&&game.boss.rules.interrupted,'Regular core shots must interrupt repair');assert(coreHits>20&&reloads>0);assert.deepEqual([...overloadPatterns],['sweep','strike'],'Hard run survives both overload patterns');
for(let i=0;i<420;i++)game.simulate(1/60);
assert(game.state.won&&game.boss.status().settled,'Victory completes after the crash without a lift interaction');
assert.equal(game.serviceLift.mode,'parked');
console.log('PASS: Hard input-driven full fight ('+game.state.time.toFixed(1)+'s, '+game.player.health+' health, '+game.state.reserve+' reserve), all phases, repair interruption, '+reloads+' reloads, '+coreHits+' core hits and crash victory.');
ui('restart');assert(!game.state.over&&game.boss.status().health===3000&&game.state.reserve===540,'UI restart restores encounter');
// Let the real boss/projectiles cause failure on Veteran; Forgiving shield
// regeneration can sustain an idle player during the acquisition phase.
game.state.difficulty='veteran';ui('restart');checkArrival();
key('KeyW',true);key('ShiftLeft',true);for(let i=0;i<180;i++)game.simulate(1/60);key('KeyW',false);key('ShiftLeft',false);
for(let i=0;i<30000&&!game.state.over;i++)game.simulate(1/60);assert(game.state.over&&!game.state.won,'Incoming attacks eventually kill an idle player');ui('restart');assert(game.player.health===100&&!game.state.over);console.log('PASS: enemy-fire death and UI restart after input-driven victory.');
