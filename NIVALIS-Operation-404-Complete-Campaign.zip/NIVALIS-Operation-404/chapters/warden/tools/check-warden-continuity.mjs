import assert from 'node:assert/strict';
export async function checkContinuity({g,key,tick,ui,inputHandlers}){
 const lift=g.serviceLift;
assert.deepEqual(lift.status().location,[4,-67]);
let litContainerVertices=0;const vertex=new THREE.Vector3();
lift.shell.parent.updateMatrixWorld(true);
lift.shell.parent.traverse(o=>{if(!o.isMesh||!o.material?.emissive?.getHex()||o.material.emissiveIntensity===0)return;const p=o.geometry.attributes.position;for(let i=0;i<p.count;i++){vertex.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld);if(vertex.x>0&&vertex.x<8&&vertex.y>3.8&&vertex.y<4.8&&vertex.z>-70&&vertex.z<-62)litContainerVertices++;}});
assert.equal(litContainerVertices,0,'Service lift container strips must be dark');
let otherCargoStillLit=false;g.level.prototypes.cargo_module.traverse(o=>{if(o.material?.emissive?.getHex()>0)otherCargoStillLit=true;});assert(otherCargoStillLit,'Other containers retain their original lights');
for(let i=0;i<90;i++)g.atmosphere.update(1/60,{x:4,z:-67},i/60);
assert(g.atmosphere.fills.every(l=>l.position.z!==-67),'No steady fill remains at the lift');
assert(g.level.containerLabels.filter(l=>l.z<-62&&l.x>-1&&l.x<9).every(l=>l.text==='SERVICE LIFT'),'All lift container nameplates omit the number');
console.log('PASS: unnumbered lift signs, dark container fixtures, no constant lift fill, and other cargo lights preserved.');

// Sweep the real rendered panel bounds through a complete opening. They must
// fit the hollow pockets and never pass through the retained building/cab walls.
const leaves=lift.cab.children.filter(o=>o.name.startsWith('Lift door '));
assert.equal(leaves.length,4);
const wallBoxes=g.level.colliders.filter(c=>c.type==='wall'||c.type==='lift-wall').map(c=>new THREE.Box3(new THREE.Vector3(c.x-c.w/2,c.minY,c.z-c.d/2),new THREE.Vector3(c.x+c.w/2,c.maxY,c.z+c.d/2)));
lift.reset();lift.unlock();
for(let frame=0;frame<=110;frame++){
 lift.cab.updateMatrixWorld(true);
 const bounds=leaves.map(o=>new THREE.Box3().setFromObject(o));
 for(const b of bounds){
  assert(b.min.x>=4-2.78&&b.max.x<=4+2.78,'Door extends outside its cassette');
  assert(b.min.z>-67+1.57&&b.max.z<-67+2.17,'Door touches a pocket cover');
  for(const wall of wallBoxes)assert(!b.intersectsBox(wall),'Moving door intersects a compound or cabin wall');
 }
 for(let a=0;a<bounds.length;a++)for(let b=a+1;b<bounds.length;b++){
  const overlap=bounds[a].clone().intersect(bounds[b]).getSize(new THREE.Vector3());
  assert(Math.min(overlap.x,overlap.y,overlap.z)<.0001,'Door leaves must stay in distinct tracks');
 }
 lift.update(1/60,g.player);
}
for(const [i,leaf] of leaves.entries()){const b=new THREE.Box3().setFromObject(leaf);assert(i<2?b.max.x<4-1.79:b.min.x>4+1.79,'Open leaves must be concealed behind pocket covers');}
lift.reset();
console.log('PASS: four telescoping panels clear all walls and remain inside their covered tracks throughout opening.');
// The visible tube and emitted light fade together; distant shaft lights do not.
let bulb;lift.cab.traverse(o=>{if(o.material?.name==='Cabin amber strip')bulb=o.material;});
const lamp=lift.cab.children.find(o=>o.isPointLight);assert(bulb&&lamp);
const shaftGlow=[];lift.shaft.traverse(o=>{if(o.material?.emissiveIntensity)shaftGlow.push([o.material,o.material.emissiveIntensity]);});
let dimmest=Infinity,brightest=0,blackoutFrames=0,longestBlackout=0;
for(let frame=0;frame<600;frame++){lift.update(1/60,g.player);dimmest=Math.min(dimmest,lamp.intensity);brightest=Math.max(brightest,lamp.intensity);blackoutFrames=lamp.intensity<.06?blackoutFrames+1:0;longestBlackout=Math.max(longestBlackout,blackoutFrames);assert(Math.abs(lamp.intensity/1.85-bulb.emissiveIntensity/.95)<1e-8,'Tube and emitted light must flicker together');}
if(g.state.reducedFlashing)assert(dimmest===1.85&&brightest===1.85,'Reduced motion keeps the light steady');
else {assert(dimmest<.04&&brightest>1.8,'A failing strip must drop almost completely out and recover');assert(longestBlackout>=20,'Blackouts must persist long enough to be clearly visible');}
for(const [m,intensity] of shaftGlow)assert.equal(m.emissiveIntensity,intensity,'Only the cabin strip flickers');
lift.reset();
console.log('PASS: '+(process.argv.includes('--reduced-motion')?'steady reduced-motion light':'irregular cabin flicker')+' synchronises the bulb and light while shaft lamps stay steady.');


// WARDEN's accessibility toggle also holds the cabin light steady.
lift.setReducedFlashing(true);for(let i=0;i<600;i++){lift.update(1/60,g.player);assert.equal(lift.status().light,100);}
lift.setReducedFlashing(false);lift.reset();
 const {player,state,ladder,serviceLift}=g;
 const press=code=>{key(code,true);key(code,false);};
 const until=(condition,message)=>{for(let i=0;i<600&&!condition();i++)g.simulate(1/60);assert(condition(),message);};
 const face=point=>{const dx=point.x-player.x,dy=point.y-player.y-player.height,dz=point.z-player.z;player.yaw=Math.atan2(-dx,-dz);player.pitch=Math.atan2(dy,Math.hypot(dx,dz));return new THREE.Vector3(dx,dy,dz).normalize();};
 g.start('recon',false);
 g.teleport(ladder.exit.x,ladder.exit.z,0);player.yaw=-Math.PI/2;
 key('KeyE',true);g.interact(1/60);key('KeyE',false);
 assert(state.climbing);tick(.5);
 const ammo=state.ammo;g.shoot();assert.equal(state.ammo,ammo,'Ladder prevents firing');
 key('KeyW',true);tick(.6);const heldY=player.y;assert(heldY>.9);
 press('KeyM');tick(.4);assert.equal(player.y,heldY,'Map freezes the ladder');press('KeyM');
 until(()=>!state.climbing,'Climb exits onto the pad');key('KeyW',false);
 assert.equal(player.y,g.level.ladder.topY);assert.equal(player.x,ladder.deck.x);assert.equal(player.z,ladder.deck.z);
 assert.equal(serviceLift.mode,'parked','Pad access must not enable the parked lift');
 player.yaw=Math.PI/2;key('KeyE',true);g.interact(1/60);key('KeyE',false);tick(1.1);
 key('KeyS',true);until(()=>!state.climbing,'Climb descends from the pad');key('KeyS',false);
 assert.equal(player.y,0);assert.equal(player.x,ladder.exit.x);assert.equal(player.z,ladder.exit.z);
 player.yaw=-Math.PI/2;key('KeyE',true);g.interact(1/60);key('KeyE',false);tick(.5);key('KeyW',true);tick(.6);key('KeyW',false);
 press('Space');g.updatePlayer(1/60);assert(!state.climbing&&!player.grounded,'Space releases the ladder without immunity');
 console.log('PASS: ladder ascent, descent, map freeze, release and combat restrictions coexist with the inactive arrival lift.');

 g.start('recon',false);key('KeyQ',true);tick(.8);g.updateCamera();
 assert(state.ads>.999);assert(Math.abs(g.camera.fov-g.adsConfig.aimFov)<.01);
 const zoom=Math.tan(g.adsConfig.baseFov*Math.PI/360)/Math.tan(g.camera.fov*Math.PI/360);
 assert(Math.abs(zoom-2)<.001,'Sights use true 2x magnification');
 const mouse=(type,button)=>inputHandlers.get(type).forEach(fn=>fn({button,target:document.getElementById('world'),clientX:0,clientY:0}));
 mouse('mousedown',2);key('KeyQ',false);tick(.2);assert(state.ads>.99,'Releasing Q preserves a held RMB');
 mouse('mouseup',2);tick(.8);assert(state.ads<.001,'Releasing both aim controls clears zoom');
 key('KeyQ',true);tick(.8);state.ammo=35;press('KeyR');tick(.4);assert(state.ads<.01,'Reload exits ADS');
 key('KeyQ',false);tick(2);assert.equal(state.ammo,36);
 console.log('PASS: 2x sights, Q/RMB overlap and reload transitions preserve v1.8 aiming.');

 g.start('recon',false);assert.equal(g.humanWorld.tags.length,1);
 assert.equal(g.humanObjectives.status().tagsRequired,1);
 const tag=g.humanWorld.tags[0];g.teleport(-24.2,-42.45,.28);
 const resolved=g.resolvePosition(player.x,player.z);
 assert(Math.hypot(resolved.x-player.x,resolved.z-player.z)<.01,'Graffiti approach clears the NIVALIS SYSTEMS container wall');
 const view=face(tag);assert.equal(g.humanObjectives.nearest(player,view)?.kind,'tag','Graffiti is reachable inside NIVALIS SYSTEMS');
 const origin=new THREE.Vector3(player.x,player.y+player.height,player.z);
 serviceLift.shell.parent.updateMatrixWorld(true);
 const ray=new THREE.Raycaster(origin,view,0,origin.distanceTo(new THREE.Vector3(tag.x,tag.y,tag.z))-.08);
 assert.equal(ray.intersectObjects([serviceLift.shell,serviceLift.cab],true).length,0,'Rendered lift parts must not hide the tag from its approach');
 key('KeyE',true);g.interact(3.1);assert(g.humanObjectives.status().achievements.eyesOff,'One tag awards Eyes Off');
 g.teleport(4,-67,.406);player.yaw=0;player.pitch=0;
 g.interact(2);assert.equal(serviceLift.mode,'parked','Spraying cannot activate the parked lift');
 key('KeyE',false);g.interact(.01);key('KeyE',true);g.interact(1.1);key('KeyE',false);
 assert.equal(serviceLift.mode,'parked','A fresh E press cannot start lift travel');
 console.log('PASS: single-container Eyes Off objective remains reachable while the open arrival lift stays inactive.');
 g.start('recon',false);assert(!state.climbing&&serviceLift.mode==='parked');
}
