// Reference: references/basement-props-reference.png (built-in image generation).
// Metres, Y-up, front +Z. Real model surfaces; no remote assets.
function kit(T){
 const g=new T.Group(),m={};
 const material=(name,color,metalness=.5,roughness=.8)=>{const a=new T.MeshStandardMaterial({color,metalness,roughness});a.color.convertSRGBToLinear();a.name=name;return a;};
 m.steel=material('Bunker grey-green steel',0x535f56);m.edge=material('Worn steel edges',0x89918b,.72,.62);m.dark=material('Graphite inset',0x252b2c,.35,.88);m.black=material('Rubber and shadow',0x101714,.05,.98);m.cloth=material('Worn wool blanket',0x555448,0,1);m.pillow=material('Canvas linen',0x7b7b69,0,1);m.rust=material('Restrained corrosion',0x624335,.18,.98);m.green=material('Phosphor indicator',0x74df95,0,.35);m.green.emissive.set(0x74df95);m.green.emissiveIntensity=.6;m.amber=material('Amber indicator',0xc1965c,.12,.5);m.amber.emissive.set(0xb87332);m.amber.emissiveIntensity=.4;
 const mesh=(geo,mat,x=0,y=0,z=0)=>{const o=new T.Mesh(geo,mat);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const B=(x,y,z,w,h,d,mat=m.steel)=>mesh(new T.BoxGeometry(w,h,d),mat,x,y,z);
 const C=(x,y,z,r,h,mat=m.steel,n=12)=>mesh(new T.CylinderGeometry(r,r,h,n),mat,x,y,z);
 const beam=(a,b,r=.025,mat=m.steel)=>{a=new T.Vector3(...a);b=new T.Vector3(...b);const v=b.clone().sub(a),o=mesh(new T.CylinderGeometry(r,r,v.length(),8),mat);o.position.copy(a.add(b).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return o;};
 const plate=(x,y,z,w,h,d,mat=m.steel,c=.045)=>{const s=new T.Shape();const pts=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];s.moveTo(...pts[0]);pts.slice(1).forEach(p=>s.lineTo(...p));s.closePath();return mesh(new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:false}),mat,x,y,z-d/2);};
 const bolt=(x,y,z)=>{const o=C(x,y,z,.015,.015,m.edge,6);o.rotation.x=Math.PI/2;};
 const wear=(x,y,z,w,h)=>{for(let i=0;i<7;i++){const q=i*.137;B(x-w/2+(q%1)*w,y-h/2+((i*.371)%1)*h,z,.012+(i%3)*.018,.007,.003,i%3?m.edge:m.rust);}};
 return {g,m,B,C,beam,plate,bolt,wear};
}

function finish(g,T){g.updateMatrixWorld(true);const bb=new T.Box3(),v=new T.Vector3();g.traverse(o=>{const a=o.isMesh&&o.geometry.attributes.position;if(a)for(let i=0;i<a.count;i++)bb.expandByPoint(v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld));});const c=bb.getCenter(new T.Vector3());g.children.forEach(o=>{o.position.x-=c.x;o.position.z-=c.z;o.position.y-=bb.min.y;});return g;}
export default function generate(T){const {g,m,B,C,beam,plate,bolt,wear}=kit(T);g.name='Two occupied emergency bunks';
 for(const x of [-1.17,1.17])for(const z of [-.48,.48]){C(x,1.21,z,.035,2.42,m.steel);B(x,.027,z,.19,.054,.16,m.edge);}
 for(const y of [.44,1.66]){B(0,y,0,2.36,.12,1.03,m.steel);plate(0,y+.15,0,2.27,.20,.95,m.cloth,.065);B(-.75,y+.288,0,.47,.10,.70,m.pillow).rotation.z=-.055;for(let i=0;i<6;i++){B(.2+i*.105,y+.261,.015,.016,.016,.82,i%2?m.cloth:m.pillow).rotation.y=.07;}beam([-1.17,y+.54,-.48],[1.17,y+.54,-.48],.026,m.steel);for(const x of [-1.17,1.17])beam([x,y+.20,-.48],[x,y+.20,.48],.028,m.steel);wear(0,y,.526,2.3,.10);}
 for(const x of [.61,1.07])beam([x,.10,.57],[x,2.05,.57],.025,m.edge);for(let y=.27;y<2.02;y+=.25)beam([.61,y,.57],[1.07,y,.57],.022,m.edge);
 beam([-1.10,.48,-.5],[1.10,1.6,-.5],.015,m.dark);return finish(g,T);}
