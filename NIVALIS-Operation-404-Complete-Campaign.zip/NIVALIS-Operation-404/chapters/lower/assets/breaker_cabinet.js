// Reference: references/basement-props-reference.png (built-in image generation).
// Metres, Y-up, front +Z. Real model surfaces; no remote assets.
function kit(T){
 const g=new T.Group(),m={};
 const material=(name,color,metalness=.5,roughness=.8)=>{const a=new T.MeshStandardMaterial({color,metalness,roughness});a.color.convertSRGBToLinear();a.name=name;return a;};
 m.steel=material('Bunker grey-green steel',0x535f56);m.edge=material('Worn steel edges',0x89918b,.72,.62);m.dark=material('Graphite inset',0x252b2c,.35,.88);m.black=material('Rubber and shadow',0x101714,.05,.98);m.cloth=material('Worn wool blanket',0x555448,0,1);m.pillow=material('Canvas linen',0x7b7b69,0,1);m.rust=material('Restrained corrosion',0x624335,.18,.98);m.green=material('Phosphor indicator',0x74df95,0,.35);m.green.emissive.set(0x74df95);m.green.emissiveIntensity=.6;m.amber=material('Amber indicator',0xc1965c,.12,.5);m.amber.emissive.set(0xb87332);m.amber.emissiveIntensity=.4;
 const mesh=(geo,mat,x=0,y=0,z=0)=>{const o=new T.Mesh(geo,mat);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const B=(x,y,z,w,h,d,mat=m.steel)=>mesh(new T.BoxGeometry(w,h,d),mat,x,y,z);
 const C=(x,y,z,r,h,mat=m.steel,n=12)=>mesh(new T.CylinderGeometry(r,r,h,n),mat,x,y,z);
 const beam=(a,b,r=.025,mat=m.steel)=>{a=new T.Vector3(...a);b=new T.Vector3(...b);const v=b.clone().sub(a),o=mesh(new T.CylinderGeometry(r,r,v.length(),8),mat);o.position.copy(a.add(b).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return o;};
 const plate=(x,y,z,w,h,d,mat=m.steel,c=.045)=>{const s=new T.Shape();const pts=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];s.moveTo(...pts[0]);pts.slice(1).forEach(p=>s.lineTo(...p));s.closePath();return mesh(new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:false}),mat,x,y,z-d/2);};
 const bolt=(x,y,z)=>{const o=C(x,y,z,.015,.015,m.edge,6);o.rotation.x=Math.PI/2;};
 const wear=(x,y,z,w,h)=>{for(let i=0;i<7;i++){const q=i*.137;B(x-w/2+(q%1)*w,y-h/2+((i*.371)%1)*h,z,.012+(i%3)*.018,.007,.003,i%3?m.edge:m.rust);}};
 return {g,m,B,C,beam,plate,bolt,wear};
}

function finish(g,T){g.updateMatrixWorld(true);const bb=new T.Box3(),v=new T.Vector3();g.traverse(o=>{const a=o.isMesh&&o.geometry.attributes.position;if(a)for(let i=0;i<a.count;i++)bb.expandByPoint(v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld));});const c=bb.getCenter(new T.Vector3());g.children.forEach(o=>{o.position.x-=c.x;o.position.z-=c.z;o.position.y-=bb.min.y;});return g;}
export default function generate(T){const {g,m,B,C,beam,plate,bolt,wear}=kit(T);g.name='Auxiliary breaker cabinet';g.userData.mounts='back';
 plate(0,1.24,0,1.76,2.44,.49,m.steel);B(0,1.30,.252,1.53,2.11,.026,m.black);
 for(const x of [-.68,.68]){B(x,.035,0,.3,.07,.66,m.dark);beam([x,.2,.285],[x,2.2,.285],.035,m.edge);}
 for(let i=0;i<4;i++){const x=-.51+i*.34;plate(x,1.43,.297,.275,1.01,.10,m.steel,.025);beam([x,1.02,.365],[x,1.57,.45],.025,m.edge);const lever=C(x,1.57,.48,.04,.18,m.rust);lever.rotation.z=Math.PI/2;B(x,2.06,.30,.23,.14,.04,m.dark);for(const y of [.79,1.99])bolt(x,y,.36);beam([x,.39,.30],[x,.88,.30],.023,m.black);}
 B(0,.33,.282,1.38,.11,.045,m.edge);const door=new T.Group();door.name='Open cabinet door';g.add(door);door.position.set(.89,1.27,.24);door.rotation.y=1.13;
 const p=B(0,0,0,1.70,2.35,.045,m.steel);g.remove(p);door.add(p);p.position.set(.85,0,0);
 for(let i=0;i<6;i++){const sl=B(0,0,0,.55,.032,.012,m.dark);g.remove(sl);door.add(sl);sl.position.set(.85,-.7+i*.07,.032);}
 wear(0,2.43,.26,1.7,.10);for(const y of [.24,2.28])for(const x of [-.77,.77])bolt(x,y,.29);return finish(g,T);}
