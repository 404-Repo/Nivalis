// Reference: references/basement-props-reference.png (built-in image generation).
// Metres, Y-up, front +Z. Real model surfaces; no remote assets.
function kit(T){
 const g=new T.Group(),m={};
 const material=(name,color,metalness=.5,roughness=.8)=>{const a=new T.MeshStandardMaterial({color,metalness,roughness});a.color.convertSRGBToLinear();a.name=name;return a;};
 m.steel=material('Bunker grey-green steel',0x535f56);m.edge=material('Worn steel edges',0x89918b,.72,.62);m.dark=material('Graphite inset',0x252b2c,.35,.88);m.black=material('Rubber and shadow',0x101714,.05,.98);m.cloth=material('Worn wool blanket',0x555448,0,1);m.pillow=material('Canvas linen',0x7b7b69,0,1);m.rust=material('Restrained corrosion',0x624335,.18,.98);m.green=material('Phosphor indicator',0x74df95,0,.35);m.green.emissive.set(0x74df95);m.green.emissiveIntensity=.6;m.amber=material('Amber indicator',0xc1965c,.12,.5);m.amber.emissive.set(0xb87332);m.amber.emissiveIntensity=.4;
 const mesh=(geo,mat,x=0,y=0,z=0)=>{const o=new T.Mesh(geo,mat);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const B=(x,y,z,w,h,d,mat=m.steel)=>mesh(new T.BoxGeometry(w,h,d),mat,x,y,z);
 const C=(x,y,z,r,h,mat=m.steel,n=12)=>mesh(new T.CylinderGeometry(r,r,h,n),mat,x,y,z);
 const beam=(a,b,r=.025,mat=m.steel)=>{a=new T.Vector3(...a);b=new T.Vector3(...b);const v=b.clone().sub(a),o=mesh(new T.CylinderGeometry(r,r,v.length(),8),mat);o.position.copy(a.add(b).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return o;};
 const plate=(x,y,z,w,h,d,mat=m.steel,c=.045)=>{const s=new T.Shape();const pts=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];s.moveTo(...pts[0]);pts.slice(1).forEach(p=>s.lineTo(...p));s.closePath();return mesh(new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:false}),mat,x,y,z-d/2);};
 const bolt=(x,y,z)=>{const o=C(x,y,z,.015,.015,m.edge,6);o.rotation.x=Math.PI/2;};
 const wear=(x,y,z,w,h)=>{for(let i=0;i<7;i++){const q=i*.137;B(x-w/2+(q%1)*w,y-h/2+((i*.371)%1)*h,z,.012+(i%3)*.018,.007,.003,i%3?m.edge:m.rust);}};
 return {g,m,B,C,beam,plate,bolt,wear};
}

function finish(g,T){g.updateMatrixWorld(true);const bb=new T.Box3(),v=new T.Vector3();g.traverse(o=>{const a=o.isMesh&&o.geometry.attributes.position;if(a)for(let i=0;i<a.count;i++)bb.expandByPoint(v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld));});const c=bb.getCenter(new T.Vector3());g.children.forEach(o=>{o.position.x-=c.x;o.position.z-=c.z;o.position.y-=bb.min.y;});return g;}
export default function generate(T){const {g,m,B,C,beam,plate,bolt,wear}=kit(T);g.name='Lower station / archival CRT desk';
 for(const x of [-1.03,1.03]){plate(x,.53,0,.43,1.0,.79,m.steel);B(x,.05,0,.57,.10,.91,m.dark);for(let i=0;i<3;i++){B(x,.28+i*.24,.409,.35,.20,.025,m.dark);B(x,.33+i*.24,.43,.14,.025,.035,m.edge);}wear(x,.6,.425,.35,.8);}
 plate(0,1.10,.03,2.65,.15,1.05,m.steel);B(0,1.017,-.36,2.20,.10,.07,m.dark);
 plate(-.36,1.72,-.20,1.28,1.15,.53,m.steel,.09);plate(-.36,1.74,.075,1.10,.91,.04,m.dark,.09);plate(-.36,1.74,.104,.92,.72,.025,m.black,.07);
 const anchor=new T.Group();anchor.name='display-anchor';anchor.position.set(-.36,1.74,.12);g.add(anchor);
 for(const x of [-.93,.21])for(const y of [1.24,2.21])bolt(x,y,.089);
 for(const x of [-1.04,.32])beam([x,1.37,.11],[x,2.10,.11],.031,m.edge);
 for(let i=0;i<8;i++)B(-.83+i*.13,2.305,-.2,.07,.012,.31,m.dark);
 B(-.37,1.195,.32,1.17,.035,.37,m.dark).rotation.x=.10;
 for(let r=0;r<4;r++)for(let c=0;c<14;c++)B(-.89+c*.076,1.229,.20+r*.067,.054,.018,.045,m.pillow);
 B(-.41,1.23,.456,.36,.018,.043,m.pillow);
 const deck=B(.90,1.32,-.08,.61,.36,.64,m.dark);deck.rotation.x=-.18;
 for(let r=0;r<3;r++)for(let c=0;c<3;c++)B(.70+c*.18,1.30+r*.09,.271-r*.027,.10,.045,.03,(r+c)%4?m.steel:m.amber);
 C(.91,1.202,.37,.095,.035,m.dark);C(.91,1.25,.37,.035,.08,m.edge);
 for(const x of [-1.19,1.19])for(const z of [-.34,.44]){const o=C(x,1.181,z,.02,.013,m.edge,6);}
 beam([-.87,.25,-.4],[-.87,1.66,-.4],.047,m.black);wear(-.36,2.28,.081,1.15,.04);wear(0,1.12,.563,2.5,.09);return finish(g,T);}
