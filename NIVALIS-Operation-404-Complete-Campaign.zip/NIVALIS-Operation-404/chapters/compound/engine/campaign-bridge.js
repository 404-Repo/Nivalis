// Explicit campaign adapter. Standalone source still runs without a parent shell.
const host=window.name==='nivalis-campaign'&&window.parent!==window?window.parent.__NIVALIS_CAMPAIGN__:null;
let adapter=null;
export const campaign={
 enabled:!!host,disposed:false,
 attach(value){adapter=value;},
 ready(){if(host&&adapter)host.ready(window,adapter);},
 complete(result){host?.complete(window,result);},
 failed(){host?.failed(window);},
 prepare(){host?.prepare(window);},
 playing(){host?.playing(window);},
 paused(){host?.paused(window);},
 lock(){host?.lock(window);},
 title(){host?.title(window);},
 settings(){host?.settings(window);},
 mementos(value){return host?.mementos(window,value);}
};
if(host){
 document.addEventListener('click',event=>{
  if(event.target.closest('[data-open-panel="title-settings"]')){event.preventDefault();event.stopImmediatePropagation();host.settings(window);}
 },true);
 const target=document.querySelector('#pause .pause-panel')||document.querySelector('#pause .panel')||document.getElementById('pause');
 const button=document.createElement('button');button.textContent='MAIN TITLE';button.className='title-panel-link campaign-title';button.addEventListener('click',()=>host.title(window));target?.append(button);
}
