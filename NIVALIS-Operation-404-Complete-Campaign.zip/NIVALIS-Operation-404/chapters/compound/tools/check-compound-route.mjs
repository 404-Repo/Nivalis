import assert from 'node:assert/strict';

// A deterministic route-viability regression, not a claim about player skill.
// All patrols and CCTV run uninterrupted from the real Hard spawn. Movement,
// crouch/sprint and interaction use the real input handlers. Only look direction
// is steered automatically. No teleports, damage changes or disabled actors.
export function checkCompoundRoute({g,key,elements}){
  const route=[
    ['sprint'],[-35.8,35.5],['wait',2],[-35.4,31.3],['wait',2],
    ['sneak'],[-25,8],[-20,7],[-20,-7.2],['use',1.8],
    [-21.2,-7.2],[-21.2,-17],[-16,-23],[-13,-29],[-14,-38],
    ['sprint'],[-6,-35],[4,-35],['sneak'],['use',1.8],
    [9,-38],[9,-50],[4,-50],[20.2,-50],[20.2,-41],
    ['walk'],[20.2,-19.5],['sneak'],['use',1.8],
    ['walk'],[20.2,-41],['sneak'],[27,-50],[17,-60],
    [12,-62],[4,-62],[4,-67],['use',1.2],['wait',13]
  ];
  g.start('combat',false);
  assert(g.tuning().stealth,'Route must use default Hard rules');
  const advance=()=>{
    g.simulate(1/60);
    assert(!g.security.compoundAlert,'Route must not trigger confirmed detection');
    assert(!g.state.over||g.state.won,'Player must survive every frame');
  };
  for(const step of route){
    if(['walk','sneak','sprint'].includes(step[0])){
      key('KeyC',false);key('ShiftLeft',false);
      if(step[0]==='sneak')key('KeyC',true);
      if(step[0]==='sprint')key('ShiftLeft',true);
    }else if(typeof step[0]==='string'){
      if(step[0]==='use')key('KeyE',true);
      for(let frame=0;frame<Math.round(step[1]*60)&&!g.state.over;frame++)advance();
      key('KeyE',false);
    }else{
      key('KeyW',true);let reached=false;
      for(let frame=0;frame<5400;frame++){
        const dx=step[0]-g.player.x,dz=step[1]-g.player.z;
        if(Math.hypot(dx,dz)<.25){reached=true;break;}
        g.player.yaw=Math.atan2(-dx,-dz);advance();
      }
      key('KeyW',false);
      assert(reached,`Movement must reach ${step} without crossing solid cover`);
    }
  }
  assert(g.state.won&&g.serviceLift.mode==='arrived','Complete the descent to B1');
  assert.equal(g.level.terminals.filter(t=>t.done).length,3);
  assert.equal(g.enemies.filter(e=>e.alive).length,8);
  assert.equal(g.state.kills,0);assert.equal(g.state.shots,0);
  assert.equal(g.state.droneAlerts+g.security.alerts,0);
  assert.equal(g.state.stealthBonus,1000,'Completion awards the Ghost bonus');
  assert.match(elements.get('result-stats').innerHTML,/GHOST/,'Results display Ghost');
  console.log(`PASS: uninterrupted ${g.state.time.toFixed(1)}s Hard route; three uplinks, eight surviving patrols, zero shots/alerts, Ghost and B1 arrival.`);
}
