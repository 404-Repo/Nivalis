#!/usr/bin/env node
// Render-state regression fixtures. Node VM uses the same local Three r140.
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx={exports:{},module:{exports:{}},console};vm.runInNewContext(fs.readFileSync(path.join(root,'vendor/three.min.js'),'utf8'),ctx);globalThis.THREE=ctx.exports;
const {bakeStatic}=await import('../engine/assets.js'),T=globalThis.THREE,tests=[];
const rec=(name,passed,detail)=>{tests.push({name,passed,detail});assert(passed,name);console.log('PASS',name);};
function two(a,b){const g=new T.Group();for(const [i,m]of [a,b].entries()){const mesh=new T.Mesh(new T.BoxGeometry(1,1,1),m);mesh.position.set(i*2-.5,.5,0);mesh.castShadow=mesh.receiveShadow=true;g.add(mesh);}return bakeStatic(g);}
for(const slot of ['roughnessMap','metalnessMap','emissiveMap','aoMap','alphaMap','lightMap']){const a=new T.MeshStandardMaterial(),b=a.clone();a[slot]=new T.Texture();b[slot]=new T.Texture();rec(`Distinct ${slot} survives static merging`,two(a,b).children.length===2);}
for(const key of ['normalScale','bumpScale','depthWrite','alphaTest','polygonOffsetFactor']){const a=new T.MeshStandardMaterial(),b=a.clone();if(key==='normalScale')b.normalScale.set(2,1);else if(key==='depthWrite')b.depthWrite=false;else b[key]=.36;rec(`Distinct ${key} survives static merging`,two(a,b).children.length===2);}
{const a=new T.MeshStandardMaterial({roughnessMap:new T.Texture()}),b=a.clone();rec('Identical render state still batches into one draw',two(a,b).children.length===1);}
{const a=new T.MeshStandardMaterial(),b=a.clone();a.onBeforeCompile=()=>{};b.onBeforeCompile=()=>{};rec('Unknown custom shader hooks are never merged by accident',two(a,b).children.length===2);}
{const a=new T.MeshStandardMaterial(),b=a.clone();a.onBeforeCompile=b.onBeforeCompile=()=>{};a.userData.materialMergeKey=b.userData.materialMergeKey='verified-fixture';rec('Explicit identical surface shader contract can batch',two(a,b).children.length===1);}
{const g=new T.Group(),m=new T.InstancedMesh(new T.BoxGeometry(1,1,1),new T.MeshStandardMaterial(),2);m.setMatrixAt(0,new T.Matrix4().makeTranslation(-3,.5,0));m.setMatrixAt(1,new T.Matrix4().makeTranslation(3,.5,0));g.add(m);const out=bakeStatic(g),box=new T.Box3().setFromObject(out),size=box.getSize(new T.Vector3());rec('Baking applies instance matrices, retaining 7 m width',Math.abs(size.x-7)<1e-6);rec('Baking retains both cubes and 24 triangles',out.children[0].geometry.attributes.position.count/3===24);}
const report={environment:'Node / bundled Three r140',tests,passed:tests.every(t=>t.passed)};fs.mkdirSync(path.join(root,'docs/surface-qa'),{recursive:true});fs.writeFileSync(path.join(root,'docs/surface-qa/merge-report.json'),JSON.stringify(report,null,2));
