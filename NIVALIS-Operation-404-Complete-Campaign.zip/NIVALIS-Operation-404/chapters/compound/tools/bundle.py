#!/usr/bin/env python3
"""Embed the complete ES-module graph, fonts and assets in PLAY.html.

Uses native import maps so modules retain their own scopes. Python stdlib only.
The canonical source remains index.html + main.js + engine/ + assets/ + vendor/.
"""
from pathlib import Path
import base64
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'artifacts/PLAY.html'
IMPORT = re.compile(r'(^\s*import\b[^;\n]*?\bfrom\s*)([\'\"])([^\'\"]+)\2', re.M)
modules = {}


def local_file(parent, reference):
    path = (parent / reference).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        raise ValueError(f'Missing or external runtime file: {reference}')
    return path


def key(path):
    return 'nivalis/' + path.relative_to(ROOT).as_posix()


def embed_module(path):
    name = key(path)
    if name in modules:
        return name
    modules[name] = ''
    def rewrite(match):
        dependency = local_file(path.parent, match[3])
        return match[1] + json.dumps(embed_module(dependency))
    source = IMPORT.sub(rewrite, path.read_text())
    modules[name] = 'data:text/javascript;base64,' + base64.b64encode(source.encode()).decode()
    return name


def script_safe(source):
    return re.sub(r'</script', r'<\\/script', source, flags=re.I)


def embed_css(path):
    def replace_url(match):
        ref = match[1].strip(' \"\'')
        if ref.startswith('data:'):
            return match[0]
        asset = local_file(path.parent, ref)
        mime = {'.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml'}[asset.suffix]
        return 'url("data:' + mime + ';base64,' + base64.b64encode(asset.read_bytes()).decode() + '")'
    return re.sub(r'url\(([^)]+)\)', replace_url, path.read_text())


embed_module(ROOT / 'main.js')
assets = sorted((ROOT / 'assets').glob('*.js'))
bootstrap = '\n'.join('import asset_' + str(i) + ' from ' + json.dumps(embed_module(path)) + ';' for i, path in enumerate(assets))
bootstrap += '\nwindow.__ASSET_REGISTRY__={' + ','.join(json.dumps(path.stem)+':asset_'+str(i) for i, path in enumerate(assets)) + '};\nawait import("nivalis/main.js");'
html = (ROOT / 'index.html').read_text()
html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', lambda m: '<style>\n' + embed_css(local_file(ROOT, m[1])) + '\n</style>', html)
html = html.replace('<script src="./vendor/three.min.js"></script>', '<script>\n' + script_safe((ROOT/'vendor/three.min.js').read_text()) + '\n</script>')
html = html.replace('<script type="module" src="./main.js"></script>', '<script type="importmap">' + json.dumps({'imports': modules}, separators=(',', ':')) + '</script>\n<script type="module">' + script_safe(bootstrap) + '</script>')
if re.search(r'<(?:script|link)\b[^>]*(?:src|href)="\./', html):
    raise ValueError('An external runtime script or stylesheet remains')
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(html)
print(f'Bundled {OUT}: {len(modules)} modules, {len(assets)} assets, {OUT.stat().st_size:,} bytes.')
