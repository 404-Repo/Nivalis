import assert from 'node:assert/strict';

// Exercise the imported v1.8 controls against the merged game, including its
// interaction priority at the new lift. Run via check-lift.mjs --access-alert.
export async function checkAccessAlert({g,key,tick,ui,inputHandlers}){
 const {player,state,ladder,serviceLift}=g;
 const press=code=>{key(code,true);key(code,false);};
 const until=(condition,message)=>{for(let i=0;i<600&&!condition();i++)g.simulate(1/60);assert(condition(),message);};
 const face=point=>{const dx=point.x-player.x,dy=point.y-player.y-player.height,dz=point.z-player.z;player.yaw=Math.atan2(-dx,-dz);player.pitch=Math.atan2(dy,Math.hypot(dx,dz));return new THREE.Vector3(dx,dy,dz).normalize();};
 g.start('recon',false);
 g.teleport(ladder.exit.x,ladder.exit.z,0);player.yaw=-Math.PI/2;
 key('KeyE',true);g.interact(1/60);key('KeyE',false);
 assert(state.climbing);tick(.5);
 const ammo=state.ammo;g.shoot();assert.equal(state.ammo,ammo,'Ladder prevents firing');
 key('KeyW',true);tick(.6);const heldY=player.y;assert(heldY>.9);
 press('KeyM');tick(.4);assert.equal(player.y,heldY,'Map freezes the ladder');press('KeyM');
 until(()=>!state.climbing,'Climb exits onto the pad');key('KeyW',false);
 assert.equal(player.y,g.level.ladder.topY);assert.equal(player.x,ladder.deck.x);assert.equal(player.z,ladder.deck.z);
 assert.equal(serviceLift.mode,'locked','Pad access must not unlock the lift');
 player.yaw=Math.PI/2;key('KeyE',true);g.interact(1/60);key('KeyE',false);tick(1.1);
 key('KeyS',true);until(()=>!state.climbing,'Climb descends from the pad');key('KeyS',false);
 assert.equal(player.y,0);assert.equal(player.x,ladder.exit.x);assert.equal(player.z,ladder.exit.z);
 player.yaw=-Math.PI/2;key('KeyE',true);g.interact(1/60);key('KeyE',false);tick(.5);key('KeyW',true);tick(.6);key('KeyW',false);
 press('Space');g.updatePlayer(1/60);assert(!state.climbing&&!player.grounded,'Space releases the ladder without immunity');
 console.log('PASS: ladder ascent, descent, map freeze, release and combat restrictions coexist with the locked service lift.');

 g.start('recon',false);key('KeyQ',true);tick(.8);g.updateCamera();
 assert(state.ads>.999);assert(Math.abs(g.camera.fov-g.adsConfig.aimFov)<.01);
 const zoom=Math.tan(g.adsConfig.baseFov*Math.PI/360)/Math.tan(g.camera.fov*Math.PI/360);
 assert(Math.abs(zoom-2)<.001,'Sights use true 2x magnification');
 const mouse=(type,button)=>inputHandlers.get(type).forEach(fn=>fn({button,target:document.getElementById('world'),clientX:0,clientY:0}));
 mouse('mousedown',2);key('KeyQ',false);tick(.2);assert(state.ads>.99,'Releasing Q preserves a held RMB');
 mouse('mouseup',2);tick(.8);assert(state.ads<.001,'Releasing both aim controls clears zoom');
 key('KeyQ',true);tick(.8);state.ammo=35;press('KeyR');tick(.4);assert(state.ads<.01,'Reload exits ADS');
 key('KeyQ',false);tick(2);assert.equal(state.ammo,36);
 console.log('PASS: 2x sights, Q/RMB overlap and reload transitions preserve v1.8 aiming.');

 g.start('combat',false);state.time=6;
 const drone=g.enemies.find(e=>e.id==='S1'),other=g.enemies.find(e=>e.id==='H2');
 assert(drone.statusLight.materials.length>0);
 assert.notEqual(drone.statusLight.materials[0],other.statusLight.materials[0]);
 const otherColor=other.statusLight.materials[0].color.getHex();
 drone.statusLight.update('locked');assert.equal(other.statusLight.materials[0].color.getHex(),otherColor,'Alert colour is instance-local');
 drone.statusLight.update('patrol');Object.assign(drone,{x:-1,y:1.65,z:28,yaw:Math.PI});g.teleport(-1,20,0);
 assert(g.stealth.perceive(drone,player,state).seen,'Player visible ahead of S1');
 for(let i=0;i<240&&!drone.engaged;i++){state.time+=1/60;g.updateEnemies(1/60);}
 assert(drone.engaged&&drone.statusLight.state==='locked');assert.equal(drone.patrolState,'PURSUING');
 const before={x:drone.x,z:drone.z};g.updateEnemies(.05);
 assert(Math.hypot(drone.x-before.x,drone.z-before.z)>drone.route.speed*.05*1.4,'Confirmed lock accelerates pursuit');
 const known={...drone.lastKnown};g.teleport(-20,-7,0);
 assert(!g.stealth.perceive(drone,player,state).seen,'Tunnel breaks sight');g.updateEnemies(.1);
 assert.equal(drone.charge,0,'Cover cancels firing charge');assert.deepEqual(drone.lastKnown,known,'Hidden player does not update last seen position');
 assert.equal(drone.statusLight.state,'locked','Red persists in contact search');
 console.log('PASS: independent drone alert colours, faster pursuit, and cover breaking the firing charge.');

 g.start('recon',false);assert.equal(g.humanWorld.tags.length,1);
 assert.equal(g.humanObjectives.status().tagsRequired,1);
 const tag=g.humanWorld.tags[0];g.teleport(-24.2,-42.45,.28);
 const resolved=g.resolvePosition(player.x,player.z);
 assert(Math.hypot(resolved.x-player.x,resolved.z-player.z)<.01,'Graffiti approach clears the NIVALIS SYSTEMS container wall');
 const view=face(tag);assert.equal(g.humanObjectives.nearest(player,view)?.kind,'tag','Graffiti is reachable inside NIVALIS SYSTEMS');
 const origin=new THREE.Vector3(player.x,player.y+player.height,player.z);
 serviceLift.shell.parent.updateMatrixWorld(true);
 const ray=new THREE.Raycaster(origin,view,0,origin.distanceTo(new THREE.Vector3(tag.x,tag.y,tag.z))-.08);
 assert.equal(ray.intersectObjects([serviceLift.shell,serviceLift.cab],true).length,0,'Rendered lift parts must not hide the tag from its approach');
 key('KeyE',true);g.interact(3.1);assert(g.humanObjectives.status().achievements.eyesOff,'One tag awards Eyes Off');
 g.level.terminals.forEach(t=>t.done=true);serviceLift.unlock();g.teleport(4,-67,.406);player.yaw=0;player.pitch=0;
 g.interact(2);assert.equal(serviceLift.mode,'ready','Held spray interaction cannot chain into a descent');
 key('KeyE',false);g.interact(.01);key('KeyE',true);g.interact(1.1);key('KeyE',false);
 assert.equal(serviceLift.mode,'closing','A fresh E press boards the lift normally');
 console.log('PASS: single-container Eyes Off objective is reachable, and requires a fresh E press before descent.');
 g.start('recon',false);assert(!state.climbing&&serviceLift.mode==='locked');
}
