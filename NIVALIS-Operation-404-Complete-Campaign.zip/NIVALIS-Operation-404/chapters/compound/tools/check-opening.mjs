import assert from 'node:assert/strict';

// Run through the real game boot in check-lift.mjs --opening.
export function checkOpening({g,tick}){
 const {state,player,stealth}=g,V=(x,y,z)=>new THREE.Vector3(x,y,z);
 const visibleTargets=()=>g.enemies.filter(e=>{
  const eye=V(player.x,player.y+player.height,player.z),delta=V(e.x,e.y+.54,e.z).sub(eye),distance=delta.length();
  return distance<135&&g.wallDistance(eye,delta.normalize(),distance+.02)>distance-.05;
 }).map(e=>e.id);
 g.start('combat',false);
 assert(g.enemies.every(e=>e.hp===63),'Do not increase drone health to pad difficulty');
 assert(stealth.metrics().every(route=>route.clear),'Every full patrol circuit must remain clear');
 const revised=visibleTargets();
 for(const e of g.enemies){[e.x,e.y,e.z]=e.route.points[0];}
 const previous=visibleTargets();
 assert(revised.length<previous.length,'Opening exposes fewer drones from the actual spawn: '+JSON.stringify({previous,revised}));
 console.log('PASS: opening targets with clear sight lines reduced from '+previous.length+' to '+revised.length+'; all eight full patrol circuits remain clear.');

 g.start('combat',false);tick(4.8);
 assert.equal(state.droneAlerts+g.security.alerts,0,'A quiet deployment is not immediately detected');
 const drone=g.enemies[0];Object.assign(drone,{x:0,y:1.65,z:16,yaw:0});
 g.teleport(0,25,0);state.time=.2;
 assert(!stealth.perceive(drone,player,state).seen,'Quiet players retain deployment grace');
 g.shoot();
 assert.equal(state.shots,1);assert(drone.interest>0,'The actual first shot is heard before five seconds');
 assert(stealth.perceive(drone,player,state).seen,'Firing ends drone vision grace');
 assert.equal(state.droneAlerts+g.security.alerts,0,'A sound is an investigation, not an automatic global alert');
 assert(drone.suspicion<1&&!g.security.compoundAlert,'A hit or gunshot still requires visual acquisition before an alarm');
 // Put the player on an unobstructed ray in the real yard camera's viewing cone.
 state.shots=0;state.time=.2;g.security.update(0,player,state);
 const watcher=g.security.cameras[0],point=watcher.eye.clone().addScaledVector(watcher.direction,5);
 Object.assign(player,{x:point.x,y:point.y-player.height*.8,z:point.z});
 g.security.update(.1,player,state);assert(!watcher.seen);
 state.shots=1;g.security.update(.1,player,state);assert(watcher.seen,'CCTV also respects the early end of grace');
 assert(watcher.suspicion>0&&watcher.suspicion<1,'CCTV still requires a readable acquisition period');
 console.log('PASS: firing ends opening grace for hearing, drone vision and CCTV without a forced alarm.');

 g.start('combat',false);state.time=6;
 const hunter=g.enemies[0];Object.assign(hunter,{x:-1,y:1.65,z:28,yaw:Math.PI,suspicion:1,reported:true,pursuitRemaining:6.5});
 g.teleport(-1,18,0);const before=V(hunter.x,hunter.y,hunter.z);
 g.updateEnemies(.05);const travelled=before.distanceTo(V(hunter.x,hunter.y,hunter.z));
 assert(Math.abs(travelled-hunter.route.speed*2*.05)<.001,'Confirmed sighting moves at double patrol speed');
 const known={...hunter.lastKnown};g.teleport(-20,-7,.28);g.updateEnemies(.1);
 assert.equal(hunter.charge,0,'Solid cover cancels firing');assert.deepEqual(hunter.lastKnown,known,'Faster pursuit must not track a hidden player');
 console.log('PASS: double patrol speed after a lock, with cover and last-known-position rules preserved.');

 g.start('recon',false);
 for(let time=0;time<360;time+=.1)for(const e of g.enemies){
  const from=V(e.x,e.y,e.z);stealth.patrol(e,.1,time);
  assert(from.distanceTo(V(e.x,e.y,e.z))<=e.route.speed*.1+.001,'No patrol teleporting');
 }
 assert(g.enemies.every(e=>e.laps>=2),'Staggered patrols keep completing their circuits');
 g.start('combat',false);assert.equal(state.shots,0);
 assert(g.enemies.every(e=>e.waypoint===(e.route.start+1)%e.route.points.length&&!e.interest&&!e.suspicion),'Restart restores the authored staggered opening');
 console.log('PASS: six-minute patrol soak and clean replay.');
 g.start('recon',false);
}
