import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
process.chdir(fileURLToPath(new URL('..',import.meta.url)));
// Preserve the compound outside the approved lift, ladder and upper-label edits.
const v18=JSON.parse(fs.readFileSync('docs/access-alert-source.json','utf8'));
const current=fs.readFileSync('engine/level.js','utf8');
const originalSignText=text=>{for(const [before,after] of [['SERVICE / 01', 'SERVICE 01'], ['CARGO / 04', 'CARGO 04'], ['LOGISTICS / 02', 'LOGISTICS 02'], ['LOADING DECK / 02', 'LOADING DECK 02'], ['09 / DRONE PAD', 'DRONE PAD 09'], ['WARDEN / 09', 'WARDEN 09'], ['SIGNAL CONTROL / N-09', 'SIGNAL CONTROL N-09'], ['HUMAN CREW / 06', 'HUMAN CREW 06'], ['N-09 / SERVICE', 'N-09 SERVICE'], ['NIVALIS / 09', 'NIVALIS 09']])text=text.replaceAll(after,before);return text;};
const originalLayout=originalSignText(current).replace("label:'SERVICE LIFT',sub:'B1 — LOWER STATION ACCESS',lights:false", "label:'EXTRACTION / 09'")
 .replace('ends=[-1,1],lights=true','ends=[-1,1]')
 .replace(/    const module=prop\('cargo_module',x,z,\{rot,scale\}\);[\s\S]*?    const sx=/,"    prop('cargo_module',x,z,{rot,scale});const sx=")
 .replace(/  \/\/ An explicit climb route[\s\S]*?(?=  const helipad=)/,'');
assert.equal(createHash('sha256').update(originalLayout).digest('hex'),v18.layout_without_ladder_and_upper_label_sha256);
const ctx={exports:{},module:{exports:{}},console};vm.runInNewContext(fs.readFileSync('vendor/three.min.js','utf8'),ctx);globalThis.THREE=ctx.exports;
const gradient={addColorStop(){}};
const drawing=new Proxy({measureText:t=>({width:String(t).length*8}),createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),createLinearGradient:()=>gradient,createRadialGradient:()=>gradient},{get:(o,k)=>k in o?o[k]:()=>{}});
globalThis.document={baseURI:new URL('../',import.meta.url).href,createElement:()=>({width:256,height:256,getContext:()=>drawing})};
globalThis.window={__NIVALIS_SURFACE_PILOT__:false};
class Element {
 constructor(){this.handlers=new Map();this.style={};this.value='';this.children=[];this.width=650;this.height=650;this.parentElement={clientWidth:500};const classes=new Set();this.classList={add:(...s)=>s.forEach(x=>classes.add(x)),remove:(...s)=>s.forEach(x=>classes.delete(x)),contains:s=>classes.has(s),toggle:(s,on)=>{on??=!classes.has(s);on?classes.add(s):classes.delete(s);}};}
 getContext(){return drawing;} addEventListener(type,handler){if(!this.handlers.has(type))this.handlers.set(type,[]);this.handlers.get(type).push(handler);} closest(){return null;} appendChild(e){this.children.push(e);} querySelector(){return new Element();} querySelectorAll(){return [];} setAttribute(){} dispatchEvent(){} matches(){return false;} getBoundingClientRect(){return {left:0,top:0,width:1400,height:900};}
}
const elements=new Map();
document.getElementById=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};document.createElement=()=>new Element();document.querySelector=selector=>document.getElementById(selector);document.querySelectorAll=()=>[];const inputHandlers=new Map();document.addEventListener=(type,fn)=>{if(!inputHandlers.has(type))inputHandlers.set(type,[]);inputHandlers.get(type).push(fn);};document.body=new Element();document.documentElement=new Element();
window.addEventListener=()=>{};globalThis.innerWidth=1400;globalThis.innerHeight=900;globalThis.devicePixelRatio=1;window.devicePixelRatio=1;
globalThis.matchMedia=q=>({matches:process.argv.includes('--reduced-motion')&&q.includes('prefers-reduced-motion')});globalThis.requestAnimationFrame=()=>{};
Object.defineProperty(globalThis,'navigator',{value:{maxTouchPoints:0},configurable:true});
globalThis.localStorage={getItem:()=>null,setItem(){}};
THREE.WebGLRenderer=class {constructor(){this.shadowMap={};this.capabilities={getMaxAnisotropy:()=>4};this.info={render:{calls:0,triangles:0}};}setPixelRatio(){}setSize(){}render(){}clearDepth(){}};

globalThis.location={search:process.argv.includes('--tour')?'?lift-preview=1':''};
document.body.dataset={chapter:'compound'};document.fonts={ready:Promise.resolve()};globalThis.ResizeObserver=class{observe(){}};
await import('../main.js');
for(let i=0;i<100&&!window.__READY__;i++)await new Promise(resolve=>setTimeout(resolve,5));
assert(window.__READY__,elements.get('error-message')?.textContent||'Game failed to boot');
const g=window.__DEBUG__,lift=g.serviceLift;
const ui=(id,type='click')=>{for(const fn of elements.get(id).handlers.get(type)||[])fn({target:elements.get(id)});};
const key=(code,on)=>{for(const fn of inputHandlers.get(on?'keydown':'keyup')||[])fn({target:elements.get('world'),code,repeat:false,preventDefault(){}});};
const tick=seconds=>{for(let i=0;i<Math.round(seconds*60)&&!g.state.over;i++)g.simulate(1/60);};
assert.deepEqual(lift.status().location,[4,-67]);
let litContainerVertices=0;const vertex=new THREE.Vector3();
lift.shell.parent.updateMatrixWorld(true);
lift.shell.parent.traverse(o=>{if(!o.isMesh||!o.material?.emissive?.getHex()||o.material.emissiveIntensity===0)return;const p=o.geometry.attributes.position;for(let i=0;i<p.count;i++){vertex.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld);if(vertex.x>0&&vertex.x<8&&vertex.y>3.8&&vertex.y<4.8&&vertex.z>-70&&vertex.z<-62)litContainerVertices++;}});
assert.equal(litContainerVertices,0,'Service lift container strips must be dark');
let otherCargoStillLit=false;g.level.prototypes.cargo_module.traverse(o=>{if(o.material?.emissive?.getHex()>0)otherCargoStillLit=true;});assert(otherCargoStillLit,'Other containers retain their original lights');
for(let i=0;i<90;i++)g.atmosphere.update(1/60,{x:4,z:-67},i/60);
assert(g.atmosphere.fills.every(l=>l.position.z!==-67),'No steady fill remains at the lift');
assert(g.level.containerLabels.filter(l=>l.z<-62&&l.x>-1&&l.x<9).every(l=>l.text==='SERVICE LIFT'),'All lift container nameplates omit the number');
console.log('PASS: unnumbered lift signs, dark container fixtures, no constant lift fill, and other cargo lights preserved.');

// Sweep the real rendered panel bounds through a complete opening. They must
// fit the hollow pockets and never pass through the retained building/cab walls.
const leaves=lift.cab.children.filter(o=>o.name.startsWith('Lift door '));
assert.equal(leaves.length,4);
const wallBoxes=g.level.colliders.filter(c=>c.type==='wall'||c.type==='lift-wall').map(c=>new THREE.Box3(new THREE.Vector3(c.x-c.w/2,c.minY,c.z-c.d/2),new THREE.Vector3(c.x+c.w/2,c.maxY,c.z+c.d/2)));
lift.unlock();
for(let frame=0;frame<=110;frame++){
 lift.cab.updateMatrixWorld(true);
 const bounds=leaves.map(o=>new THREE.Box3().setFromObject(o));
 for(const b of bounds){
  assert(b.min.x>=4-2.78&&b.max.x<=4+2.78,'Door extends outside its cassette');
  assert(b.min.z>-67+1.57&&b.max.z<-67+2.17,'Door touches a pocket cover');
  for(const wall of wallBoxes)assert(!b.intersectsBox(wall),'Moving door intersects a compound or cabin wall');
 }
 for(let a=0;a<bounds.length;a++)for(let b=a+1;b<bounds.length;b++){
  const overlap=bounds[a].clone().intersect(bounds[b]).getSize(new THREE.Vector3());
  assert(Math.min(overlap.x,overlap.y,overlap.z)<.0001,'Door leaves must stay in distinct tracks');
 }
 lift.update(1/60,g.player);
}
for(const [i,leaf] of leaves.entries()){const b=new THREE.Box3().setFromObject(leaf);assert(i<2?b.max.x<4-1.79:b.min.x>4+1.79,'Open leaves must be concealed behind pocket covers');}
lift.reset();
console.log('PASS: four telescoping panels clear all walls and remain inside their covered tracks throughout opening.');
// The visible tube and emitted light fade together; distant shaft lights do not.
let bulb;lift.cab.traverse(o=>{if(o.material?.name==='Cabin amber strip')bulb=o.material;});
const lamp=lift.cab.children.find(o=>o.isPointLight);assert(bulb&&lamp);
const shaftGlow=[];lift.shaft.traverse(o=>{if(o.material?.emissiveIntensity)shaftGlow.push([o.material,o.material.emissiveIntensity]);});
let dimmest=Infinity,brightest=0,blackoutFrames=0,longestBlackout=0;
for(let frame=0;frame<600;frame++){lift.update(1/60,g.player);dimmest=Math.min(dimmest,lamp.intensity);brightest=Math.max(brightest,lamp.intensity);blackoutFrames=lamp.intensity<.06?blackoutFrames+1:0;longestBlackout=Math.max(longestBlackout,blackoutFrames);assert(Math.abs(lamp.intensity/1.85-bulb.emissiveIntensity/.95)<1e-8,'Tube and emitted light must flicker together');}
if(process.argv.includes('--reduced-motion'))assert(dimmest===1.85&&brightest===1.85,'Reduced motion keeps the light steady');
else {assert(dimmest<.04&&brightest>1.8,'A failing strip must drop almost completely out and recover');assert(longestBlackout>=20,'Blackouts must persist long enough to be clearly visible');}
for(const [m,intensity] of shaftGlow)assert.equal(m.emissiveIntensity,intensity,'Only the cabin strip flickers');
lift.reset();
console.log('PASS: '+(process.argv.includes('--reduced-motion')?'steady reduced-motion light':'irregular cabin flicker')+' synchronises the bulb and light while shaft lamps stay steady.');

ui('explore');
const tour=process.argv.includes('--tour');
if(tour){assert.equal(g.state.liftPreview,true);assert.equal(g.player.z,-59);assert.equal(lift.mode,'ready');assert(g.level.terminals.every(t=>!t.done));}
else{
 assert.equal(lift.mode,'locked');
 g.teleport(4,-67,.406);key('KeyE',true);g.interact(2);key('KeyE',false);assert.equal(lift.mode,'locked');assert(!g.state.won);
 for(const [i,t] of g.level.terminals.entries()){
  g.teleport(t.x,t.z,t.y);key('KeyE',true);g.interact(1.7);key('KeyE',false);assert(t.done,'Terminal must isolate through real interaction');assert.equal(lift.mode,i===2?'ready':'locked');
 }
 g.teleport(4,-59,0);g.player.yaw=0;
}
// Real movement must reach the cabin through its original entrance.
tick(2);key('KeyE',true);tick(1.2);key('KeyE',false);assert.equal(lift.mode,'ready','Cannot depart from outside');
key('KeyW',true);tick(1.7);key('KeyW',false);assert(lift.inCab(g.player),'Walk to the cabin without teleporting or crossing solid walls: '+JSON.stringify({x:g.player.x,y:g.player.y,z:g.player.z,near:g.level.colliders.filter(c=>Math.hypot(c.x-g.player.x,c.z-g.player.z)<4)}));
const outside=lift.shell.parent.children.filter(o=>o!==lift.cab&&o!==lift.shaft).map(o=>[o,o.visible]);
key('KeyE',true);tick(1.2);key('KeyE',false);assert.equal(lift.mode,'closing');assert(!g.state.over,'Boarding alone does not finish the chapter');
const ammo=g.state.ammo;g.shoot();assert.equal(g.state.ammo,ammo,'No shooting during descent');
tick(2);assert.equal(lift.mode,'descending');assert(lift.shaft.visible);assert(!lift.shell.visible);assert(outside.every(([o])=>!o.visible),'Daylight and the outdoor scene are hidden only after closure');
const height=g.player.y;key('KeyW',true);tick(1);key('KeyW',false);assert(g.player.y<height,'Cabin and player descend together');assert.equal(g.player.y,lift.cab.position.y);assert(!g.state.over);
tick(10);assert.equal(lift.mode,'arrived');assert.equal(g.player.y,.406-18);assert(g.state.won);assert.match(elements.get('pause-description').textContent,/B1|lower station/);
lift.reset();for(const [o,visible] of outside)assert.equal(o.visible,visible,'Lift reset restores exterior visibility');
ui('restart');assert(!g.state.over);assert.equal(lift.mode,tour?'ready':'locked');assert.equal(lift.cab.position.y,.406);assert(!lift.shaft.visible);assert(lift.shell.visible);assert.equal(g.level.terminals.filter(t=>t.done).length,0);
if(tour){ui('deploy');assert(!g.state.liftPreview);assert.equal(lift.mode,'locked');assert.equal(g.player.z,g.level.spawn.z);}
console.log('PASS: '+(tour?'tour':'mission')+' unlock, unchanged location, collision-safe boarding, hold-E, 18 m descent, B1 arrival and replay.');
if(process.argv.includes('--opening'))await (await import('./check-opening.mjs')).checkOpening({g,key,tick,ui,elements,inputHandlers});
if(process.argv.includes('--access-alert'))await (await import('./check-access-alert.mjs')).checkAccessAlert({g,key,tick,ui,elements,inputHandlers});
if(process.argv.includes('--compound-combat'))await (await import('./check-compound-combat.mjs')).checkCompoundCombat({g,key,tick,ui,elements,inputHandlers});
if(process.argv.includes('--compound-route'))await (await import('./check-compound-route.mjs')).checkCompoundRoute({g,key,tick,elements});
