#!/usr/bin/env node
/** Local asset contract checker. Not the upstream 404 verifier. No dependencies. */
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),ctx={exports:{},module:{exports:{}},console};
vm.runInNewContext(fs.readFileSync(path.join(root,'vendor/three.min.js'),'utf8'),ctx);const THREE=ctx.exports;
function inspect(group){
 assert(group?.isGroup,'Generator must return a THREE.Group');group.updateMatrixWorld(true);
 const bounds=new THREE.Box3(),v=new THREE.Vector3(),instanceMatrix=new THREE.Matrix4(),worldMatrix=new THREE.Matrix4();let meshes=0,triangles=0;const materials=new Set();
 group.traverse(o=>{if(!o.isMesh)return;meshes++;const p=o.geometry?.attributes?.position;assert(p?.count,'Mesh must contain vertices');
 const count=o.isInstancedMesh?o.count:1;
 assert(Number.isInteger(count)&&count>0,'Instance count must be positive');
 for(let instance=0;instance<count;instance++){
  if(o.isInstancedMesh){o.getMatrixAt(instance,instanceMatrix);worldMatrix.multiplyMatrices(o.matrixWorld,instanceMatrix);}else worldMatrix.copy(o.matrixWorld);
  for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i).applyMatrix4(worldMatrix);assert([v.x,v.y,v.z].every(Number.isFinite),'Nonfinite transformed vertex');bounds.expandByPoint(v);}
 }
 triangles+=((o.geometry.index?.count||p.count)/3)*count;for(const m of (Array.isArray(o.material)?o.material:[o.material])){assert(m?.isMeshStandardMaterial,'Code assets use MeshStandardMaterial');materials.add(m.uuid);assert(!m.map&&!m.normalMap&&!m.bumpMap,'Code asset must not load texture maps');}
 assert(o.castShadow&&o.receiveShadow,'Mesh shadow flags must be explicit');});
 assert(meshes>0,'No renderable meshes');const size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());assert(size.x>.01&&size.y>.01&&size.z>.01,'Degenerate asset extent');assert(Math.abs(bounds.min.y)<.001,'Base must be Y=0');assert(Math.abs(center.x)<.001&&Math.abs(center.z)<.001,'Asset must be centered X/Z');
 return {meshes,triangles,materials:materials.size,dimensions_m:size.toArray().map(n=>+n.toFixed(4)),min:bounds.min.toArray().map(n=>+n.toFixed(6)),max:bounds.max.toArray().map(n=>+n.toFixed(6))};
}
const report={checker:'NIVALIS: OPERATION 404 local vertex-exact asset checks, not upstream harness',threeRevision:THREE.REVISION,assets:[],fixtures:[],passed:true};
for(const name of fs.readdirSync(path.join(root,'assets')).filter(n=>n.endsWith('.js')).sort()){
 const filename=path.join(root,'assets',name),code=fs.readFileSync(filename,'utf8');assert(!/^\s*import\s/m.test(code),`${name}: asset has imports`);
 const {default:generate}=await import(pathToFileURL(filename));const group=generate(THREE),r=inspect(group);report.assets.push({name:name.slice(0,-3),...r});console.log(name,r.dimensions_m,'m',r.triangles,'triangles');
 if(name==='ramp.js'){
  const ray=new THREE.Raycaster(),heights=[];for(const z of [3,-3]){ray.set(new THREE.Vector3(0,10,z),new THREE.Vector3(0,-1,0));heights.push(ray.intersectObject(group,true)[0]?.point.y);}
  assert(heights[1]>heights[0]+1.9,'Ramp must rise toward -Z');report.rampOrientationHeights=heights;
 }
}
const createBox=()=>{const g=new THREE.Group(),m=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial());m.castShadow=m.receiveShadow=true;m.position.y=.5;g.add(m);return g;};
const fixtures=[['wrong return',()=>({})],['empty group',()=>new THREE.Group()],['floating base',()=>{const g=createBox();g.position.y=1;return g;}],['off-center',()=>{const g=createBox();g.position.x=1;return g;}],['nonfinite vertices',()=>{const g=createBox();g.children[0].geometry.attributes.position.array[0]=NaN;return g;}]];
for(const [name,fn]of fixtures){let caught=false;try{inspect(fn());}catch{caught=true;}assert(caught,`Checker missed fixture ${name}`);report.fixtures.push({name,caught});}
inspect(createBox());report.fixtures.push({name:'valid grounded control',accepted:true});
const instances=new THREE.Group(),im=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial(),2);
im.castShadow=im.receiveShadow=true;im.setMatrixAt(0,new THREE.Matrix4().makeTranslation(-3,.5,0));im.setMatrixAt(1,new THREE.Matrix4().makeTranslation(3,.5,0));instances.add(im);
const ir=inspect(instances);assert.equal(ir.dimensions_m.join(','),'7,1,1');assert.equal(ir.triangles,24);report.fixtures.push({name:'instance matrices and multiplied triangle count',accepted:true,result:ir});
im.setMatrixAt(1,new THREE.Matrix4().makeTranslation(NaN,.5,0));let rejected=false;try{inspect(instances);}catch{rejected=true;}assert(rejected);report.fixtures.push({name:'nonfinite instance matrix rejected',caught:true});
fs.mkdirSync(path.join(root,'docs/qa'),{recursive:true});fs.writeFileSync(path.join(root,'docs/qa/asset-report.json'),JSON.stringify(report,null,2)+'\n');console.log('PASS:',report.assets.length,'selected assets, ramp orientation,',report.fixtures.length,'checker fixtures.');
