import assert from 'node:assert/strict';

// Behavioral checks use the imported game, actual shooting/collision/perception,
// and controlled positions for individual cases. The route check below starts
// from the real spawn and uses movement/interaction inputs with live actors.
export function checkCompoundCombat({g,tick,key,elements}){
  const {player,state,stealth,security}=g,V=(x,y,z)=>new THREE.Vector3(x,y,z);
  const face=e=>{const dx=e.x-player.x,dz=e.z-player.z,dy=e.y+.54-player.y-player.height;player.yaw=Math.atan2(-dx,-dz);player.pitch=Math.atan2(dy,Math.hypot(dx,dz));state.ads=1;};
  g.start('combat',false);
  const target=g.enemies[0],before=V(target.x,target.y,target.z);
  face(target);g.shoot();assert.equal(target.hp,40,'Actual rifle hit deals the same damage');
  assert(target.evasion,'Surviving opening sentry has an evasive route');
  assert(!security.compoundAlert,'Being hit is not visual identification');
  for(let i=0;i<21;i++){const from=V(target.x,target.y,target.z);state.time+=1/60;g.updateEnemies(1/60);const to=V(target.x,target.y,target.z);assert(stealth.routeClear(from,to),'Every evasive step clears the expanded body collider');assert(from.distanceTo(to)<=9/60+.001,'Evasion moves continuously');}
  assert(before.distanceTo(V(target.x,target.y,target.z))>1.2,'Evasion leaves the original firing line');
  const hp=target.hp;g.shoot();assert.equal(target.hp,hp,'Repeating the original aim misses the displaced sentry');
  assert(!security.compoundAlert,'A distant inaccurate burst does not invent a visual lock');
  console.log('PASS: live rifle hit, unchanged health, visible collision-safe evasion, and stationary follow-up aim misses.');

  g.start('combat',false);const isolated=g.enemies[0];
  for(let shot=0;shot<3;shot++){face(isolated);g.shoot();if(shot<2)tick(.12);}
  assert(!isolated.alive&&state.kills===1,'Tracking the evasive target still permits a three-shot takedown');
  assert(!security.compoundAlert&&state.droneAlerts+security.alerts===0,'An isolated accurate takedown remains undetected');
  console.log('PASS: an accurate isolated takedown is still possible without a confirmed alert.');

  // A visible attack can be investigated without revealing the unseen shooter.
  g.start('combat',false);state.time=6;state.shots=1;
  const victim=g.enemies[0],witness=g.enemies[2];
  Object.assign(victim,{x:-1,y:1.65,z:19,hp:0});
  Object.assign(witness,{x:-1,y:1.7,z:10,yaw:0,interest:0});
  stealth.hit([victim,witness],victim,V(4,1.78,38),state);
  assert(witness.interest>0);assert.equal(witness.lastKnown.z,19,'Witness investigates the victim, not the shooter');assert(!security.compoundAlert);
  witness.interest=0;witness.yaw=Math.PI;
  stealth.hit([victim,witness],victim,V(4,1.78,38),state);
  assert.equal(witness.interest,0,'A witness facing away cannot see an attack');
  console.log('PASS: witnessed attacks cause local investigation; unseen attacks do not disclose the shooter.');

  g.start('combat',false);state.time=6;
  const reporter=g.enemies[0];Object.assign(reporter,{x:-1,y:1.65,z:28,yaw:Math.PI});g.teleport(-1,20);
  for(let i=0;i<240&&!security.compoundAlert;i++){state.time+=1/60;g.updateEnemies(1/60);}
  assert(security.compoundAlert&&state.droneAlerts>0,'Actual visual acquisition latches compound alarm');
  g.updateEnemies(1/60);assert(g.enemies.every(e=>e.alerted),'Every patrol receives the report, including distant sentries');
  const known={...security.lastKnown};reporter.alive=false;reporter.group.visible=false;
  g.teleport(-20,-7,.28);state.shots=0;player.speed=0;
  for(let i=0;i<1800;i++){state.time+=1/60;security.update(1/60,player,state);g.updateEnemies(1/60);}
  assert(security.compoundAlert,'Thirty seconds without contact cannot reset a confirmed alarm');
  assert.deepEqual(security.lastKnown,known,'No report tracks a player hidden inside the service tunnel');
  assert(g.enemies.filter(e=>e.alive).every(e=>e.alerted&&e.charge===0&&!e.engaged),'Alerted drones cannot charge through solid cover');
  for(const c of security.cameras)security.disableZone(c.id);
  assert(security.compoundAlert,'Disabling all uplinks cannot erase a sentry broadcast');
  g.updateHUD();assert.equal(elements.get('security-label').textContent,'COMPOUND ALERT');
  assert.equal(elements.get('security-detail').textContent,'PATROLS REMAIN ALERT · USE COVER');
  const version=security.contactVersion;
  security.reportContact('S2',known,state);assert(security.contactVersion>version,'Fresh contact at an old position broadcasts again after contact was lost');
  console.log('PASS: confirmed sentry lock alerts all patrols, survives reporter death/uplink cuts, and does not track through cover.');

  g.start('combat',false);state.time=6;security.update(0,player,state);
  const watcher=security.cameras[0],spot=watcher.eye.clone().addScaledVector(watcher.direction,5);
  Object.assign(player,{x:spot.x,y:spot.y-player.height*.8,z:spot.z});
  for(let i=0;i<180&&!security.compoundAlert;i++)security.update(1/60,player,state);
  assert(security.compoundAlert&&security.alerts===1,'Actual CCTV dwell, not a debug alarm, latches detection');
  security.hit(watcher,100);g.updateEnemies(1/60);assert(g.enemies.every(e=>e.alerted));
  security.disableZone(watcher.id);assert(security.compoundAlert,'Destroying or isolating reporting CCTV preserves alert');
  g.start('combat',false);assert(!security.compoundAlert&&security.contactVersion===0);
  assert(g.enemies.every(e=>!e.alerted&&!e.evasion&&!e.evasionCooldown),'Restart clears all reactions');
  g.start('recon',false);face(g.enemies[0]);g.shoot();tick(.5);
  assert(!security.compoundAlert&&g.enemies.every(e=>!e.alerted&&!e.evasion),'Explore remains non-hostile');
  console.log('PASS: CCTV confirmation, camera destruction, HUD persistence, clean restart and peaceful Explore.');
}
