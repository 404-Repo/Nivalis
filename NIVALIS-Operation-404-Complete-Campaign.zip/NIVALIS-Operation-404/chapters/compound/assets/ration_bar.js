// NIVALIS / Chocobar. Clean paper sleeve and thin folded foil, four exposed squares.
// Y up; metre scale; centered X/Z and grounded. Print is supplied by the game.
export default function generate(THREE){
 const g=new THREE.Group();g.name='ration_bar';
 const mat=(color,roughness,metalness=0)=>{const m=new THREE.MeshStandardMaterial({color,roughness,metalness});m.color.convertSRGBToLinear();return m;};
 const orange=mat(0xb65b32,.82),cocoa=mat(0x573321,.48),dark=mat(0x40261b,.6);
 const foil=mat(0xd5d8d5,.4,.35),fold=mat(0xadb5b5,.46,.4);foil.side=fold.side=THREE.DoubleSide;
 function add(geo,m,x,y,z,name){const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.name=name;o.castShadow=o.receiveShadow=true;g.add(o);return o;}
 function slab(w,d,h,r,b,x,y,z,m,name){
  const hw=w/2-b,hd=d/2-b,rr=Math.max(.0002,r-b),s=new THREE.Shape();
  s.moveTo(-hw+rr,-hd);s.lineTo(hw-rr,-hd);s.quadraticCurveTo(hw,-hd,hw,-hd+rr);
  s.lineTo(hw,hd-rr);s.quadraticCurveTo(hw,hd,hw-rr,hd);s.lineTo(-hw+rr,hd);
  s.quadraticCurveTo(-hw,hd,-hw,hd-rr);s.lineTo(-hw,-hd+rr);s.quadraticCurveTo(-hw,-hd,-hw+rr,-hd);s.closePath();
  const geo=new THREE.ExtrudeGeometry(s,{depth:h-2*b,steps:1,curveSegments:3,bevelEnabled:true,bevelThickness:b,bevelSize:b,bevelSegments:2});
  geo.translate(0,0,b);geo.rotateX(-Math.PI/2);return add(geo,m,x,y,z,name);
 }
 function sheet(rows,m,name){
  const p=[],idx=[],cols=rows[0].length;rows.forEach(row=>row.forEach(v=>p.push(...v)));
  for(let j=0;j<rows.length-1;j++)for(let i=0;i<cols-1;i++){const a=j*cols+i,b=a+1,c=a+cols,d=c+1;idx.push(a,c,b,b,c,d);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(p,3));geo.setIndex(idx);geo.computeVertexNormals();
  return add(geo,m,0,0,0,name);
 }
 // One continuous chocolate base; the sleeve conceals the left-hand portion.
 slab(.302,.108,.014,.004,.0015,0,.002,0,dark,'chocolate-base');
 for(const x of [.065,.115])for(const z of [-.026,.026]){
  slab(.047,.049,.015,.004,.002,x,.014,z,cocoa,'chocolate-square');
 }
 // Foil follows the chocolate's sides and turns inward below the upper edge.
 // It has no detached bottom sheet, end flap or raised tray rim.
 for(const side of [-1,1]){
  const rows=[];
  for(const [height,width]of [[.003,.053],[.006,.056],[.020,.056],[.027,.054]]){
   rows.push([[-.149,height,side*width],[.026,height,side*width],[.148,height,side*width]]);
  }
  sheet(rows,foil,'foil-side-wrap');
 }
 // A single folded-back collar between sleeve and chocolate. Broad, shallow
 // changes of angle supply a soft highlight without a corrugated/blocky border.
 sheet([
  [[-.020,.030,-.056],[-.020,.030,0],[-.020,.030,.056]],
  [[.009,.031,-.055],[.011,.032,0],[.009,.031,.055]],
  [[.029,.030,-.054],[.031,.031,0],[.029,.030,.054]],
  [[.034,.033,-.054],[.035,.034,0],[.034,.033,.054]],
  [[.036,.030,-.054],[.037,.030,0],[.036,.030,.054]]
 ],foil,'foil-fold');
 // The orange paper band has the same height and rounded corners as the bar.
 slab(.161,.119,.031,.004,.0015,-.073,0,0,orange,'paper-sleeve');
 // Thin folded return on the paper's open edge makes the seam read as paper.
 sheet([[[.0075,.028,-.058],[.0075,.029,0],[.0075,.028,.058]],[[.009,.027,-.055],[.009,.028,0],[.009,.027,.055]]],fold,'foil-seam');
 const print=add(new THREE.PlaneGeometry(.137,.101),mat(0xb65b32,.84),-.074,.0312,0,'wrapper-print');print.rotation.x=-Math.PI/2;
 g.updateMatrixWorld(true);const bounds=new THREE.Box3(),v=new THREE.Vector3();
 g.traverse(o=>{if(o.isMesh){const p=o.geometry.attributes.position;for(let i=0;i<p.count;i++)bounds.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld));}});
 const center=bounds.getCenter(new THREE.Vector3());for(const o of g.children){o.position.x-=center.x;o.position.y-=bounds.min.y;o.position.z-=center.z;}
 return g;
}
