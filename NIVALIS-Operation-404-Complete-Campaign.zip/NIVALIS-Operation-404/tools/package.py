#!/usr/bin/env python3
"""Package a reproducible, clean delivery without hosting credentials or QA shortcuts."""
from pathlib import Path
import hashlib, json, sys, zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'final-delivery/NIVALIS-Operation-404-Complete-Campaign.zip'
OUT.parent.mkdir(parents=True,exist_ok=True)
entries=[]
for name in ['README.md','QA.md','PLAY.html','index.html','style.css','campaign.js','campaign-state.js','title-audio.js','package.json','assets','chapters','tools','dist']:
    p=ROOT/name
    files=sorted(p.rglob('*')) if p.is_dir() else [p]
    entries.extend(f for f in files if f.is_file() and not any(part in {'.DS_Store','__pycache__','.git','.openai','artifacts','development'} for part in f.relative_to(ROOT).parts) and f.suffix!='.pyc')
entries=sorted(set(entries))
checksums={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in entries}
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in entries:
        info=zipfile.ZipInfo('NIVALIS-Operation-404/'+str(file.relative_to(ROOT)),(2026,9,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,file.read_bytes())
    info=zipfile.ZipInfo('NIVALIS-Operation-404/SHA256SUMS.json',(2026,9,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,json.dumps(checksums,indent=2)+'\n')
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for name,sha in checksums.items(): assert hashlib.sha256(z.read('NIVALIS-Operation-404/'+name)).hexdigest()==sha
digest=hashlib.sha256(OUT.read_bytes()).hexdigest()
OUT.with_suffix('.zip.sha256').write_text(digest+'  '+OUT.name+'\n')
print(f'{OUT}\n{len(entries)} files; {OUT.stat().st_size:,} bytes\nSHA256 {digest}')
