# NIVALIS: OPERATION 404

Beyond the last transmission, the compound is still listening. Descend beneath the ice. Find what keeps it awake.

A cel-shaded first-person campaign through a frozen outpost, a buried control station and an awakened failsafe. Three chapters form one continuous operation: COMPOUND, LOWER STATION and WARDEN.

## Play

Open **PLAY.html** in a desktop browser with WebGL enabled. It contains the complete game, fonts and synthesized audio. If local-file restrictions affect pointer capture or saved progress, run `node tools/serve.mjs` and open `http://localhost:8080/`.

WASD moves; the mouse or trackpad controls the camera. Left-click fires, right-click or Q aims, E interacts, R reloads, C crouches and Escape pauses. The pause menu includes controls and accessibility/audio settings. Difficulty defaults to HARD. Audio starts on the first interaction if the browser blocks autoplay.

Progress and settings stay in the current browser. Checkpoints resume at chapter boundaries; they do not synchronize between devices or hosted copies. The cel edition uses separate saved progress from the original edition.

## Contents

- `dist/`: ready-to-host static website; upload its contents for the smallest web deployment.
- `PLAY.html`: self-contained offline player.
- `chapters/`, root JavaScript/CSS and `assets/`: editable game source.
- `tools/`: dependency-free build, validation, local serving and packaging tools.
- `licenses/` and `THIRD_PARTY_NOTICES.txt`: bundled third-party notices.
- `QA.md`: verification scope and limitations.

The root `index.html` also runs the campaign from the included `dist/chapters/`. The `/game/` entry point redirects to the campaign. No server-side application, account, API key, telemetry service or externally hosted asset is required.

## Build and check

Use Python 3 and a current Node.js. No package installation is needed.

```sh
python3 tools/build.py
node tools/check.mjs
python3 tools/package.py
```

`npm run build`, `npm test` and `npm run package` run the same commands. One shared bundler embeds each chapter's module graph, models and fonts. `release-manifest.json` explicitly lists the files allowed in the delivery. Add new release inputs to this list deliberately; temporary files are never included automatically.

The packager validates a temporary archive before replacing the delivery ZIP, includes `SHA256SUMS.json` and writes a separate ZIP checksum. ZIP timestamps and permissions are normalized; comments, extended metadata and symlinks are excluded.

## Before publishing source

Review the staged files and your Git commit identity. A ZIP has no Git history. Updating an existing repository does not remove identifying information from its older commits.

The optional pre-push guard checks outgoing Git objects, nested delivery archives and author/committer identities. To use it, copy `.privacy-policy.example.json` to `.privacy-policy.json`, fill the arrays with your chosen public alias and GitHub private email, then run `git config --local core.hooksPath .githooks`. The actual identity policy is ignored and must stay local. Credentials, hosting configuration, development previews and delivery archives are also ignored.

The privacy scanner checks known credential formats, personal filesystem paths, private configuration files and archive metadata, including embedded chapter code. It is a focused safeguard rather than a guarantee against every possible disclosure.

## Art and credits

Cel Edition 1.1.9 includes the approved snow silhouettes, painted bunker surfaces, varied service containers/tanks, clearer dark prop materials, subtle moving skies, outlined carbine and graphic signage/uplink screens. The campaign retains its authored layout, controls and gameplay.

Version 1.1.9 also corrects depth sampling precision in the outline pass to address mobile floor striping. Devices without high-precision fragment support retain cel lighting with the depth-outline pass omitted.

Atlas supplied concept references and art direction. The geometry, canvas artwork, shaders and audio are implemented locally. See `THIRD_PARTY_NOTICES.txt` for Three.js, the 404 game recipe adaptation and the bundled typeface licenses.
