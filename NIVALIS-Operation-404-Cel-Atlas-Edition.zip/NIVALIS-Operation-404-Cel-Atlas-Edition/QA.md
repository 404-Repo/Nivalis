# Cel Edition 1.1.8 — Release verification

This delivery contains the approved three-chapter cel campaign. Release cleanup affects packaging, build tooling and documentation; the playable chapter payloads and offline player are checked against the approved build.

## Automated checks

Passed for the release candidate on 21 September 2026: all supported checks, 88 asset configurations, 71 protected runtime sources and 12 privacy regression tests. The three embedded chapter files and PLAY.html match the approved 1.1.8 payloads byte-for-byte.

Run `node tools/check.mjs` after `python3 tools/build.py`.

- Campaign ordering, duplicate completion, checkpoints, invalid saves and bounded settings.
- Embedded module resolution, JavaScript syntax and portable resource completeness.
- Title/pause audio lifecycle, including delayed autoplay and rapid pause/resume.
- Asset geometry, finite normals, retained scenery bounds, fixed placements/colliders and matching Compound/Warden variants.
- Protected gameplay, controls, audio, UI and renderer source fingerprints.
- Lower Station prerequisite orders, puzzle recovery/hints, shutdown sequencing and bounded lighting.
- Credential/path patterns, private filenames, encoded modules, nested archives, symlinks, normalized ZIP metadata and outgoing Git identities using synthetic test data.

## Delivery scope

Source, offline player, static website, necessary tests/build tools and third-party licenses are included. Review pages, design studies, backups, screenshots, historical QA logs, obsolete standalone chapter checks, unused Warden music, Git history, hosting metadata and the local identity policy are excluded.

The source folder and static upload both retain applicable third-party notices. The manifest restricts delivery contents and checksums cover every packaged file other than the checksum manifest itself.

## Limits

Prior visual review covered Compound, Lower Station and Warden and normal campaign startup. This packaging pass is not a new uninterrupted combat/puzzle playthrough, physical trackpad hardware test or GPU benchmark. Browser autoplay and local-file restrictions may require a first interaction or the included local server. The privacy scan is focused and cannot prove the absence of every possible secret.

No GitHub push, release publication or public deployment is part of this delivery preparation.
