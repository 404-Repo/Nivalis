# Cel Edition 1.1.10 — Release verification

This delivery contains the approved three-chapter cel campaign with mobile touch-input and depth-precision corrections. The three outline shaders explicitly request high-precision depth sampling. Devices without high-precision fragment support retain the cel material lighting and omit depth outlines. Version 1.1.10 adds a shared touch-look controller, explicit gesture blocking and touch-generated mouse filtering. Level layout, assets, objectives and combat/puzzle logic are unchanged.

## Automated checks

Passed for the release candidate on 21 September 2026: all supported checks, 88 asset configurations, 74 protected runtime sources and 12 privacy regression tests. Fingerprints for the touched input code, campaign cache keys and shell stylesheet were updated after reviewing the targeted changes; the new shared touch helpers are also protected. The previous renderer correction is retained. The three embedded chapters and PLAY.html are rebuilt from this source. Chapter cache keys are updated for returning players.

Run `node tools/check.mjs` after `python3 tools/build.py`.

- Campaign ordering, duplicate completion, checkpoints, invalid saves and bounded settings.
- Embedded module resolution, JavaScript syntax and portable resource completeness.
- Title/pause audio lifecycle, including delayed autoplay and rapid pause/resume.
- Fresh right/left touch gestures, direction reversals, independent pointer ownership, capture loss/cancellation, pause/resume, native gesture suppression and touch/trackpad separation.
- Asset geometry, finite normals, retained scenery bounds, fixed placements/colliders and matching Compound/Warden variants.
- Protected gameplay, controls, audio, UI and renderer source fingerprints.
- Lower Station prerequisite orders, puzzle recovery/hints, shutdown sequencing and bounded lighting.
- Credential/path patterns, private filenames, encoded modules, nested archives, symlinks, normalized ZIP metadata and outgoing Git identities using synthetic test data.

## Delivery scope

Source, offline player, static website, necessary tests/build tools and third-party licenses are included. Review pages, design studies, backups, screenshots, historical QA logs, obsolete standalone chapter checks, unused Warden music, Git history, hosting metadata and the local identity policy are excluded.

The source folder and static upload both retain applicable third-party notices. The manifest restricts delivery contents and checksums cover every packaged file other than the checksum manifest itself.

## Mobile rendering verification

A controlled test quantized sampled depth to reproduce horizontal floor stripes similar to the Samsung Internet report. The high-precision candidate produced no floor contrast jumps in the same flat-ground test for Compound, Lower Station or Warden, while retaining object silhouettes. The compatibility fallback also rendered cleanly. All three complete chapter builds started and rendered in the local desktop browser without shader or console errors.

This simulation isolates a likely failure mechanism; it is not Samsung hardware emulation. Confirmation on the affected Samsung device remains outstanding.

## Touch-input verification

All 33 browser fixture checks passed across the three complete chapter builds. Tests cover right-first and left-first swipes, a fresh right swipe after release, centre-right canvas input, additional fingers, cancellation, paused input and a right swipe after resuming. The controller also passed unit checks for native touchstart prevention, ownership, disposal and compatibility mouse events.

The browser fixture uses synthetic touch events and coarse-pointer configuration; it does not reproduce Samsung Internet’s native gesture recognizer. Confirmation on the affected Samsung device remains outstanding. No handset model or browser version was supplied.

## Limits

Visual checks covered Compound, Lower Station and Warden startup and the outline effect. This targeted rendering pass is not a new uninterrupted combat/puzzle playthrough, physical trackpad hardware test or GPU benchmark. Browser autoplay and local-file restrictions may require a first interaction or the included local server. The privacy scan is focused and cannot prove the absence of every possible secret.
