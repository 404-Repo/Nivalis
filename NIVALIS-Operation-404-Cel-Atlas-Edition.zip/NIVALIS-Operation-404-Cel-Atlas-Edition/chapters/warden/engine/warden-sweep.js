// A committed lane: warnings and damage share these exact floor targets.
// Nothing follows the player after the warning begins.
export const SWEEP = Object.freeze({ warning:2.8, duration:3.2, count:9, spacing:2, radius:1.35 });
export function makeWardenSweep(scene, floorAt) {
  const group=new THREE.Group();group.name='Warden sweep lane';group.visible=false;
  const geometry=new THREE.RingGeometry(1.23,SWEEP.radius,24),markers=[];
  for(let i=0;i<SWEEP.count;i++){
    const m=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:0xffdf86,side:THREE.DoubleSide,transparent:true,opacity:.7,depthWrite:false}));
    m.rotation.x=-Math.PI/2;group.add(m);markers.push(m);
  }
  const cursor=new THREE.Mesh(new THREE.RingGeometry(.3,.48,16),new THREE.MeshBasicMaterial({color:0xfff6d0,side:THREE.DoubleSide,depthWrite:false}));
  cursor.rotation.x=-Math.PI/2;group.add(cursor);scene.add(group);
  let targets=[];
  return {
    begin(origin,player){
      const dx=player.x-origin.x,dz=player.z-origin.z,length=Math.hypot(dx,dz)||1;
      targets=markers.map((m,i)=>{
        const offset=(i-(SWEEP.count-1)/2)*SWEEP.spacing;
        const x=player.x+dz/length*offset,z=player.z-dx/length*offset;
        const target=new THREE.Vector3(x,floorAt(x,z,player.y)+.06,z);
        m.position.copy(target);return target;
      });group.visible=true;this.update(0,false);
    },
    update(progress,firing){
      markers.forEach((m,i)=>{m.material.opacity=firing&&i<progress*(SWEEP.count-1)?.13:.75;});
      if(targets.length){cursor.position.lerpVectors(targets[0],targets[targets.length-1],firing?progress:0);cursor.position.y+=.015;cursor.scale.setScalar(firing?1:1+progress*2);}
    },
    target(index){return targets[index].clone();},
    hide(){group.visible=false;},
    get targets(){return targets.map(p=>p.toArray());}
  };
}
