// Six persistent voices plus two modulation oscillators; no per-frame voices.
const FLIGHT_VOICES=[[91,.085,'sawtooth'],[97,.078,'sawtooth'],[46,.08,'triangle'],[191,.026,'square']];
export class WardenAudio {
 constructor(ctx,bus){
  this.ctx=ctx;this.sources=[];this.filter=ctx.createBiquadFilter();this.filter.type='lowpass';this.filter.frequency.value=2400;
  this.pan=ctx.createStereoPanner();this.gain=ctx.createGain();this.gain.gain.value=0;this.filter.connect(this.pan);this.pan.connect(this.gain);this.gain.connect(bus);
  this.rotor=ctx.createGain();this.rotor.gain.value=.48;this.rotor.connect(this.filter);
  for(const [freq,gain,type] of FLIGHT_VOICES){const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.value=freq;g.gain.value=gain;o.connect(g);g.connect(this.rotor);o.start();this.sources.push(o);}
  this.warningFilter=ctx.createBiquadFilter();this.warningFilter.type='lowpass';this.warningFilter.Q.value=.65;this.warningFilter.frequency.value=2400;this.warningFilter.connect(this.pan);
  this.warning=ctx.createGain();this.warning.gain.value=0;this.warning.connect(this.warningFilter);
  for(const f of [480,720]){const o=ctx.createOscillator();o.type='sine';o.frequency.value=f;o.connect(this.warning);o.start();this.sources.push(o);}
  // Close wing pitches beat against one another; flutter and pitch drift make
  // the mechanical swarm feel agitated instead of like a steady synth note.
  this.flutter=ctx.createOscillator();this.flutter.type='triangle';this.flutter.frequency.value=23;
  this.flutterDepth=ctx.createGain();this.flutterDepth.gain.value=.085;this.flutter.connect(this.flutterDepth);this.flutterDepth.connect(this.rotor.gain);
  this.warble=ctx.createOscillator();this.warble.type='sine';this.warble.frequency.value=4.7;
  this.warbleDepth=ctx.createGain();this.warbleDepth.gain.value=2.1;this.warble.connect(this.warbleDepth);
  for(const source of this.sources.slice(0,2))this.warbleDepth.connect(source.frequency);
  for(const source of [this.flutter,this.warble]){source.start();this.sources.push(source);}
 }
 update({boss,listener,occluded=false}){
  if(!boss||!listener)return;const t=this.ctx.currentTime,dx=boss.position[0]-listener.x,dz=boss.position[2]-listener.z,dist=Math.hypot(dx,dz,boss.position[1]-listener.y),side=dx*Math.cos(listener.yaw)-dz*Math.sin(listener.yaw);
  this.pan.pan.setTargetAtTime(Math.max(-.95,Math.min(.95,side/Math.max(6,Math.hypot(dx,dz)))),t,.09);
  this.gain.gain.setTargetAtTime((boss.rotorPower||0)*Math.max(.12,1/(1+dist*.055))*(occluded?.55:1),t,.12);
  const power=boss.rotorPower||0,overload=boss.phase===3?1.14:1;
  this.filter.frequency.setTargetAtTime(occluded?420:850+power*650,t,.15);
  for(let i=0;i<4;i++)this.sources[i].frequency.setTargetAtTime(FLIGHT_VOICES[i][0]*(.5+power*.5)*overload,t,.18);
  this.flutter.frequency.setTargetAtTime((12+power*11)*overload,t,.18);
 }
 cue(kind,seconds){
  const t=this.ctx.currentTime,g=this.warning.gain,strike=kind==='strike',sweep=kind==='sweep',duration=Math.max(.2,seconds);
  g.cancelScheduledValues(t);g.setValueAtTime(0,t);
  g.linearRampToValueAtTime(strike?.095:.045,t+.04);
  g.linearRampToValueAtTime(strike?.15:.19,t+duration-.12);g.linearRampToValueAtTime(0,t+duration);
  const cutoff=this.warningFilter.frequency;cutoff.cancelScheduledValues(t);cutoff.setValueAtTime(strike?2400:240,t);
  cutoff.exponentialRampToValueAtTime(strike?2400:620,t+duration);
  // Low, slightly detuned harmonics build pressure as the gold beam locks on.
  // Ground strikes retain their distinct, higher warning pitch.
  for(let i=4;i<6;i++){
   const oscillator=this.sources[i],f=oscillator.frequency,ratio=i===4?1:strike?1.5:1.513;
   oscillator.type=strike?'sine':i===4?'triangle':'sawtooth';
   f.cancelScheduledValues(t);f.setValueAtTime((strike?330:sweep?92:58)*ratio,t);
   f.exponentialRampToValueAtTime((strike?1050:sweep?185:112)*ratio,t+duration);
  }
 }
 cancel(){this.warning.gain.cancelScheduledValues(this.ctx.currentTime);this.warning.gain.setTargetAtTime(0,this.ctx.currentTime,.025);}
 dispose(){for(const source of this.sources){source.stop();source.disconnect();}this.filter.disconnect();this.pan.disconnect();this.gain.disconnect();this.rotor.disconnect();this.warning.disconnect();this.warningFilter.disconnect();this.flutterDepth.disconnect();this.warbleDepth.disconnect();}
}
