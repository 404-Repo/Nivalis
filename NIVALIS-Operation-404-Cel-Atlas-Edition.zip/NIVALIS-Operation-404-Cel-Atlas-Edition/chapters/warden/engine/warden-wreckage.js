import { ASSET, bakeStatic } from './assets.js';

// Break up the original patrol asset before baking. Every fragment gets its own
// contact height; a rotated whole-drone bounding box leaves empty air underneath.
export async function makePatrolWreckage(scene, level) {
  const source = await ASSET('drone', { keepHierarchy:true });
  const wrecks = new THREE.Group(), fragments = [], materials = new Map();
  const sites = [[-6,12,0],[7,1,0],[-20,-18,0],[21,-14,3.27],[21,-26,3.27],[0,-29,0],[-10,-44,0],[9,-58,0]];
  const buckets = new Map(['hull','plate','sensor','weapon','aerial','rotor0','rotor1','rotor2','rotor3'].map(k=>[k,[]]));
  const point = new THREE.Vector3();
  source.updateMatrixWorld(true);
  source.traverse(mesh=>{
    if(!mesh.isMesh)return;
    const center = new THREE.Box3().setFromObject(mesh).getCenter(new THREE.Vector3());
    let key = 'hull';
    if(Math.abs(center.x)>.32)key='rotor'+((center.x>0?2:0)+(center.z>0?1:0));
    else if(center.y>.69)key='aerial';
    else if(center.y>.56&&mesh.geometry.type==='BoxGeometry')key='plate';
    else if(center.y<.20)key='weapon';
    else if(center.z>.43)key='sensor';
    buckets.get(key).push(mesh);
  });
  function charred(original){
    if(!materials.has(original)){
      const m=original.clone();m.color.multiplyScalar(.53);m.roughness=.96;m.metalness=.24;
      if(m.emissive)m.emissive.set(0);m.emissiveIntensity=0;materials.set(original,m);
    }
    return materials.get(original);
  }
  const local=(x,z,s)=>({x:(x-s.x)*Math.cos(s.angle)-(z-s.z)*Math.sin(s.angle),z:(x-s.x)*Math.sin(s.angle)+(z-s.z)*Math.cos(s.angle)});
  function floorAt(x,z,limit){
    let y=-.025;
    for(const s of level.surfaces){const p=local(x,z,s);if(s.y<=limit+.35&&Math.abs(p.x)<s.w/2&&Math.abs(p.z)<s.d/2)y=Math.max(y,s.y);}
    return y;
  }
  function free(x,z,y,radius){
    return !level.colliders.some(c=>{
      if(c.maxY<=y+.04||c.minY>=y+.75)return false;
      const p=local(x,z,c);return Math.abs(p.x)<c.w/2+radius&&Math.abs(p.z)<c.d/2+radius;
    });
  }
  function vertexBounds(group){
    group.updateMatrixWorld(true);const bounds=new THREE.Box3();
    group.traverse(m=>{if(!m.isMesh)return;const p=m.geometry.attributes.position;
      for(let j=0;j<p.count;j++)bounds.expandByPoint(point.fromBufferAttribute(p,j).applyMatrix4(m.matrixWorld));
    });return bounds;
  }
  function settle(piece,x,z,y,kind,site){
    const center=vertexBounds(piece).getCenter(new THREE.Vector3());
    // Center the unrotated contents, then rotate the fragment around itself.
    piece.children.forEach(m=>m.position.sub(center));
    const i=fragments.length,rotor=kind.startsWith('rotor');
    piece.rotation.set(kind==='aerial'?Math.PI/2:rotor?.025:.08,site*.81+i*1.91,rotor?.035:.07*(i%3-1));
    piece.scale.set(.92,kind==='hull'?.58:rotor?.48:.92,.92);
    piece.position.set(x,0,z);
    const bounds=vertexBounds(piece),floor=floorAt(x,z,y);
    piece.position.y=floor-bounds.min.y+.002;
    const grounded=vertexBounds(piece);
    fragments.push({site,kind,x,z,floor,minY:grounded.min.y,maxY:grounded.max.y});
    wrecks.add(piece);
    const contact=new THREE.Mesh(new THREE.PlaneGeometry(grounded.max.x-grounded.min.x+.25,grounded.max.z-grounded.min.z+.25),scarMaterial);
    contact.rotation.x=-Math.PI/2;contact.position.set((grounded.min.x+grounded.max.x)/2,floor+.004,(grounded.min.z+grounded.max.z)/2);wrecks.add(contact);
  }
  const scarCanvas=document.createElement('canvas');scarCanvas.width=scarCanvas.height=64;
  const ctx=scarCanvas.getContext('2d'),gradient=ctx.createRadialGradient(32,32,3,32,32,31);
  gradient.addColorStop(0,'rgba(0,0,0,.82)');gradient.addColorStop(.44,'rgba(0,0,0,.48)');gradient.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,64,64);
  const scarMaterial=new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(scarCanvas),color:0x20191b,transparent:true,opacity:.68,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1});
  const shardMaterial=new THREE.MeshStandardMaterial({color:0x435057,roughness:.95,metalness:.28,side:THREE.DoubleSide});
  sites.forEach(([x,z,y],site)=>{
    let index=0;
    for(const [kind,meshes] of buckets){
      if(!meshes.length)continue;
      const piece=new THREE.Group();piece.name=kind;
      for(const original of meshes){
        const mesh=original.clone();mesh.material=charred(original.material);mesh.castShadow=true;mesh.receiveShadow=true;
        if(mesh.geometry.type==='TorusGeometry'){
          const p=mesh.geometry.parameters;
          mesh.geometry=new THREE.TorusGeometry(p.radius,p.tube,p.radialSegments,p.tubularSegments,Math.PI*(1.25+(site%3)*.14));
        }
        piece.add(mesh);
      }
      const angle=index*2.399+site*.74,reach=kind==='hull'?0:1.15+(index%3)*.48;
      let px=x+Math.cos(angle)*reach,pz=z+Math.sin(angle)*reach;
      if(y>0){px=21+Math.cos(angle)*.9;pz=z+Math.sin(angle)*reach*1.4;}
      for(let attempt=0;attempt<16&&!free(px,pz,floorAt(px,pz,y),.30);attempt++){
        const a=angle+attempt*.61;px=x+Math.cos(a)*(reach+.5);pz=z+Math.sin(a)*(reach+.5);
        if(y>0)px=21+Math.cos(a)*.9;
      }
      settle(piece,px,pz,y,kind,site);index++;
    }
    // Torn metal chips and a dark impact patch tie the separated parts to snow.
    for(let j=0;j<5;j++){
      const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute([-.14,0,-.08,.17,.015,-.04,.08,.045,.13,-.14,0,-.08,.08,.045,.13,-.07,.015,.08],3));geo.computeVertexNormals();
      const mesh=new THREE.Mesh(geo,shardMaterial),piece=new THREE.Group();piece.add(mesh);
      const angle=j*2.13+site*.83,reach=.65+j*.22;
      let px=x+Math.cos(angle)*reach,pz=z+Math.sin(angle)*reach;if(y>0)px=21+Math.cos(angle)*.8;
      if(free(px,pz,floorAt(px,pz,y),.17))settle(piece,px,pz,y,'shard',site);
    }
    const scar=new THREE.Mesh(new THREE.PlaneGeometry(y>0?2.1:3.5,3.6),scarMaterial);scar.rotation.x=-Math.PI/2;scar.position.set(x,floorAt(x,z,y)+.004,z);wrecks.add(scar);
  });
  const group=bakeStatic(wrecks);group.name='Disabled patrol / scattered grounded wreckage';scene.add(group);
  return {group,fragments,sites};
}
