import { ASSET, bakeStatic } from './assets.js';
import { WardenState } from './warden-state.js';
import { makePatrolWreckage } from './warden-wreckage.js';
import { makeSign } from './environment.js';
import { makeWardenPresentation } from './warden-presentation.js';
import { makeWardenSweep, SWEEP } from './warden-sweep.js';

const v = (x=0,y=0,z=0) => new THREE.Vector3(x,y,z);
const clamp = (n,a,b) => Math.max(a,Math.min(b,n));

// Chapter 03 returns from B1. Keep the shared compound layout and lift fixed.
export const getWardenSpawn = level => ({x:level.extraction.x,z:level.extraction.z+4.25,y:0,yaw:Math.PI});

export async function makeWarden(scene, level, { wallDistance, floorAt=(_x,_z,y)=>y, fire, escorts, notify, audio, onDefeat }) {
  const rules = new WardenState(), rig = new THREE.Group();
  rig.name = 'WARDEN / autonomous defense';
  const tree = await ASSET('heavy_drone', { keepHierarchy:true });
  const fans = new Map();
  // Preserve the supplied silhouette. Only the existing fan blades articulate.
  for (const blade of [...tree.children]) if (blade.name === 'stationary rotor blade') {
    const key = `${blade.position.x}:${blade.position.z}`;
    if (!fans.has(key)) { const group = new THREE.Group(); group.position.copy(blade.position); fans.set(key,group); }
    const group = fans.get(key); tree.remove(blade); blade.position.sub(group.position); group.add(blade);
  }
  // Original armour panels and optics articulate; the source model is shared unchanged.
  const panels=[], optics=[];
  const offset=tree.userData.originAdjustment||{x:0,y:0,z:0};
  for(const side of [-1,1]){
    const panel=new THREE.Group();panel.position.set(side*1.18,2.25+offset.y,-.03+offset.z);
    for(const part of [...tree.children])if(Math.abs(part.position.x-side*1.325)<.035&&Math.abs(part.position.y-(1.99+offset.y))<.12){tree.remove(part);part.position.sub(panel.position);panel.add(part);}
    const id=makeSign('WARDEN 09',{width:1.07,height:.16,bg:'#283640',color:'#c8d4d4'});id.position.set(side*1.352,2.025,-.02).sub(panel.position);id.rotation.y=side*Math.PI/2;panel.add(id);rig.add(panel);panels.push({group:panel,side});
  }
  const copies=new Map();tree.traverse(o=>{if(o.isMesh&&o.material?.emissive?.getHex()>0){if(!copies.has(o.material)){const m=o.material.clone();copies.set(o.material,m);optics.push(m);}o.material=copies.get(o.material);}});
  const body=bakeStatic(tree);const shell=[];body.traverse(o=>{if(o.isMesh&&o.material?.color&&!o.material.emissive?.getHex()){const source=o.material;o.material=source.clone();o.material.onBeforeCompile=source.onBeforeCompile;o.material.customProgramCacheKey=source.customProgramCacheKey;shell.push({material:o.material,color:source.color.clone()});}});rig.add(body);
  const rotors = [];
  for (const fan of fans.values()) {
    const position = fan.position.clone(); fan.position.set(0,0,0);
    const baked = bakeStatic(fan); baked.position.copy(position); rig.add(baked); rotors.push(baked);
  }
  const coreMaterial = new THREE.MeshStandardMaterial({ color:0x71e9ed, emissive:0x39d8e8, emissiveIntensity:1.2, metalness:.45, roughness:.3 });
  const core = new THREE.Mesh(new THREE.SphereGeometry(.62,16,12), coreMaterial);
  core.position.set(0,.88,.35); core.scale.set(1,.62,1.3); core.userData.weakpoint=true; rig.add(core);
  const guns=[];
  for (const x of [-.92,.92]) {
    const gun = new THREE.Mesh(new THREE.CylinderGeometry(.105,.14,1.0,10),new THREE.MeshStandardMaterial({color:0x27333d,metalness:.8,roughness:.5}));
    gun.rotation.x=Math.PI/2; gun.position.z=.35;const mount=new THREE.Group();mount.position.set(x,1.05,1.72);mount.add(gun);rig.add(mount);guns.push(mount);
  }
  rig.traverse(o=>{ if(o.isMesh){o.castShadow=false;o.receiveShadow=true;} }); scene.add(rig);
  const ray = new THREE.Raycaster(), beam = new THREE.Line(new THREE.BufferGeometry().setFromPoints([v(),v()]),new THREE.LineBasicMaterial({color:0xffee9b,transparent:true,opacity:1}));
  beam.name='Warden targeting beam';beam.frustumCulled=false;beam.visible=false;scene.add(beam);
  const beamTube=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,1,6),new THREE.MeshBasicMaterial({color:0xffedb2,transparent:true,opacity:.85,depthWrite:false}));beamTube.name='Warden targeting beam volume';beamTube.visible=false;scene.add(beamTube);
  const marker = new THREE.Mesh(new THREE.RingGeometry(2.8,3.0,48),new THREE.MeshBasicMaterial({color:0xffe184,side:THREE.DoubleSide,transparent:true,opacity:1,depthWrite:false}));
  marker.rotation.x=-Math.PI/2;marker.visible=false;scene.add(marker);

  // Converging chevrons and a shrinking ring communicate the strike without flashing.
  const countdown=new THREE.Mesh(new THREE.RingGeometry(2.86,3.0,48),marker.material.clone());countdown.rotation.x=-Math.PI/2;countdown.visible=false;scene.add(countdown);
  const arrows=new THREE.Group();const warningMat=marker.material;
  for(let i=0;i<8;i++){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute([-.28,0,3.5,.28,0,3.5,0,0,3.08],3));const m=new THREE.Mesh(g,warningMat);m.rotation.y=i*Math.PI/4;arrows.add(m);}scene.add(arrows);arrows.visible=false;
  const presentation=makeWardenPresentation(scene,rig,level);
  const sweep=makeWardenSweep(scene,floorAt);let sweepShot=0;
  const searchlight=new THREE.SpotLight(0x9de9eb,0,70,.18,.8,1.4);
  searchlight.name='Warden launch searchlight';scene.add(searchlight,searchlight.target);
  const wreckage=await makePatrolWreckage(scene,level);

  // Attach warning lamps to existing structures; no new buildings or blockers.
  const lamps=[];
  for(const [x,y,z] of [[-17.2,3.5,3.7],[18.9,4.4,-2.3],[6.2,5.2,-6.8],[7.2,4.9,-62.7]]) {
    const housing=new THREE.Mesh(new THREE.CylinderGeometry(.22,.25,.12,12),new THREE.MeshStandardMaterial({color:0x30363b,metalness:.6,roughness:.7}));housing.position.set(x,y,z);scene.add(housing);
    const bulb=new THREE.Mesh(new THREE.SphereGeometry(.17,12,8),new THREE.MeshBasicMaterial({color:0xff4836}));bulb.position.set(x,y+.17,z);scene.add(bulb);
    const light=new THREE.PointLight(0xff3828,0,9,2);light.position.copy(bulb.position);scene.add(light);lamps.push({bulb,light});
  }
  let elapsed=0, mode='idle', timer=0, cycle=0, burst=0, shotTimer=0, acquired=false, lastKnown=v(4,1.7,38), lockedTarget=v(), strikeTarget=v(), deathTime=0;
  let recoil=0,impactDone=false,rotorPower=0;const previous=v(),velocity=v(),deathStart=v();
  let lastPhase=1, spawned=false, seen=false, reducedFlash=false, started=false;
  const phaseNames=['','ACQUISITION','RECOVERY','OVERLOAD'];
  const eye=()=>rig.localToWorld(v(0,1.0,2.15));
  const isClear=(from,to)=>{const delta=to.clone().sub(from),length=delta.length();return wallDistance(from,delta.normalize(),length+.05)>length-.1;};
  const vulnerable=()=>mode==='cooling'||mode==='repair';
  function enter(next,seconds){if(['aim','strike','sweep-aim'].includes(mode))audio.cancelBossWarning?.();mode=next;timer=seconds;if(next!=='launch')searchlight.intensity=0;beam.visible=beamTube.visible=false;marker.visible=countdown.visible=arrows.visible=false;if(!next.startsWith('sweep'))sweep.hide();}
  function reset(){
    presentation.reset();shell.forEach(s=>s.material.color.copy(s.color));rotors.forEach(r=>r.rotation.y=0);recoil=0;impactDone=false;rotorPower=0;panels.forEach(p=>p.group.rotation.z=0);optics.forEach(m=>m.emissiveIntensity=.12);
    rules.reset();elapsed=0;cycle=0;burst=0;shotTimer=0;sweepShot=0;searchlight.intensity=0;lastPhase=1;spawned=false;seen=false;acquired=false;started=false;deathTime=0;
    const spawn=getWardenSpawn(level);lastKnown.set(spawn.x,1.7,spawn.z);rig.position.set(0,level.helipad.y,-13);rig.rotation.set(0,-.18,0);rig.visible=true;
    enter('idle',0);rig.updateMatrixWorld(true);
  }
  function start(){reset();started=true;enter('launch',12);audio.alarm();}
  function updateLights(time,active){
    const level=active?(reducedFlash?.45:.2+.8*Math.pow((Math.sin(time*3.3)+1)/2,3)):.05;
    for(const lamp of lamps){lamp.light.intensity=level*2.2;lamp.bulb.material.color.setRGB(1,.13+level*.16,.07);}
  }
  function update(dt,player,state){
    if(!started)return;elapsed+=dt;const recon=state.mode==='recon';
    updateLights(elapsed,!rules.defeated);
    previous.copy(rig.position);recoil=Math.max(0,recoil-dt*3.5);
    if(rules.defeated){
      deathTime+=dt;const travel=clamp(deathTime/2.7,0,1),ease=travel*travel*(3-2*travel);
      rig.position.lerpVectors(deathStart,v(0,level.helipad.y,-13),ease);
      rig.rotation.z=Math.sin(deathTime*5)*.22*(1-travel);rig.rotation.x=.12*Math.sin(travel*Math.PI);
      if(travel===1&&!impactDone){impactDone=true;presentation.impact();audio.bossImpact?.();notify('WARDEN offline. Failsafe neutralized.','DEFENSE SYSTEM OFFLINE',8);}
      rotors.forEach((r,i)=>r.rotation.y+=dt*Math.max(0,34-deathTime*12)*(i%2?1:-1));
      rotorPower=Math.max(0,1-deathTime/2.7);coreMaterial.emissiveIntensity=0;optics.forEach(m=>m.emissiveIntensity=0);
      presentation.update(dt,{elapsed,mode,phase:rules.phase,defeated:true,deathTime,rotorPower,reducedFlash});return;
    }
    timer-=dt;rotorPower=mode==='launch'?clamp((elapsed-.8)/4.2,0,1):1;
    rotors.forEach((rotor,i)=>{const power=mode==='launch'?clamp((elapsed-.6-i*.62)/2.4,0,1):1;rotor.rotation.y+=dt*(rules.phase===3?46*(i===2?.62+.14*Math.sin(elapsed*6):1):34)*power*(i%2?1:-1);});
    const target=v(player.x,player.y+player.height*.65,player.z),from=eye();
    seen=mode!=='launch'&&isClear(from,target);
    if(seen){lastKnown.copy(target);acquired=true;}
    if(rules.phase!==lastPhase){
      lastPhase=rules.phase;audio.alarm();
      if(rules.phase===2){enter('return',0);notify('WARDEN returning to its pad. Hit the amber reactor to interrupt repairs.','PHASE 02 / RECOVERY',7);}
      else {cycle=0;enter('hunt',1.8);notify('Repair system destroyed. Gold sweep lanes and ground strikes incoming.','PHASE 03 / OVERLOAD',5);}
    }
    if(mode==='launch'){
      // Rise from the original pad, then cross the visible gap beside the mast.
      // The player keeps control, but acquisition waits until the reveal ends.
      const lift=clamp((elapsed-3.1)/3.6,0,1),ease=lift*lift*(3-2*lift);
      const crossing=clamp((elapsed-6.7)/3.8,0,1),slide=crossing*crossing*(3-2*crossing);
      rig.position.set(-11*slide,level.helipad.y+(17-level.helipad.y)*ease,-13-7*slide);
      searchlight.position.copy(eye());
      const sx=-12+Math.sin(elapsed*.65)*8,sz=-42+Math.cos(elapsed*.4)*7;
      searchlight.target.position.set(sx,floorAt(sx,sz,0),sz);searchlight.intensity=1.8*clamp((elapsed-3)/3,0,1);
      if(timer<=0){searchlight.intensity=0;enter('hunt',2);notify('Break the gold targeting beam with cover. Shoot the blue core during cooling.','WARDEN ACTIVE',6);}
    } else if(mode==='return'){
      rig.position.lerp(v(0,10,-13),1-Math.exp(-dt*1.0));
      if(rig.position.distanceTo(v(0,10,-13))<.35&&rules.beginRepair()){
        enter('repair',8);if(!spawned&&!recon){escorts(rig.position.clone());spawned=true;}
      }
    } else if(mode==='repair'){
      rules.update(dt);
      if(!rules.repairing){enter('cooling',rules.interrupted?10:6);notify(rules.interrupted?'Repair interrupted. Core exposed.':'Repair cycle exhausted. Core exposed.', 'DAMAGE WINDOW',4);}
    } else {
      // Circling follows the last visible position; shelter never gives wall hacks.
      const angle=elapsed*(rules.phase===3?.34:.23);
      const desired=v(clamp(lastKnown.x+Math.cos(angle)*13,-25,25),16+Math.sin(elapsed*.7)*.35,clamp(lastKnown.z+Math.sin(angle)*12,-62,35));
      if(mode==='hunt'){
        const move=desired.clone().sub(rig.position),distance=move.length(),step=Math.min(distance,dt*(rules.phase===3?7:5));
        if(distance>.01){const direction=move.normalize();if(wallDistance(rig.position.clone().add(v(0,1.5,0)),direction,step+4.3)>step+4.2)rig.position.addScaledVector(direction,step);else rig.position.y=Math.min(19,rig.position.y+dt*3);}
      }
      if(mode==='hunt'&&timer<=0&&seen&&!recon){
        if(rules.phase===3&&cycle%2===0){
          enter('sweep-aim',SWEEP.warning);sweepShot=0;sweep.begin(eye(),player);
          notify('Gold sweep lane marked. Leave the line or get behind solid cover.','SWEEP INCOMING',SWEEP.warning);audio.bossWarning?.('sweep',SWEEP.warning);
        }else if(rules.phase===3){
          strikeTarget.set(player.x,floorAt(player.x,player.z,player.y)+.06,player.z);marker.position.copy(strikeTarget);enter('strike',2.3);marker.visible=true;
          notify('Ground strike marked. Move out of the ring.','INCOMING',2.3);audio.bossWarning?.('strike',2.3);
        }else{enter('aim',state.difficulty==='veteran'?1.0:1.5);audio.bossWarning?.('aim',timer);}
      } else if(mode==='aim'){
        if(!seen){enter('hunt',1);}
        else {lockedTarget.copy(target);beam.visible=true;
          if(timer<=0){enter('burst',0);burst=rules.phase===3?5:3;shotTimer=0;}}
      } else if(mode==='burst'){
        shotTimer-=dt;
        if(shotTimer<=0&&burst>0){
          // Aim locks at the end of the warning. Sprinting defeats the burst.
          fire(eye(),lockedTarget,{speed:rules.phase===3?31:25,damage:state.difficulty==='classic'?9:state.difficulty==='veteran'?20:15});burst--;shotTimer=.19;
        }
        if(burst<=0){cycle++;enter('cooling',rules.phase===3?5:4);}
      } else if(mode==='sweep-aim'){
        sweep.update(clamp(1-timer/SWEEP.warning,0,1),false);
        if(timer<=0)enter('sweep',SWEEP.duration);
      } else if(mode==='sweep'){
        const progress=clamp(1-timer/SWEEP.duration,0,1);sweep.update(progress,true);
        // Each shot uses the same swept wall collision and sheltered blast checks
        // as a ground strike. The lane never retargets during its traverse.
        while(sweepShot<SWEEP.count&&progress+1e-6>=sweepShot/(SWEEP.count-1)){
          const end=sweep.target(sweepShot++);
          if(isClear(eye(),end))fire(eye(),end,{speed:30,damage:state.difficulty==='classic'?18:32,splash:SWEEP.radius});
        }
        if(timer<=0){cycle++;enter('cooling',5.5);}
      } else if(mode==='strike'){
        marker.material.opacity=1;countdown.visible=arrows.visible=true;countdown.position.copy(strikeTarget);countdown.position.y+=.02;arrows.position.copy(strikeTarget);arrows.position.y+=.03;countdown.scale.setScalar(Math.max(.08,timer/2.3));
        if(timer<=0){if(isClear(eye(),strikeTarget))fire(eye(),strikeTarget,{speed:30,damage:state.difficulty==='classic'?22:38,splash:3.0});cycle++;enter('cooling',5.5);}
      } else if(mode==='cooling'&&timer<=0){enter('hunt',rules.phase===3?1.0:2.0);}
    }
    const yaw=Math.atan2(lastKnown.x-rig.position.x,lastKnown.z-rig.position.z);
    if(mode!=='launch')rig.rotation.y+=Math.atan2(Math.sin(yaw-rig.rotation.y),Math.cos(yaw-rig.rotation.y))*Math.min(1,dt*2);
    coreMaterial.color.set(mode==='repair'?0x493019:vulnerable()?0x102b38:0x30434a);
    coreMaterial.emissive.set(mode==='repair'?0xff9b13:vulnerable()?0x00bbee:0x132b31);
    coreMaterial.emissiveIntensity=vulnerable()?1.05:.25;const c=vulnerable()?1.1:.8;core.scale.set(c,.62*c,1.3*c);
    velocity.copy(rig.position).sub(previous).divideScalar(Math.max(dt,.001));
    const side=velocity.x*Math.cos(rig.rotation.y)-velocity.z*Math.sin(rig.rotation.y),fore=velocity.x*Math.sin(rig.rotation.y)+velocity.z*Math.cos(rig.rotation.y);
    const wobble=rules.phase===3?Math.sin(elapsed*4.7)*.032:Math.sin(elapsed*1.4)*.009;
    rig.rotation.z+=(clamp(-side*.025,-.17,.17)+wobble+recoil*.055-rig.rotation.z)*Math.min(1,dt*3);
    rig.rotation.x+=(clamp(fore*.018,-.12,.12)+recoil*.035-rig.rotation.x)*Math.min(1,dt*3);
    if(mode==='launch'&&elapsed<3.1){rig.rotation.z=rig.rotation.x=0;}
    for(const panel of panels){const open=mode==='repair'?1.1:rules.phase===3?.42:0;panel.group.rotation.z+=(-panel.side*open-panel.group.rotation.z)*Math.min(1,dt*3);}
    shell.forEach(s=>s.material.color.copy(s.color).multiplyScalar(rules.phase===3?.72:1));
    optics.forEach(m=>{m.emissiveIntensity=mode==='launch'?.12+clamp((elapsed-.5)/2,0,1)*1.5:1.7;m.emissive.set(rules.phase===3?0xff733b:0x70e4f0);});
    const local=rig.worldToLocal(target.clone());for(const gun of guns){const d=local.clone().sub(gun.position);gun.rotation.x=-Math.atan2(d.y,Math.hypot(d.x,d.z));gun.rotation.y=clamp(Math.atan2(d.x,d.z),-.5,.5);}
    presentation.update(dt,{elapsed,mode,phase:rules.phase,defeated:false,deathTime,rotorPower,reducedFlash});
    rig.updateMatrixWorld(true);
    beamTube.visible=beam.visible;
    if(beam.visible){
      // The warning reaches the supporting floor, including while jumping.
      // Keep projectile aim at the torso and clip the visible beam against cover.
      const source=eye(),end=v(player.x,floorAt(player.x,player.z,player.y)+.025,player.z);
      const direction=end.clone().sub(source),length=direction.length();direction.normalize();
      const reach=Math.max(0,Math.min(length,wallDistance(source,direction,length)));
      end.copy(source).addScaledVector(direction,reach);
      const positions=beam.geometry.attributes.position;
      positions.setXYZ(0,source.x,source.y,source.z);positions.setXYZ(1,end.x,end.y,end.z);positions.needsUpdate=true;
      beamTube.position.copy(source).add(end).multiplyScalar(.5);beamTube.scale.y=Math.max(.001,reach);
      beamTube.quaternion.setFromUnitVectors(v(0,1,0),direction);
    }
  }
  function hitTest(origin,direction,maxDistance){
    if(!started||rules.defeated||mode==='launch')return null;
    ray.set(origin,direction);ray.far=maxDistance;const hit=ray.intersectObject(rig,true)[0];
    return hit?{distance:hit.distance,weak:hit.object.userData.weakpoint===true&&vulnerable()}:null;
  }
  function hit(result){
    if(!result||rules.defeated)return;
    recoil=result.weak?1:.3;presentation.hit();const repairing=mode==='repair';rules.hit(result.weak?60:8,result.weak&&repairing);
    if(rules.defeated){deathStart.copy(rig.position);enter('destroyed',0);audio.kill();coreMaterial.emissive.set(0);onDefeat();}
  }
  function status(){return {id:'warden-aftermath',health:Math.ceil(rules.health),maxHealth:rules.maxHealth,phase:rules.phase,phaseName:phaseNames[rules.phase],mode,defeated:rules.defeated,settled:impactDone,victoryReady:rules.defeated&&deathTime>=6.2,rotorPower,warningSeconds:['aim','strike','sweep-aim'].includes(mode)?Math.max(0,timer):0,sweepTargets:mode.startsWith('sweep')?sweep.targets:[],repairing:rules.repairing,healed:Math.round(rules.healed),interrupted:rules.interrupted,vulnerable:vulnerable(),seen,acquired,position:rig.position.toArray()};}
  reset();
  return {rules,rig,wreckage,reset,start,update,hit,hitTest,status,setReducedFlashing(value){reducedFlash=!!value;},idle(time){if(!started)updateLights(time,false);}};
}
