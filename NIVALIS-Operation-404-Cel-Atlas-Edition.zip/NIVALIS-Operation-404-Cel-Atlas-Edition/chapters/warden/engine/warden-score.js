/* WARDEN / Redline — original combat composition, synthesized locally.
 * Dry sixteenth-note ostinatos, Phrygian tension, pulsed sub-bass and drums.
 * Fixed voice pools; all notes use the AudioContext clock, never frame time.
 */
export class WardenCombatScore {
  constructor(context,destination,{seed=0x9044}={}) {
    this.ctx=context;this.seed=seed>>>0;this.nodes=[];this.sources=[];this.pending=[];
    this.voices=[];this.arps=[];this.disposed=false;this.bossPhase=1;this.bpm=128;
    this.beat=60/this.bpm;this.step=0;this.played=0;this.skipped=0;this.transitions=0;
    this.lastTick=-Infinity;this.duckUntil=-Infinity;this.tension=0;this.lookahead=.55;
    this.mix=this.gain(.83);this.duckGain=this.gain(1);this.mix.connect(this.duckGain);this.duckGain.connect(destination);
    this.highpass=this.filter('highpass',30,.6);this.body=this.filter('lowpass',2800,.65);
    this.highpass.connect(this.body);this.body.connect(this.mix);
    this.synthBus=this.gain(1);this.synthBus.connect(this.highpass);
    this.drumBus=this.gain(1);this.drumBus.connect(this.highpass);
    // A short, dark reflection leaves the rhythmic attacks intelligible.
    const echo=this.node(context.createDelay(1));echo.delayTime.value=.176;
    const echoFilter=this.filter('lowpass',1100,.5),feedback=this.gain(.16),send=this.gain(.10);
    this.synthBus.connect(echo);echo.connect(echoFilter);echoFilter.connect(feedback);feedback.connect(echo);echoFilter.connect(send);send.connect(this.highpass);
    this.makeLayer('Motor sequence',8,'sawtooth',.18,-.22);
    this.makeLayer('Alarm counterpoint',6,'square',.10,.24);
    this.makeLayer('Pulsed sub-bass',4,'sawtooth',.24,0);
    this.kick=this.drumVoice('sine',.62);
    this.tom=this.drumVoice('triangle',.18);
    this.makeNoiseDrums();
    // Low fifths hold the tonal center quietly; the rhythm carries the score.
    this.tensionFilter=this.filter('lowpass',175,.6);this.tensionGain=this.gain(.025);
    this.tensionFilter.connect(this.tensionGain);this.tensionGain.connect(this.highpass);
    this.oscillator('triangle',this.frequency(38),this.tensionFilter);
    this.oscillator('sine',this.frequency(45),this.tensionFilter);
    this.epoch=context.currentTime+.10;this.nextTime=this.epoch+.06;
    for(const source of this.pending)source.start(this.epoch);
    this.pending.length=0;this.update({},this.epoch);
  }
  node(value){this.nodes.push(value);return value;}
  gain(value=1){const node=this.node(this.ctx.createGain());node.gain.value=value;return node;}
  filter(type,frequency,q=.6){const node=this.node(this.ctx.createBiquadFilter());node.type=type;node.frequency.value=frequency;node.Q.value=q;return node;}
  oscillator(type,frequency,destination){const source=this.node(this.ctx.createOscillator());source.type=type;source.frequency.value=frequency;source.connect(destination);this.sources.push(source);this.pending.push(source);return source;}
  frequency(midi){return 440*Math.pow(2,(midi-69)/12);}
  random(){this.seed=(Math.imul(this.seed,1664525)+1013904223)>>>0;return this.seed/4294967296;}
  pan(value){const node=this.node(this.ctx.createStereoPanner?this.ctx.createStereoPanner():this.ctx.createGain());if(node.pan)node.pan.value=value;return node;}
  makeLayer(name,count,type,level,pan){
    const layer={name,voices:[],level,played:0,skipped:0,interval:this.beat/4};
    for(let i=0;i<count;i++){
      const filter=this.filter('lowpass',1000,1.05),envelope=this.gain(0),panner=this.pan(pan);
      const oscillator=this.oscillator(type,110,filter);filter.connect(envelope);envelope.connect(panner);panner.connect(this.synthBus);
      const voice={oscillator,filter,envelope,freeAt:-Infinity};layer.voices.push(voice);this.voices.push(voice);
    }
    this.arps.push(layer);
  }
  drumVoice(type,level){const envelope=this.gain(0),oscillator=this.oscillator(type,60,envelope);envelope.connect(this.drumBus);return {envelope,oscillator,level};}
  makeNoiseDrums(){
    const buffer=this.ctx.createBuffer(1,this.ctx.sampleRate*2,this.ctx.sampleRate),data=buffer.getChannelData(0);
    for(let i=0;i<data.length;i++)data[i]=(this.random()*2-1)*.6;
    const source=this.node(this.ctx.createBufferSource());source.buffer=buffer;source.loop=true;this.sources.push(source);this.pending.push(source);
    this.snare={filter:this.filter('bandpass',1400,.65),envelope:this.gain(0)};
    this.hat={filter:this.filter('highpass',5600,.5),envelope:this.gain(0)};
    for(const drum of [this.snare,this.hat]){source.connect(drum.filter);drum.filter.connect(drum.envelope);drum.envelope.connect(this.drumBus);}
  }
  envelope(parameter,at,peak,length,attack=.004){
    parameter.setValueAtTime(0,at);parameter.linearRampToValueAtTime(peak,at+attack);
    parameter.exponentialRampToValueAtTime(.0001,at+length-.008);parameter.setValueAtTime(0,at+length);
  }
  note(index,midi,at,accent=1){
    const layer=this.arps[index],voice=layer.voices[layer.played%layer.voices.length];
    if(voice.freeAt>at){layer.skipped++;return;}
    const length=index===2?.18:index===1?.115:.14,phase=this.bossPhase;
    const cutoff=index===2?430+phase*110:index===1?1600+phase*350:1050+phase*250;
    voice.oscillator.frequency.setValueAtTime(this.frequency(midi),at);
    voice.filter.frequency.setValueAtTime(cutoff,at);voice.filter.frequency.exponentialRampToValueAtTime(cutoff*.32,at+length);
    const level=layer.level*accent*(phase===0?.28:1);
    this.envelope(voice.envelope.gain,at,level,length);voice.freeAt=at+length;layer.played++;
  }
  drum(drum,at,frequency,end,length,accent=1){
    drum.oscillator.frequency.setValueAtTime(frequency,at);drum.oscillator.frequency.exponentialRampToValueAtTime(end,at+length*.8);
    this.envelope(drum.envelope.gain,at,drum.level*accent,length);
  }
  schedule(step,at){
    const phase=this.bossPhase,bar=Math.floor(step/16),n=step%16;
    const root=[38,38,39,36][Math.floor(bar/2)%4];
    const motor=[0,0,7,1,0,12,7,6,0,0,7,1,12,7,6,1];
    const answer=[12,null,13,7,null,18,13,12,7,null,13,19,null,18,13,7];
    if(phase===0){if(n%8===0)this.note(2,26,at,.6);return;}
    this.note(0,root+12+motor[n],at,n%4===0?1.15:.86);
    if(n%2===0||phase===3){const degree=answer[n];if(degree!==null)this.note(1,root+degree,at,phase===1?.48:.78);}
    if(n%2===0)this.note(2,root-12+(n===10?1:n===14?7:0),at,n%4===0?1.1:.8);
    if(n%4===0||(phase>1&&n===10))this.drum(this.kick,at,116,39,.18,n===10?.65:1);
    if(n===4||n===12)this.envelope(this.snare.envelope.gain,at,.18+phase*.018,.13);
    if(n%2===0||phase===3)this.envelope(this.hat.envelope.gain,at,n%4===2?.072:.035,.034,.002);
    if(phase>1&&(n===14||n===15))this.drum(this.tom,at,n===14?105:82,45,.085,.8);
    this.played++;
  }
  setBossPhase(value){
    const phase=Math.max(0,Math.min(3,Math.floor(Number(value)||0)));
    if(phase===this.bossPhase)return;
    this.bossPhase=phase;this.bpm=[80,128,140,152][phase];this.beat=60/this.bpm;this.transitions++;
    for(const layer of this.arps)layer.interval=this.beat/4;
  }
  update({tension=0,indoor=false}={},when=this.ctx.currentTime){
    if(this.disposed||!Number.isFinite(when)||when<this.epoch||when-this.lastTick<.04)return;
    this.lastTick=when;this.tension=Math.max(0,Math.min(1,Number(tension)||0));this.elapsed=when-this.epoch;
    const safe=Math.max(when,this.ctx.currentTime)+.02,interval=this.beat/4;
    if(this.nextTime<safe){const missed=Math.ceil((safe-this.nextTime)/interval);this.step+=missed;this.skipped+=missed;this.nextTime+=missed*interval;}
    while(this.nextTime<=when+this.lookahead){this.schedule(this.step++,this.nextTime);this.nextTime+=interval;}
    this.body.frequency.setTargetAtTime(indoor?2200:2800+this.bossPhase*200,when,.4);
    this.tensionGain.gain.setTargetAtTime(this.bossPhase===0?.016:.022+this.tension*.018,when,.7);
    if(when>=this.duckUntil)this.duckGain.gain.setTargetAtTime(1,when,.2);
  }
  duck(strength=.3,seconds=.5){
    if(this.disposed)return;const t=this.ctx.currentTime,gain=this.duckGain.gain;this.duckUntil=Math.max(this.duckUntil,t+seconds);
    if(gain.cancelAndHoldAtTime)gain.cancelAndHoldAtTime(t);else gain.cancelScheduledValues(t);
    gain.setTargetAtTime(1-Math.max(0,Math.min(.65,strength)),t,.02);gain.setTargetAtTime(1,this.duckUntil,.23);
  }
  snapshot(){return {name:'WARDEN / Redline',bpm:this.bpm,phase:this.bossPhase,elapsed:this.elapsed||0,transitions:this.transitions,played:this.played,skipped:this.skipped,sources:this.sources.length,nodes:this.nodes.length,disposed:this.disposed,arpeggiators:this.arps.map(a=>({name:a.name,interval:a.interval,played:a.played,skipped:a.skipped,pooledVoices:a.voices.length}))};}
  dispose(){if(this.disposed)return;this.disposed=true;for(const source of this.sources){try{source.stop();}catch{}}for(const node of this.nodes){try{node.disconnect();}catch{}}this.sources.length=0;this.nodes.length=0;}
}
