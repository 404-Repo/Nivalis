// Optional detail constructions inside the original outlines. Shared base
// generators remain byte-identical to Level 1; all additions bake by material.
export function applyHeroDetails(root,asset,variant='field'){
 if(!['heavy_drone','rifle','station_rover'].includes(asset)||variant==='service')return root;
 const steel=new THREE.MeshStandardMaterial({color:0x73818a,metalness:.72,roughness:.62}),recess=new THREE.MeshStandardMaterial({color:0x17242b,metalness:.3,roughness:.9}),oxide=new THREE.MeshStandardMaterial({color:variant==='scorched'?0x3c3537:0x705244,metalness:.38,roughness:.93});
 for(const m of [steel,recess,oxide])m.color.convertSRGBToLinear();
 const detail=new THREE.Group();detail.name=`hero detail / ${asset} / ${variant}`;
 const box=(x,y,z,w,h,d,mat)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);o.position.set(x,y,z);detail.add(o);return o;};
 const bolt=(x,y,z,r,side=false)=>{const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,r*.35,6),steel);m.rotation[side?'z':'x']=Math.PI/2;m.position.set(x,y,z);detail.add(m);};
 if(asset==='station_rover'){
  for(const x of [-.66,.66]){box(x,2.08,-2.383,.77,.70,.025,recess);for(const xx of [-.32,.32])for(const yy of [-.28,.28])bolt(x+xx,2.08+yy,-2.408,.028);}
  for(let i=0;i<7;i++){const rib=box(-.66,1.86+i*.075,-2.409,.57,.038,.034,steel);rib.rotation.x=-.35;}
  box(.66,2.08,-2.403,.61,.55,.014,oxide);box(.87,2.08,-2.43,.055,.15,.028,steel);
  for(const x of [-1.797,1.797])for(const z of [-1.87,0,1.87])for(let i=0;i<6;i++){const a=i*Math.PI/3;bolt(x,.67+Math.sin(a)*.23,z+Math.cos(a)*.23,.029,true);}
 }else if(asset==='rifle'){
  for(const side of [-1,1]){for(const z of [-.22,-.05])bolt(side*.109,.31,z,.012,true);for(let i=0;i<3;i++)box(side*.105,.34,.19+i*.075,.004,.015,.043,recess);}
  for(let i=0;i<3;i++)box(0,.393,-.14+i*.056,.08,.004,.014,oxide);
 }else{
  const a=root.userData.originAdjustment||{x:0,y:0,z:0};detail.position.set(a.x,a.y,a.z);
  for(const x of [-2.86,2.86])for(const z of [-2.22,2.22]){
   const ring=new THREE.Mesh(new THREE.TorusGeometry(1.12,.016,5,40),oxide);ring.rotation.x=Math.PI/2;ring.position.set(x,1.55,z);detail.add(ring);
   for(let i=0;i<8;i++){const angle=i*Math.PI/4,fastener=new THREE.Mesh(new THREE.CylinderGeometry(.031,.031,.015,6),steel);fastener.position.set(x+Math.cos(angle)*1.21,2.36,z+Math.sin(angle)*1.21);detail.add(fastener);}
  }
 }
 if(variant==='scorched')for(const m of [steel,oxide])m.color.multiplyScalar(.65);
 root.add(detail);return root;
}
