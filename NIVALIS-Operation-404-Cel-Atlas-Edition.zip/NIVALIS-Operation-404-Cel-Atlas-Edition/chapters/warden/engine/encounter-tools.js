export function registerEncounterTools({start,status}) {
  const context=document.modelContext;
  if(!context?.registerTool)return;
  const lifecycle=new AbortController();
  const register=tool=>{try{Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}};
  const object=input=>{if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Expected an object.');};
  register({name:'get_warden_encounter_status',description:'Read the current WARDEN phase, health, mission and player status.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute(input){object(input);if(Object.keys(input).length)throw new Error('This tool takes no parameters.');return status();}});
  register({name:'start_warden_encounter',description:'Start a fresh WARDEN encounter from the start or results screen. Combat enables enemy fire; recon explores without incoming fire. Does not replace an active run.',inputSchema:{type:'object',properties:{mode:{type:'string',enum:['combat','recon']}},required:['mode'],additionalProperties:false},annotations:{readOnlyHint:false},execute(input){object(input);if(Object.keys(input).some(k=>k!=='mode')||!['combat','recon'].includes(input.mode))throw new Error('Choose combat or recon.');const current=status();if(current.started&&!current.over)throw new Error('A run is already active. Use its pause or restart controls.');start(input.mode,false);return status();}});
  window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
}
