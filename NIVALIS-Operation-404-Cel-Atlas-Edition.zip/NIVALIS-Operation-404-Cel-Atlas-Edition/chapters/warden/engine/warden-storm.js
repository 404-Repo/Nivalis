// Presentation only: no geometry, movement, visibility or encounter rules change.
export function makeWardenStorm(scene,environment,level) {
  const red=new THREE.Color(0xff3022).convertSRGBToLinear(),fixtures=[];
  const materials=new Map();
  // Run before actors and the first-person weapon are added. Clone materials so
  // emergency lighting cannot recolor cached drone optics or WARDEN's weakpoint.
  scene.traverse(object=>{
    // Painted markings use a faint emissive map for readability, not a lamp.
    if(object.name.startsWith('interior-spray-paint-'))return;
    if(object.isPointLight||object.isSpotLight)object.color.copy(red);
    if(!object.isMesh||Array.isArray(object.material))return;
    const original=object.material;
    if(!original.emissive||original.emissiveIntensity<=0||original.emissive.getHex()===0)return;
    if(!materials.has(original)){
      const material=original.clone();material.color.copy(red);material.emissive.copy(red);
      materials.set(original,material);fixtures.push({material,level:Math.max(1.7,original.emissiveIntensity)});
    }
    object.material=materials.get(original);
  });
  environment.snow.visible=false;
  // Deliberately theatrical emergency bounce: the whole yard stays red even
  // between the local lamps, with a little cold moonlight to retain silhouettes.
  environment.sun.intensity=.10;environment.hemi.intensity=1.22;
  environment.hemi.color.set(0xff2038).convertSRGBToLinear();
  environment.hemi.groundColor.set(0x9a1930).convertSRGBToLinear();
  scene.fog.color.set(0x873641).convertSRGBToLinear();scene.background.copy(scene.fog.color);
  environment.mist.forEach(m=>m.material.color.set(0xee716c).convertSRGBToLinear());
  environment.sky.material.uniforms.fogTint.value.copy(scene.fog.color);
  Object.assign(environment.fogProfiles,{
    light:{density:.019,mist:.78},atmospheric:{density:.026,mist:1.16},dense:{density:.032,mist:1.40}
  });
  const count=6200,positions=new Float32Array(count*3),seeds=new Float32Array(count);
  let seed=91404;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  for(let i=0;i<count;i++){positions[i*3]=random()*84;positions[i*3+1]=random()*28;positions[i*3+2]=random()*84;seeds[i]=random();}
  const roofs=level.colliders.filter(c=>['roof','deck','helipad-deck'].includes(c.type));
  const shapes=Array.from({length:12},()=>new THREE.Vector4()),poses=Array.from({length:12},()=>new THREE.Vector4());
  roofs.slice(0,12).forEach((r,i)=>{shapes[i].set(r.x,r.z,r.w/2+.12,r.d/2+.12);poses[i].set(Math.cos(r.angle),Math.sin(r.angle),r.maxY,0);});
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.setAttribute('seed',new THREE.BufferAttribute(seeds,1));
  const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,depthTest:true,uniforms:{
    stormTime:{value:0},center:{value:new THREE.Vector3()},gust:{value:1},pixelScale:{value:1},shelterCount:{value:Math.min(12,roofs.length)},shelters:{value:shapes},shelterPose:{value:poses}
  },vertexShader:`
    attribute float seed;uniform float stormTime,pixelScale;uniform vec3 center;
    uniform int shelterCount;uniform vec4 shelters[12],shelterPose[12];varying float visibility,flakeSeed;
    void main(){
      float t=stormTime;vec3 p=position;
      p.x=mod(p.x+t*(8.0+seed*3.0)+sin(t*.31+seed*6.28)*4.0-center.x,84.0)-42.0+center.x;
      p.z=mod(p.z+t*2.3+sin(t*.19)*3.0-center.z,84.0)-42.0+center.z;
      p.y=mod(p.y-t*(2.1+seed*2.8),28.0);
      float hidden=0.0;
      for(int i=0;i<12;i++){if(i>=shelterCount)break;vec2 d=p.xz-shelters[i].xy;vec4 r=shelterPose[i];
        vec2 local=vec2(d.x*r.x-d.y*r.y,d.x*r.y+d.y*r.x);
        if(p.y<r.z&&abs(local.x)<shelters[i].z&&abs(local.y)<shelters[i].w)hidden=1.0;
      }
      vec4 view=modelViewMatrix*vec4(p,1.0);float distance=-view.z;
      visibility=(1.0-hidden)*smoothstep(.5,3.0,distance)*(1.0-smoothstep(32.0,62.0,distance));
      gl_PointSize=clamp((48.0+seed*48.0)*pixelScale/max(1.0,distance),1.0,5.0*pixelScale);
      flakeSeed=seed;gl_Position=projectionMatrix*view;
    }`,fragmentShader:`
    uniform float gust;varying float visibility,flakeSeed;
    void main(){vec2 p=gl_PointCoord-.5;
      p=mat2(.86,-.5,.5,.86)*p;p.x*=1.25;p.y*=.82;
      float a=(1.0-smoothstep(.08,.48,length(p)))*visibility*(.46+flakeSeed*.22)*gust;
      if(a<.015)discard;gl_FragColor=vec4(1.,.56,.52,a);
    }`});
  const snow=new THREE.Points(geometry,material);snow.name='WARDEN / crosswind blizzard';snow.frustumCulled=false;scene.add(snow);
  let reduced=false,quality='balanced';
  function update(dt,player,time){
    material.uniforms.stormTime.value=time;material.uniforms.center.value.set(player.x,0,player.z);
    const gust=.84+.16*Math.sin(time*.37);material.uniforms.gust.value=gust;
    scene.fog.density*=1+.045*Math.sin(time*.27);
    environment.mist.forEach((m,i)=>{const d=m.userData;m.position.x=d.baseX+Math.sin(time*.16+d.phase)*7.5;m.position.z=d.baseZ+Math.cos(time*.09+d.phase)*2.4;m.scale.y=d.height*(1.08+.16*Math.sin(time*.22+i));m.material.opacity=Math.min(.74,m.material.opacity*(1.04+.12*Math.sin(time*.23+i)));});
    const pulse=reduced?.82:.58+.42*Math.pow((Math.sin(time*3.8)+1)/2,3);
    environment.hemi.intensity=reduced?1.22:1.12+pulse*.18;
    for(const f of fixtures)f.material.emissiveIntensity=f.level*pulse;
  }
  return {snow,fixtures,roofs,reducedFlashing:()=>reduced,setReducedFlashing(value){reduced=!!value;},
    setQuality(value){quality=value;geometry.setDrawRange(0,value==='low'?2400:value==='high'?count:4800);material.uniforms.pixelScale.value=value==='high'?1.25:1;},
    snapshot(){return {name:'Crosswind',flakes:geometry.drawRange.count,roofMasks:roofs.length,emergencyMaterials:fixtures.length,reducedFlashing:reduced,quality};},update};
}
