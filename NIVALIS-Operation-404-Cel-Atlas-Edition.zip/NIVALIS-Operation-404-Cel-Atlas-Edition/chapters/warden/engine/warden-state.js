// Encounter rules are independent of rendering so phase boundaries and repairs
// can be checked without a graphics context. This mission has no campaign index.
export class WardenState {
  constructor() { this.reset(); }
  reset() {
    Object.assign(this, { maxHealth: 3000, health: 3000, phase: 1, defeated: false,
      repairPending: false, repairing: false, repairSeconds: 0,
      healed: 0, repairLimit: 300, reactorDamage: 0, interrupted: false });
  }
  hit(amount, reactor = false) {
    if (this.defeated || !Number.isFinite(amount) || amount <= 0) return;
    const floor = this.phase === 1 ? this.maxHealth * .65 : this.phase === 2 ? this.maxHealth * .30 : 0;
    this.health = Math.max(floor, this.health - amount);
    if (reactor && this.repairing) {
      this.reactorDamage += amount;
      if (this.reactorDamage >= 150) { this.repairing = false; this.interrupted = true; }
    }
    if (this.phase === 1 && this.health <= floor) {
      this.phase = 2; this.repairPending = true;
    } else if (this.phase === 2 && this.health <= floor) {
      this.phase = 3; this.repairPending = this.repairing = false;
    } else if (this.health <= 0) {
      this.defeated = true; this.repairPending = this.repairing = false;
    }
  }
  beginRepair() {
    if (!this.repairPending || this.defeated || this.phase !== 2) return false;
    this.repairPending = false; this.repairing = true; return true;
  }
  update(dt) {
    if (!this.repairing || !Number.isFinite(dt) || dt <= 0) return;
    const elapsed = Math.min(dt, Math.max(0, 8 - this.repairSeconds));
    const gain = Math.min(elapsed * 37.5, this.repairLimit - this.healed, this.maxHealth * .75 - this.health);
    this.health += Math.max(0, gain); this.healed += Math.max(0, gain); this.repairSeconds += elapsed;
    if (this.repairSeconds >= 8) this.repairing = false;
  }
}
