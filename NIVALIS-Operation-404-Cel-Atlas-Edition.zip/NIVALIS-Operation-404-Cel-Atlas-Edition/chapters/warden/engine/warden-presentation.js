// Bounded, reusable presentation buffers. No gameplay colliders are added.
const v=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z);
export function makeWardenPresentation(scene,rig,level){
 const falloff=new Uint8Array(64*64*4);for(let y=0;y<64;y++)for(let x=0;x<64;x++){const a=Math.round(255*Math.pow(Math.max(0,1-Math.hypot(x-31.5,y-31.5)/31.5),1.5)),i=(y*64+x)*4;falloff[i]=falloff[i+1]=falloff[i+2]=a;falloff[i+3]=255;}const soft=new THREE.DataTexture(falloff,64,64);soft.needsUpdate=true;soft.magFilter=THREE.LinearFilter;
 const shadow=new THREE.Mesh(new THREE.CircleGeometry(1,40),new THREE.MeshBasicMaterial({color:0x151423,alphaMap:soft,transparent:true,opacity:.2,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));
 shadow.rotation.x=-Math.PI/2;scene.add(shadow);
 const count=144,positions=new Float32Array(count*3),colors=new Float32Array(count*3),geo=new THREE.BufferGeometry();
 geo.setAttribute('position',new THREE.BufferAttribute(positions,3));geo.setAttribute('color',new THREE.BufferAttribute(colors,3));
 const wash=new THREE.Points(geo,new THREE.PointsMaterial({size:.2,alphaMap:soft,vertexColors:true,transparent:true,opacity:.42,depthWrite:false}));wash.frustumCulled=false;scene.add(wash);
 const sparkGeo=new THREE.BufferGeometry(),sparkData=new Float32Array(48*3);sparkGeo.setAttribute('position',new THREE.BufferAttribute(sparkData,3));
 const sparks=new THREE.Points(sparkGeo,new THREE.PointsMaterial({color:0xffce70,size:.075,depthWrite:false,transparent:true,opacity:.85}));sparks.frustumCulled=false;rig.add(sparks);
 const transfer=new THREE.Mesh(new THREE.CylinderGeometry(.2,.64,1,16,1,true),new THREE.MeshBasicMaterial({color:0xffbf5a,transparent:true,opacity:.22,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));scene.add(transfer);
 const debris=new THREE.InstancedMesh(new THREE.BoxGeometry(.16,.09,.28),new THREE.MeshStandardMaterial({color:0x56616a,metalness:.6,roughness:.88}),18);debris.frustumCulled=false;scene.add(debris);const dummy=new THREE.Object3D(),rotation=new THREE.Matrix4();
 let hitTime=0,impactTime=-1;const pad=v(0,level.helipad.y,-13);
 function floor(x,z){let y=0;for(const s of level.surfaces){const a=s.angle||0,dx=x-s.x,dz=z-s.z,lx=dx*Math.cos(a)-dz*Math.sin(a),lz=dx*Math.sin(a)+dz*Math.cos(a);if(Math.abs(lx)<s.w/2&&Math.abs(lz)<s.d/2)y=Math.max(y,s.y);}return y;}
 function reset(){hitTime=0;impactTime=-1;wash.visible=shadow.visible=transfer.visible=sparks.visible=debris.visible=false;}
 function update(dt,{elapsed,mode,phase,defeated,deathTime,rotorPower,reducedFlash}){
  hitTime=Math.max(0,hitTime-dt);if(impactTime>=0)impactTime+=dt;
  const ground=floor(rig.position.x,rig.position.z),height=Math.max(0,rig.position.y-ground);
  shadow.visible=rotorPower>.02&&!defeated;shadow.position.set(rig.position.x,ground+.025,rig.position.z);shadow.scale.set(4.5+height*.13,3.3+height*.13,1);shadow.material.opacity=.27/(1+height*.025);
  wash.visible=(rotorPower>.05&&!defeated)||(impactTime>=0&&impactTime<2.8);
  for(let i=0;i<count;i++){
   const progress=((elapsed*(.48+i%5*.06)+i*.618)%1),angle=i*2.4+elapsed*.18,r=1.5+progress*(impactTime>=0?9:7);
   positions[i*3]=(impactTime>=0?pad.x:rig.position.x)+Math.cos(angle)*r;positions[i*3+1]=ground+.12+Math.sin(progress*Math.PI)*(.3+Math.min(2,height*.1));positions[i*3+2]=(impactTime>=0?pad.z:rig.position.z)+Math.sin(angle)*r;
   colors[i*3]=.58+progress*.3;colors[i*3+1]=.62+progress*.3;colors[i*3+2]=.66+progress*.3;
  }geo.attributes.position.needsUpdate=true;geo.attributes.color.needsUpdate=true;wash.material.opacity=impactTime>=0?Math.max(0,.75-impactTime*.27):rotorPower*.42/(1+height*.04);
  sparks.visible=(phase===3&&!defeated)||hitTime>0||(defeated&&deathTime<3.4);
  for(let i=0;i<48;i++){const t=(elapsed*(1+i%3*.1)+i*.137)%1;sparkData[i*3]=(i%2?1:-1)*(1.0+t*.9);sparkData[i*3+1]=2.2-t*t*2.1;sparkData[i*3+2]=-.5+(i%5-.2)*.18+t*.7;}
  sparkGeo.attributes.position.needsUpdate=true;sparks.material.opacity=reducedFlash?.45:.5+Math.sin(elapsed*5)*.25;
  transfer.visible=mode==='repair';const len=Math.max(.1,rig.position.y+.7-pad.y);transfer.position.set(rig.position.x,pad.y+len/2,rig.position.z);transfer.scale.set(1,len,1);transfer.rotation.y=elapsed*2;
  debris.visible=impactTime>=0;
  if(debris.visible)for(let i=0;i<18;i++){const t=Math.min(1.2,impactTime),a=i*2.399,r=.8+t*(1.2+i%4*.45);dummy.position.set(pad.x+Math.cos(a)*r,pad.y+.045+Math.max(0,Math.sin(t/1.2*Math.PI))*(.4+i%3*.22),pad.z+Math.sin(a)*r);dummy.rotation.set(i*.7+t*4,i*1.2,Math.min(t,1)*i);rotation.makeRotationFromEuler(dummy.rotation);const e=rotation.elements,extent=Math.abs(e[1])*.08+Math.abs(e[5])*.045+Math.abs(e[9])*.14;dummy.position.y+=extent-.045+.002;dummy.updateMatrix();debris.setMatrixAt(i,dummy.matrix);}debris.instanceMatrix.needsUpdate=true;
 }
 reset();return{reset,update,hit(){hitTime=.22;},impact(){impactTime=0;},get impactTime(){return impactTime;}};
}
