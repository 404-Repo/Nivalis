// WARDEN-only material treatment. Shared generator geometry stays unchanged.
// Three restrained candidates retain the same silhouette and original colours.
const cache=new Map();
export const HERO_FINISHES={service:.28,field:.44,scorched:.88};
function maps(variant){
 if(cache.has(variant))return cache.get(variant);
 const size=256,albedo=new Uint8Array(size*size*4),rough=new Uint8Array(size*size*4),amount=HERO_FINISHES[variant]??HERO_FINISHES.field;
 let seed=409;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
  const i=(y*size+x)*4,n=rand(),seam=Math.min(x%64,64-x%64),scratch=n>.992&&seam<9;
  const streak=Math.pow(Math.max(0,Math.sin(x*.23+.3)),18)*(.3+.7*y/size);
  const patch=(Math.sin(x*.075+Math.sin(y*.043)*2)+Math.cos(y*.083+Math.sin(x*.11)))*.25+.5;
  const chip=patch>.78&&n>.48?Math.min(1,(patch-.78)*9):0;
  const dirt=amount*(streak*.32+(seam<2?.2:0)+(scratch?.55:0)+chip*.65);
  albedo[i]=255*(.97-dirt);albedo[i+1]=255*(.97-dirt*1.17);albedo[i+2]=255*(.98-dirt*1.29);albedo[i+3]=255;
  rough[i]=rough[i+1]=rough[i+2]=Math.min(255,210+n*30+dirt*30);rough[i+3]=255;
 }
 function texture(data,color){const t=new THREE.DataTexture(data,size,size);t.encoding=color?THREE.sRGBEncoding:THREE.LinearEncoding;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.magFilter=THREE.LinearFilter;t.minFilter=THREE.LinearMipmapLinearFilter;t.generateMipmaps=true;t.needsUpdate=true;return t;}
 const result={map:texture(albedo,true),roughnessMap:texture(rough,false)};cache.set(variant,result);return result;
}
export function applyHeroFinish(root,asset,variant='field'){
 // The reference-built carbine keeps its shared clean finish on the return trip.
 if(!['heavy_drone','station_rover'].includes(asset))return root;
 const materials=new Map(),textures=maps(variant),p=new THREE.Vector3(),n=new THREE.Vector3();root.updateMatrixWorld(true);
 root.traverse(o=>{
  const source=o.material;if(!o.isMesh||Array.isArray(source)||!source?.isMeshStandardMaterial||source.transparent||source.emissive?.getHex()>0||source.roughness<.35||source.metalness<.2)return;
  if(!materials.has(source)){
   const m=source.clone();m.onBeforeCompile=source.onBeforeCompile;m.customProgramCacheKey=source.customProgramCacheKey;
   // Preserve the rover's metre-scaled surface shader and frost attributes.
   m.map=textures.map;m.roughnessMap=textures.roughnessMap;m.roughness=Math.min(.92,Math.max(.62,source.roughness));
   m.name=`hero/${variant}/${source.name}`;m.userData={...source.userData,heroFinish:variant,celBroadSurface:true};materials.set(source,m);
  }
  o.material=materials.get(source);
  if(!source.map){
   const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone(),pos=geo.attributes.position,norm=geo.attributes.normal,uv=new Float32Array(pos.count*2),tile=asset==='rifle'?.14:1.2;
   for(let i=0;i<pos.count;i++){
    p.fromBufferAttribute(pos,i).applyMatrix4(o.matrixWorld);n.fromBufferAttribute(norm,i).transformDirection(o.matrixWorld);
    const axis=Math.abs(n.y)>.6?1:Math.abs(n.x)>.6?0:2;
    uv[i*2]=(axis===0?p.z:p.x)/tile;uv[i*2+1]=(axis===1?p.z:p.y)/tile;
   }geo.setAttribute('uv',new THREE.BufferAttribute(uv,2));o.geometry=geo;
  }
 });root.userData.heroFinish=variant;return root;
}
