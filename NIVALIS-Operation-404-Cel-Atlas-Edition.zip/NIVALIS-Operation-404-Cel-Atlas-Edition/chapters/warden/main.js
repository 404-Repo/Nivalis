import {createTouchLook} from './engine/touch-look.js';
import {createWeaponInk} from './engine/weapon-ink.js';
import {createCelRenderer} from './engine/cel-renderer.js';
import {campaign} from './engine/campaign-bridge.js';
import {makeEndScreen} from './engine/end-screen.js';
import {updateCombatUI} from './engine/game-ui.js';
import {titleScreen} from './engine/title-screen.js';
import { makeServiceLift } from './engine/service-lift.js';
import { makeLadderController } from './engine/ladder.js';
import { makeDroneStatus } from './engine/drone_status.js';
import { makeGrounding } from './engine/grounding.js';
import { surfacePilotInfo } from './engine/surfaces.js';
import { bakeStatic } from './engine/assets.js';
import { makeEnvironment } from './engine/environment.js';
import { buildLevel } from './engine/level.js';
import { registerEncounterTools } from './engine/encounter-tools.js';
import { makeWardenStorm } from './engine/warden-storm.js';
import { makeWarden, getWardenSpawn } from './engine/warden.js';
import { FieldAudio } from './engine/audio.js';
import { makeSecurity, DIFFICULTY } from './engine/security.js';
import { makeStealthController } from './engine/stealth.js';
import { makeAtmosphere } from './engine/atmosphere.js';
import { buildHumanTraces, makeHumanObjectives, HUMAN_ACHIEVEMENTS } from './engine/human_traces.js';
const liftTour=new URLSearchParams(location.search).has('lift-preview');
const $=id=>document.getElementById(id);
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
const lerp=(a,b,t)=>a+(b-a)*t;
async function boot(){
const endScreen=makeEndScreen({onReplay:()=>$('restart').click()});
const canvas=$('world');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.35));renderer.setSize(innerWidth,innerHeight,false);renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.04;
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(76,innerWidth/innerHeight,.07,510);camera.rotation.order='YXZ';const environment=makeEnvironment(scene,renderer);scene.remove(environment.tracks);scene.add(bakeStatic(environment.tracks));
const level=await buildLevel(scene,(amount,name)=>{titleScreen.progress(10+amount*85);},{wardenEncounter:true});
const humanWorld=await buildHumanTraces(scene,level);
const storm=makeWardenStorm(scene,environment,level);storm.setQuality('balanced');
const serviceLift=makeServiceLift(scene,level);serviceLift.parkOpen();
const encounterSpawn=getWardenSpawn(level);
const grounding=makeGrounding(scene,level);
const audio=new FieldAudio(),touch=matchMedia('(pointer:coarse)').matches||(navigator.maxTouchPoints>0&&innerWidth<1000);if(touch)document.body.classList.add('touch-mode');
let preferences={};try{preferences=JSON.parse(localStorage.getItem('nivalis.campaign.warden.preferences')||'{}')||{};}catch{}
function savePreferences(){try{localStorage.setItem('nivalis.campaign.warden.preferences',JSON.stringify({navigation:state.navigation,gameplayVersion:2,difficulty:state.difficulty,reducedFlashing:state.reducedFlashing,ambience:audio.ambience,music:audio.music,breathing:audio.breathing,muted:audio.muted,motion:state.motion,sensitivity:state.sensitivity,quality:$('quality').value,fog:environment.fogStyle}));}catch{}}
const state={difficulty:'veteran',started:false,paused:false,over:false,won:false,mode:'combat',time:0,kills:0,score:0,droneAlerts:0,droneSuspicion:0,threatId:null,droneEngaged:false,stealthBonus:0,map:false,photo:false,motion:true,sensitivity:1,stamina:100,ammo:36,reserve:540,reloading:0,nextShot:0,lastDamage:-99,damage:0,hit:0,recoil:0,ads:0,toastUntil:0,hack:0,hackId:null,shots:0,hits:0};
const player={...encounterSpawn,vy:0,pitch:0,height:1.78,health:100,shield:80,grounded:true,speed:0};
let touchLook=null;
const keys=new Set();let mouseDown=false,aimDown=false,rightAimHeld=false,dragLook=false,jumpQueued=false,locked=false,lastMouse={x:0,y:0},analog={x:0,y:0};
const enemies=[],effects=[],projectiles=[];let bob=0,stepAt=0,rafPrevious=performance.now(),fps=0,frames=0,frameWindow=0,hudAccumulator=0,realClock=0;
const v3=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z),direction=v3(),right=v3(),origin=v3();
const sphereGeo=new THREE.SphereGeometry(1,8,6),tracerGeo=new THREE.CylinderGeometry(1,1,1,5),tracerMat=new THREE.MeshBasicMaterial({color:0xadeff4,transparent:true,opacity:.83,depthWrite:false,blending:THREE.AdditiveBlending}),hostileMat=new THREE.MeshBasicMaterial({color:0xff8c61});
// Separate first-person render layer prevents the weapon intersecting walls.
const viewScene=new THREE.Scene(),viewCamera=new THREE.PerspectiveCamera(56,innerWidth/innerHeight,.01,6),weapon=new THREE.Group();viewScene.add(new THREE.HemisphereLight(0xd1ebff,0x24313b,1.05));const weaponSun=new THREE.DirectionalLight(0xffe0bb,1.5);weaponSun.position.set(-3,4,2);viewScene.add(weaponSun);
weapon.add(level.prototypes.rifle.clone(true));viewScene.add(weapon);weapon.rotation.y=Math.PI;weapon.scale.setScalar(.68);
const sleeve=new THREE.MeshStandardMaterial({color:0x304351,roughness:.87,metalness:.2}),glove=new THREE.MeshStandardMaterial({color:0x1c2933,roughness:.85,metalness:.05}),cuff=new THREE.MeshStandardMaterial({color:0x8b9c9f,roughness:.55,metalness:.55});
function arm(a,b,r,m){const p=v3(...a),q=v3(...b),d=q.clone().sub(p),mesh=new THREE.Mesh(new THREE.CylinderGeometry(r*.84,r,d.length(),10),m);mesh.position.copy(p.add(q).multiplyScalar(.5));mesh.quaternion.setFromUnitVectors(v3(0,1,0),d.normalize());weapon.add(mesh);}
arm([-.31,-.19,-.52],[-.015,.08,-.15],.078,sleeve);arm([-.015,.05,-.17],[.015,.16,-.105],.072,glove);arm([-.075,.00,-.21],[-.06,.025,-.18],.084,cuff);arm([.32,-.21,-.31],[.085,.12,.22],.077,sleeve);arm([.085,.10,.20],[.075,.195,.30],.074,glove);arm([.12,.04,.16],[.103,.069,.193],.087,cuff);
const flash=new THREE.Mesh(new THREE.SphereGeometry(.11,8,6),new THREE.MeshBasicMaterial({color:0xb8faff,transparent:true,opacity:.9,blending:THREE.AdditiveBlending,depthWrite:false}));flash.position.set(0,.285,.735);flash.scale.set(.7,.7,2);flash.visible=false;weapon.add(flash);const weaponLight=new THREE.PointLight(0x7ae8ff,0,3);weaponLight.position.set(0,.3,.7);weapon.add(weaponLight);const headlamp=new THREE.PointLight(0xb1ddea,.22,11,1.5);scene.add(headlamp);
function rayBox(o,d,c,maxDistance=Infinity){const cs=Math.cos(c.angle),sn=Math.sin(c.angle),dx=o.x-c.x,dz=o.z-c.z,p=[dx*cs-dz*sn,o.y,dx*sn+dz*cs],v=[d.x*cs-d.z*sn,d.y,d.x*sn+d.z*cs],lo=[-c.w/2,c.minY,-c.d/2],hi=[c.w/2,c.maxY,c.d/2];let near=0,far=maxDistance;for(let k=0;k<3;k++){if(Math.abs(v[k])<1e-8){if(p[k]<lo[k]||p[k]>hi[k])return Infinity;}else{let a=(lo[k]-p[k])/v[k],b=(hi[k]-p[k])/v[k];if(a>b)[a,b]=[b,a];near=Math.max(near,a);far=Math.min(far,b);if(near>far)return Infinity;}}return near<=maxDistance?near:Infinity;}
function wallDistance(o,d,maxDistance=150){let nearest=maxDistance;for(const c of level.colliders)nearest=Math.min(nearest,rayBox(o,d,c,nearest));return nearest;}
function localXZ(x,z,c){const dx=x-c.x,dz=z-c.z,cs=Math.cos(c.angle||0),sn=Math.sin(c.angle||0);return{x:dx*cs-dz*sn,z:dx*sn+dz*cs};}
function floorAt(x,z,currentY=player.y){let y=0;for(const s of level.surfaces){const p=localXZ(x,z,s);if(Math.abs(p.x)<s.w/2+.34&&Math.abs(p.z)<s.d/2+.34&&currentY>=s.y-.3)y=Math.max(y,s.y);}for(const r of level.ramps){const p=localXZ(x,z,r);if(Math.abs(p.x)<=r.w/2&&Math.abs(p.z)<=r.d/2+.40){const h=lerp(r.low,r.high,clamp((r.d/2-p.z)/r.d,0,1));if(currentY>=h-.4)y=Math.max(y,h);}}return y;}
function resolvePosition(x,z){const radius=.34;for(let pass=0;pass<2;pass++)for(const c of level.colliders){if(player.y>=c.maxY-.045||player.y+player.height<=c.minY+.025)continue;const p=localXZ(x,z,c),qx=clamp(p.x,-c.w/2,c.w/2),qz=clamp(p.z,-c.d/2,c.d/2);let dx=p.x-qx,dz=p.z-qz,ds=dx*dx+dz*dz;if(ds>=radius*radius)continue;let nx=0,nz=0,push=0;if(ds>.000001){const len=Math.sqrt(ds);nx=dx/len;nz=dz/len;push=radius-len;}else{const px=c.w/2-Math.abs(p.x),pz=c.d/2-Math.abs(p.z);if(px<pz){nx=p.x>=0?1:-1;push=px+radius;}else{nz=p.z>=0?1:-1;push=pz+radius;}}const cs=Math.cos(c.angle),sn=Math.sin(c.angle);x+=(nx*cs+nz*sn)*(push+.001);z+=(-nx*sn+nz*cs)*(push+.001);}return{x:clamp(x,-42.4,42.4),z:clamp(z,-79.4,45.4)};}
function forward(){return direction.set(-Math.sin(player.yaw)*Math.cos(player.pitch),Math.sin(player.pitch),-Math.cos(player.yaw)*Math.cos(player.pitch)).normalize();}
function playerEye(){return origin.set(player.x,player.y+player.height,player.z);}
function notify(text,label='COMMAND',duration=4){$('toast-text').textContent=text;$('toast-label').textContent=label;state.toastUntil=state.time+duration;$('toast').style.opacity='1';}
const security=makeSecurity(scene,level,wallDistance,audio,notify),atmosphere=makeAtmosphere(scene,level,wallDistance,{emergency:true});
const tuning=()=>DIFFICULTY[state.difficulty]||DIFFICULTY.tactical;
const stealth=makeStealthController(scene,level,wallDistance,rayBox,audio,notify,fireStealthBolt);
const ladder=makeLadderController(level.ladder,player,state,audio,()=>{mouseDown=aimDown=rightAimHeld=false;state.ads=0;state.reloading=0;humanObjectives.cancel();});
const adsConfig=Object.freeze({baseFov:76,aimFov:2*Math.atan(Math.tan(76*Math.PI/360)/2)*180/Math.PI,magnification:2,sensitivity:.5});
const humanObjectives=makeHumanObjectives(humanWorld,wallDistance,audio,notify,(_context,radius)=>{if(tuning().stealth)stealth.hear(enemies,player,state,radius);else if(state.mode==='combat'&&tuning().response&&state.time>=5)for(const e of enemies)if(e.alive&&Math.hypot(e.x-player.x,e.z-player.z)<radius){e.interest=3;e.lastKnown={x:player.x,z:player.z};}});
const enemyDescriptors=[[-6,12,1.5],[7,1,1.6],[-20,-18,1.48],[21,-14,4.3],[22,-26,4.25],[0,-29,1.65],[-10,-44,1.5],[9,-58,1.65]];
function resetEnemies(){stealth.clear();enemies.forEach(e=>{scene.remove(e.group);e.statusLight?.dispose();});enemies.length=0;}
function disableNetwork(){security.reset(state.difficulty);for(const t of level.terminals){t.done=true;t.setOffline(true);security.disableZone(t.id);}}
function spawnEscorts(position){
 for(const side of [-1,1]){const group=level.prototypes.drone.clone(true);group.scale.setScalar(.92);const x=position.x+side*4.7,z=position.z+side*2.0,y=position.y-.6;group.position.set(x,y,z);group.traverse(o=>{if(o.isMesh)o.castShadow=false;});scene.add(group);enemies.push({group,x,z,y,statusLight:makeDroneStatus(group),anchorX:x,anchorZ:z,baseY:y,hp:63,alive:true,cooldown:3,charge:0,phase:side,interest:5,lastKnown:{x:player.x,z:player.z},engaged:false});}
 notify('WARDEN deployed two onboard reserves. Hit the amber reactor to interrupt repairs.','REINFORCEMENTS',5);
}
function fireBossBolt(from,target,{speed=25,damage=15,splash=0}={}){
 const dir=target.clone().sub(from).normalize(),mesh=new THREE.Mesh(sphereGeo,hostileMat);mesh.scale.setScalar(splash?.19:.12);mesh.position.copy(from);scene.add(mesh);
 projectiles.push({mesh,pos:mesh.position,dir,life:6,previous:mesh.position.clone(),speed,damage,source:'warden',splash,target:splash?target.clone():null});audio.tone(splash?105:185,.16,'sawtooth',.05,70);
}
const boss=await makeWarden(scene,level,{wallDistance,floorAt,fire:fireBossBolt,escorts:spawnEscorts,notify,audio,onDefeat(){
 state.score+=2000;for(const e of enemies){e.alive=false;e.group.visible=false;}for(const p of projectiles)scene.remove(p.mesh);projectiles.length=0;
 level.extraction.pad.material.color.set(0x80ebd0);notify('WARDEN is falling back onto its launch pad.','DEFENSE SYSTEM OFFLINE',4);
}});
resetEnemies();disableNetwork();
const markers=new Map();for(const t of level.terminals){const m=document.createElement('div');m.className='world-marker';m.innerHTML=`<i><b>${t.id}</b></i><span></span>`;$('markers').appendChild(m);markers.set(t.id,m);}const exitMarker=document.createElement('div');exitMarker.className='world-marker hidden';exitMarker.innerHTML='<i><b>↗</b></i><span>DESCEND / B1</span>';$('markers').appendChild(exitMarker);
function reset(){touchLook?.reset();serviceLift.reset();serviceLift.parkOpen();audio.stopLiftMotor();audio.resetMotion();ladder.reset();document.body.classList.remove('lift-travelling','lift-tour');state.liftPreview=false;humanObjectives.reset();renderer.shadowMap.needsUpdate=true;Object.assign(state,{over:false,won:false,time:0,kills:0,score:0,droneAlerts:0,droneSuspicion:0,threatId:null,droneEngaged:false,stealthBonus:0,stamina:100,ammo:36,reserve:540,reloading:0,nextShot:0,lastDamage:-99,damage:0,hit:0,recoil:0,ads:0,hack:0,hackId:null,shots:0,hits:0,map:false,photo:false});Object.assign(player,{...encounterSpawn,vy:0,pitch:0,height:1.78,health:100,shield:80,grounded:true,speed:0});effects.forEach(e=>scene.remove(e.mesh));projectiles.forEach(p=>scene.remove(p.mesh));effects.length=0;projectiles.length=0;level.terminals.forEach(t=>{t.done=true;t.group.visible=true;t.setOffline(true);t.screen.material.color.set(0xffffff);t.ring.material.color.set(0x88dee6);markers.get(t.id).classList.remove('complete');$('link-'+t.id).classList.remove('done');});level.pickups.forEach(p=>{p.taken=false;p.group.visible=true;});level.extraction.pad.material.color.set(0xebac79);if(tuning().stealth)player.shield=0;mouseDown=aimDown=rightAimHeld=false;keys.clear();analog={x:0,y:0};jumpQueued=false;resetEnemies();disableNetwork();boss.reset();$('tactical').classList.add('hidden');$('hud').classList.remove('photo');document.body.classList.remove('aiming');}
function requestLock(){if(campaign.enabled){campaign.lock();return;}if(touch)return;try{const p=canvas.requestPointerLock();if(p?.catch)p.catch(()=>notify('Mouse capture unavailable. Hold and drag to look.','INPUT',5));}catch{notify('Hold and drag on the scene to look.','INPUT',5);}}
function start(mode='combat',capture=true){campaign.playing();endScreen.hide();document.activeElement?.blur?.();titleScreen.closePanels();reset();state.mode=mode;state.started=true;state.paused=false;document.body.classList.remove('ui-paused');$('menu').classList.add('hidden');$('pause').classList.add('hidden');$('hud').classList.remove('hidden');$('mode-name').textContent=mode==='recon'?'RECON':({classic:'FORGIVING',tactical:'STANDARD',veteran:'HARD'})[state.difficulty];$('resume').classList.remove('hidden');$('touch-controls').classList.toggle('hidden',!touch);audio.start();boss.start();if(capture)requestLock();notify(mode==='recon'?'Explore the aftermath. No incoming fire.':'Core heartbeat lost. Surface patrols destroyed. WARDEN is launching on independent power. Find cover.','COMMAND',6);}
function startLiftTour(){start('recon',false);serviceLift.reset();state.liftPreview=true;document.body.classList.add('lift-tour');Object.assign(player,{x:level.extraction.x,z:level.extraction.z+8,y:0,vy:0,yaw:0,pitch:.035});serviceLift.unlock();notify('Walk into the lift. Hold E inside to descend.','SERVICE LIFT TOUR',8);}
function pause(){touchLook?.reset();if(!state.started||state.paused||state.over)return;humanObjectives.cancel();state.paused=true;document.body.classList.add('ui-paused');campaign.paused();audio.setPaused(true);mouseDown=aimDown=rightAimHeld=false;keys.clear();analog={x:0,y:0};$('pause-title').textContent='PAUSED';$('pause').classList.remove('is-result');$('pause-eyebrow').textContent='CHAPTER 03 / WARDEN';$('pause-description').textContent='';$('result-stats').classList.add('hidden');$('resume').classList.remove('hidden');$('pause').classList.remove('hidden');$('touch-controls').classList.add('hidden');if(document.pointerLockElement)document.exitPointerLock();}
function resume(){campaign.playing();document.activeElement?.blur?.();if(state.over){start(state.mode);return;}state.paused=false;document.body.classList.remove('ui-paused');audio.setPaused(false);$('pause').classList.add('hidden');$('touch-controls').classList.toggle('hidden',!touch);audio.start();requestLock();}
function finish(won){
 if(state.over)return;humanObjectives.cancel();state.over=true;state.won=won;state.paused=true;$('pause').classList.add('is-result');mouseDown=aimDown=rightAimHeld=false;keys.clear();
 $('pause-title').textContent=won?'WARDEN neutralized.':'Field link lost.';
 $('pause-eyebrow').textContent=won?'OPERATION 404 / FAILSAFE NEUTRALIZED':'OPERATION 404 / OPERATOR DOWN';
 $('pause-description').textContent=won?'The command core is severed. WARDEN has fallen. The compound is silent.':'Solid cover blocks its fire. Break the targeting beam, then hit the blue core during cooling. Your shield recovers after five seconds out of fire.';
 const elapsed=`${Math.floor(state.time/60)}:${String(Math.floor(state.time%60)).padStart(2,'0')}`;
 $('result-stats').textContent=`${elapsed} ELAPSED · ${state.kills} ESCORTS DOWN · ${state.shots?Math.round(state.hits/state.shots*100):0}% ACCURACY`;
 $('result-stats').classList.remove('hidden');$('resume').classList.add('hidden');$('pause').classList.add('hidden');$('touch-controls').classList.add('hidden');
 if(document.pointerLockElement)document.exitPointerLock();if(won)audio.confirm();setTimeout(()=>{if(state.over)audio.setPaused(true);},won?550:100);
 const report=$('result-stats').textContent;
 const mementos=Object.entries(humanObjectives.status().achievements).filter(([,found])=>found).map(([id])=>HUMAN_ACHIEVEMENTS[id]?.name).filter(Boolean);
 endScreen.show({won,outcome:won?'FAILSAFE NEUTRALIZED':'OPERATOR DOWN',nextUrl:'',nextLabel:'CONTINUE TO LOWER STATION',report:report+'\n\nFIELD MEMENTOS / '+(mementos.join(' · ')||'NONE')+(!won?'\n\n'+$('pause-description').textContent:'')});
}

function damage(amount,source='drone'){if(!(amount>0)||!Number.isFinite(amount)||state.mode==='recon'||state.over)return;if(source==='drone'&&humanObjectives.absorbDroneHit()){state.lastDamage=state.time;state.damage=.16;return;}state.lastDamage=state.time;state.damage=.8;if(tuning().stealth&&source==='drone'){player.shield=0;player.health=0;audio.tone(85,.16,'triangle',.09,38);finish(false);return;}const shieldLoss=Math.min(player.shield,amount);player.shield-=shieldLoss;player.health=Math.max(0,player.health-(amount-shieldLoss));audio.tone(85,.16,'triangle',.09,38);if(player.health<=0)finish(false);}
function addTracer(a,b,colorMat=tracerMat,lifetime=.065,radius=.012){const d=b.clone().sub(a),mesh=new THREE.Mesh(tracerGeo,colorMat);mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(v3(0,1,0),d.clone().normalize());mesh.scale.set(radius,d.length(),radius);scene.add(mesh);effects.push({mesh,life:lifetime});}
function sparks(position,enemy=false,count=6){for(let i=0;i<count;i++){const mesh=new THREE.Mesh(sphereGeo,enemy?tracerMat:hostileMat);mesh.position.copy(position);mesh.scale.setScalar(.018+Math.random()*.04);scene.add(mesh);effects.push({mesh,life:.22+Math.random()*.23,velocity:v3((Math.random()-.5)*4,Math.random()*3,(Math.random()-.5)*4)});}}
function reload(){if(serviceLift.active||state.climbing||state.reloading||state.ammo===36||state.reserve<=0||state.over)return;state.reloading=1.65;audio.reload();}
function shoot(){if(serviceLift.active||state.climbing||state.paused||state.map||state.over||state.reloading||state.time<state.nextShot)return;if(!state.ammo){reload();return;}state.ammo--;state.shots++;state.nextShot=state.time+.105;state.recoil=1;audio.shoot();if(tuning().stealth)stealth.hear(enemies,player,state,28);if(!tuning().stealth&&state.mode==='combat'&&tuning().response)for(const e of enemies){if(e.alive&&Math.hypot(e.x-player.x,e.z-player.z)<24){e.interest=4.5;e.lastKnown={x:player.x,z:player.z};}}const o=playerEye().clone(),d=forward().clone();if(state.ads<.985){const spread=.008*(1-state.ads);d.x+=(Math.random()-.5)*spread;d.y+=(Math.random()-.5)*spread;d.normalize();}let closest=wallDistance(o,d,135),hitEnemy=null;
for(const e of enemies){if(!e.alive)continue;const center=v3(e.x,e.y+.54,e.z),to=center.clone().sub(o),along=to.dot(d),perp=to.lengthSq()-along*along,radius=.67;if(along>0&&perp<radius*radius){const dist=along-Math.sqrt(radius*radius-perp);if(dist<closest){closest=dist;hitEnemy=e;}}}
let cameraHit=security.hitTest(o,d,closest);if(cameraHit){closest=cameraHit.distance;hitEnemy=null;}
const bossHit=boss.hitTest(o,d,closest);if(bossHit){closest=bossHit.distance;hitEnemy=null;cameraHit=null;}
const end=o.clone().addScaledVector(d,closest);right.set(Math.cos(player.yaw),0,-Math.sin(player.yaw));const muzzle=o.clone().addScaledVector(d,.58).addScaledVector(right,.17*(1-state.ads));muzzle.y-=.12;addTracer(muzzle,end);if(closest<130)sparks(end,!!hitEnemy,hitEnemy?6:3);
if(bossHit){state.hits++;state.hit=.18;state.coreHit=bossHit.weak;state.hitLabel=bossHit.weak?'CORE HIT':'ARMOUR';audio.bossHit(bossHit.weak);boss.hit(bossHit);sparks(end,bossHit.weak,bossHit.weak?12:4);}
if(cameraHit){state.hits++;state.hit=.18;state.coreHit=false;state.hitLabel='HIT';audio.hit();sparks(end,true,8);if(security.hit(cameraHit.camera,23)&&!tuning().stealth)state.score+=60;}
if(hitEnemy){hitEnemy.hp-=23;state.hits++;state.hit=.18;state.coreHit=false;state.hitLabel='HIT';audio.hit();hitEnemy.group.rotation.z=(Math.random()-.5)*.25;if(hitEnemy.hp<=0){hitEnemy.alive=false;hitEnemy.group.visible=false;state.kills++;if(!tuning().stealth)state.score+=100;audio.kill();sparks(v3(hitEnemy.x,hitEnemy.y+.5,hitEnemy.z),true,15);notify(tuning().stealth?'DRONE OFFLINE / NO KILL BONUS':'+100  /  DRONE OFFLINE','CONFIRMED',1.6);}}}
function nearestTerminal(){let nearest=null,dist=2.45;for(const t of level.terminals){if(t.done||Math.abs(player.y-t.y)>.85)continue;const d=Math.hypot(player.x-t.x,player.z-t.z);if(d<dist){nearest=t;dist=d;}}return nearest;}
function interact(dt){
 const pressed=keys.has('KeyE');humanObjectives.observeKey(pressed);
 document.querySelector('.interact-key').textContent='E';
 if(state.map||state.over||boss.status().defeated){humanObjectives.cancel();state.hack=0;state.hackId=null;$('interaction').classList.add('hidden');return;}
 if(ladder.interact(pressed,forward().clone())){humanObjectives.cancel();state.hack=0;state.hackId=null;$('interaction').classList.remove('hidden');$('interact-title').textContent=state.climbing?'PAD ACCESS LADDER':'CLIMB PAD LADDER';$('interact-desc').textContent=state.climbing?'W / S climb · Space release · exposed to WARDEN':'Press E to attach · W / S climb';document.querySelector('.interact-key').textContent=state.climbing?'↕':'E';$('interact-progress').style.width=`${state.climbing?clamp(player.y/level.ladder.topY,0,1)*100:0}%`;return;}
 const t=nearestTerminal(),atExit=state.liftPreview&&serviceLift.inCab(player);
 const optional=humanObjectives.nearest(player,forward().clone());
 // Nearest eligible object wins; discoveries never double-trigger an uplink.
 const terminalDistance=t?Math.hypot(player.x-t.x,player.y+player.height-(t.y+1.12),player.z-t.z):Infinity;
 if(optional&&optional.distance<terminalDistance){
  state.hack=0;state.hackId=null;$('interaction').classList.remove('hidden');$('interact-title').textContent=optional.title;$('interact-desc').textContent=optional.description;
  const fraction=humanObjectives.hold(optional,dt,pressed,{player,state});$('interact-progress').style.width=`${fraction*100}%`;return;
 }
 humanObjectives.cancel();
// A completed tag must never start the lift while E remains held.
 if(pressed&&humanObjectives.status().releaseLatch){state.hack=0;$('interaction').classList.add('hidden');return;}
 if(t||atExit){$('interaction').classList.remove('hidden');$('interact-title').textContent=t?`SEVER UPLINK ${t.id}`:'DESCEND TO B1';$('interact-desc').textContent=t?'Hold to override · 1.6 seconds':'Hold to close the doors and descend';const id=t?t.id:'EXIT';if(state.hackId!==id){state.hack=0;state.hackId=id;}
  if(pressed){state.hack+=dt;const required=t?1.6:1;if(state.hack>=required){if(t){t.done=true;security.disableZone(t.id);t.setOffline(true);t.ring.material.color.set(0x7be4ce);$('link-'+t.id).classList.add('done');markers.get(t.id).classList.add('complete');state.score+=300;if(!tuning().stealth)player.shield=Math.min(80,player.shield+25);state.hack=0;audio.confirm();if(boss.status().settled){serviceLift.unlock();level.extraction.pad.material.color.set(0x80ebd0);notify('All uplinks offline. Reach the north service lift.','COMMAND',6);}else notify(`Uplink ${t.id} isolated. ${3-level.terminals.filter(q=>q.done).length} remaining.`,'SYSTEM',4);}else if(serviceLift.begin(player)){campaign.prepare();state.hack=0;mouseDown=aimDown=rightAimHeld=false;keys.clear();analog={x:0,y:0};jumpQueued=false;humanObjectives.cancel();$('interaction').classList.add('hidden');audio.duckScore(.65,10);audio.noise(.7,.12,700);audio.tone(160,.8,'triangle',.055,72);notify('Doors closing. Descending to the lower station.','SERVICE LIFT / B1',5);}}$('interact-progress').style.width=`${Math.min(100,state.hack/required*100)}%`;}else{state.hack=Math.max(0,state.hack-dt*2);$('interact-progress').style.width=`${state.hack/1.6*100}%`;}
 }else{$('interaction').classList.add('hidden');state.hack=0;state.hackId=null;}
}
function updatePlayer(dt){if(ladder.update(dt,keys,analog,jumpQueued)){jumpQueued=false;return;}const crouch=keys.has('KeyC')||keys.has('ControlLeft');let wanted=crouch?1.08:1.78;if(wanted>player.height){for(const c of level.colliders){const p=localXZ(player.x,player.z,c);if(Math.abs(p.x)<c.w/2+.3&&Math.abs(p.z)<c.d/2+.3&&c.minY>player.y+.8&&c.minY<player.y+wanted)wanted=1.08;}}player.height=lerp(player.height,wanted,1-Math.exp(-dt*16));let ax=(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0)+analog.x,az=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0)-analog.y;
if(state.map){ax=az=0;}if(keys.has('ArrowLeft'))player.yaw+=dt*1.55;if(keys.has('ArrowRight'))player.yaw-=dt*1.55;const length=Math.hypot(ax,az);if(length>1){ax/=length;az/=length;}const sprint=keys.has('ShiftLeft')&&az>0&&!crouch&&!aimDown&&state.stamina>1&&length>.1,speed=crouch?2.25:sprint?7.4:aimDown?3:4.6;player.speed=length>.01?speed*Math.min(length,1):0;if(sprint)state.stamina=Math.max(0,state.stamina-dt*18);else state.stamina=Math.min(100,state.stamina+dt*22);
const dx=(ax*Math.cos(player.yaw)-az*Math.sin(player.yaw))*speed*dt,dz=(-ax*Math.sin(player.yaw)-az*Math.cos(player.yaw))*speed*dt;if(jumpQueued&&player.grounded&&!state.map){player.vy=6;player.grounded=false;audio.noise(.07,.07,600);}jumpQueued=false;
let nx=player.x+dx,nz=player.z+dz;const nextFloor=floorAt(nx,nz);if(player.grounded&&nextFloor>player.y&&nextFloor-player.y<.4)player.y=nextFloor;const resolved=resolvePosition(nx,nz);player.x=resolved.x;player.z=resolved.z;
const oldY=player.y;player.vy-=17.5*dt;player.y+=player.vy*dt;let floor=floorAt(player.x,player.z,Math.max(oldY,player.y));if(player.vy>0)for(const c of level.colliders){const p=localXZ(player.x,player.z,c);if(Math.abs(p.x)<c.w/2+.25&&Math.abs(p.z)<c.d/2+.25&&oldY+player.height<=c.minY+.04&&player.y+player.height>c.minY){player.y=c.minY-player.height-.015;player.vy=0;}}if(player.y<=floor){const impact=player.vy;player.y=floor;player.vy=0;player.grounded=true;if(impact<-7)audio.step();}else player.grounded=false;
if(player.speed>.25&&player.grounded){bob+=dt*(sprint?12:8.8);stepAt+=dt;if(stepAt>(sprint?.32:.47)){stepAt=0;audio.step(sprint);}}else stepAt=.2;if(!tuning().stealth&&state.time-state.lastDamage>5)player.shield=Math.min(80,player.shield+dt*15);
for(const p of level.pickups)if(!p.taken&&Math.hypot(player.x-p.x,player.z-p.z)<1.65&&(player.health<100||state.reserve<540)){p.taken=true;p.group.visible=false;player.health=Math.min(100,player.health+40);state.reserve=Math.min(720,state.reserve+108);notify(tuning().stealth?'Field kit recovered. Ammunition replenished.':'Field kit recovered. Health and ammunition replenished.','SUPPLY',3);audio.confirm();}}
function updateEnemies(dt){if(tuning().stealth){stealth.update(dt,enemies,player,state,security,$('quality').value);return;}updateLegacyEnemies(dt);}
function updateLegacyEnemies(dt){const config=tuning(),alert=security.alertRemaining>0;
for(const e of enemies){if(!e.alive)continue;
 const distance=Math.hypot(player.x-e.x,player.z-e.z),eye=v3(e.x,e.y+.54,e.z),target=v3(player.x,player.y+player.height*.83,player.z),to=target.clone().sub(eye),len=to.length(),dir=to.normalize();
 const visible=distance<(alert&&config.response?34:30)&&wallDistance(eye,dir,len+.02)>len-.1;
 e.interest=Math.max(0,e.interest-dt);e.engaged=visible&&state.mode==='combat'&&state.time>=5;
 if(state.mode==='combat'&&config.response){
   if(visible){e.interest=5;e.lastKnown={x:player.x,z:player.z};}
   else if(alert&&Math.hypot(e.anchorX-security.lastKnown.x,e.anchorZ-security.lastKnown.z)<32){e.interest=3;e.lastKnown={...security.lastKnown};}
 }
 let desiredX=e.anchorX+Math.sin(state.time*.6+e.phase)*1.05,desiredZ=e.anchorZ+Math.cos(state.time*.48+e.phase)*.68;
 if(config.response&&state.mode==='combat'&&state.time>=5&&e.interest>0){
   // A six-meter response envelope keeps each sentry in its authored lane.
   let dx=e.lastKnown.x-e.anchorX,dz=e.lastKnown.z-e.anchorZ,d=Math.hypot(dx,dz);
   if(d>6){dx*=6/d;dz*=6/d;}
   desiredX=e.anchorX+dx+Math.sin(state.time*1.15+e.phase)*1.3;
   desiredZ=e.anchorZ+dz+Math.cos(state.time*.9+e.phase)*.9;
 }
 const delta=v3(desiredX-e.x,0,desiredZ-e.z),length=delta.length();
 if(length>.02){
   const step=Math.min(length,dt*(e.interest>0?config.response||1:1.15)),heading=delta.normalize();
   // Test the same collision boxes as bullets. Side probes prevent body clipping.
   for(const turn of [0,.85,-.85]){
     const cs=Math.cos(turn),sn=Math.sin(turn),move=v3(heading.x*cs-heading.z*sn,0,heading.x*sn+heading.z*cs),nx=e.x+move.x*step,nz=e.z+move.z*step;
     const floor=floorAt(nx,nz,e.baseY),oldFloor=floorAt(e.x,e.z,e.baseY);
     const side=v3(-move.z,0,move.x).multiplyScalar(.42);
     if(Math.abs(floor-oldFloor)<.4&&wallDistance(eye,move,step+.8)>step+.79&&wallDistance(eye.clone().add(side),move,step+.65)>step+.64&&wallDistance(eye.clone().sub(side),move,step+.65)>step+.64){e.x=nx;e.z=nz;break;}
   }
 }
 e.statusLight?.update(e.engaged?'locked':e.interest>0?'suspicious':'patrol');
 e.y=e.baseY+Math.sin(state.time*1.6+e.phase)*.15;e.group.position.set(e.x,e.y,e.z);e.group.rotation.z*=Math.exp(-dt*8);
 e.group.rotation.y=visible?Math.atan2(player.x-e.x,player.z-e.z):e.interest>0?Math.atan2(e.lastKnown.x-e.x,e.lastKnown.z-e.z):Math.sin(state.time*.4+e.phase)*.65;
 if(state.mode==='recon'||state.time<5)continue;e.cooldown-=dt;
 if(visible&&e.cooldown<=.6){e.charge+=dt;e.group.rotation.z=Math.sin(state.time*25)*.025;}else e.charge=0;
 if(visible&&e.cooldown<=0){
   const spread=config.spread,aim=target.clone().add(v3((Math.random()-.5)*spread,(Math.random()-.5)*.35,(Math.random()-.5)*spread)).sub(eye).normalize(),mesh=new THREE.Mesh(sphereGeo,hostileMat);
   mesh.scale.setScalar(.082);mesh.position.copy(eye).addScaledVector(aim,.75);scene.add(mesh);
   projectiles.push({mesh,pos:mesh.position,dir:aim,life:3.2,previous:mesh.position.clone(),speed:config.boltSpeed,damage:config.damage});
   e.cooldown=(alert&&config.response?config.cadence*.64:config.cadence)+Math.random()*.6;e.charge=0;
   audio.tone(185,.1,'sawtooth',Math.max(.014,.052*(1-distance/40)),80);
 }
}}
function fireStealthBolt(e,target){
 const eye=v3(e.x,e.y+.54,e.z),aim=target.clone().sub(eye).normalize(),mesh=new THREE.Mesh(sphereGeo,hostileMat);
 mesh.scale.setScalar(.095);mesh.position.copy(eye).addScaledVector(aim,.7);scene.add(mesh);
 projectiles.push({mesh,pos:mesh.position,dir:aim,life:3.2,previous:mesh.position.clone(),speed:18,damage:1000,source:'drone'});
 audio.tone(185,.1,'sawtooth',.04,80);
}
function updateProjectiles(dt){
 for(let i=projectiles.length-1;i>=0;i--){
  const p=projectiles[i],travel=dt*(p.speed||19);p.life-=dt;p.previous.copy(p.pos);
  const wall=wallDistance(p.pos,p.dir,travel+.04);let remove=p.life<0,impact=false;
  if(!remove){
   p.pos.addScaledVector(p.dir,Math.min(travel,wall));
   if(wall<=travel+.03){remove=true;impact=true;}
   const center=v3(player.x,player.y+player.height*.64,player.z),segment=p.pos.clone().sub(p.previous),length=segment.lengthSq();
   const distanceTo=point=>p.previous.clone().addScaledVector(segment,clamp(point.clone().sub(p.previous).dot(segment)/Math.max(length,.00001),0,1)).distanceTo(point);
   if(!remove&&distanceTo(center)<.5){if(!p.splash)damage(p.damage||11,p.source||'drone');remove=true;impact=true;}
   if(!remove&&p.target&&distanceTo(p.target)<.35){remove=true;impact=true;}
   if(impact&&p.splash){
    const blast=p.pos.clone().addScaledVector(p.dir,-.12),delta=center.clone().sub(blast),d=delta.length();
    if(d<p.splash&&wallDistance(blast,delta.normalize(),d+.05)>d-.08)damage(p.damage*(1-d/p.splash*.4),'warden');
    sparks(blast,false,14);audio.noise(.32,.22,450);
   }
  }
  if(remove){scene.remove(p.mesh);projectiles.splice(i,1);}
 }
 for(let i=effects.length-1;i>=0;i--){const e=effects[i];e.life-=dt;if(e.velocity){e.mesh.position.addScaledVector(e.velocity,dt);e.velocity.y-=dt*6;e.mesh.scale.multiplyScalar(Math.exp(-dt*1.5));}if(e.life<=0){scene.remove(e.mesh);effects.splice(i,1);}}
}
function simulate(dt){if(state.over)return;state.time+=dt;if(boss.status().victoryReady&&!state.liftPreview&&state.mode==='combat'){finish(true);return;}if(serviceLift.moving)renderer.shadowMap.needsUpdate=true;const priorLift=serviceLift.mode;const arrived=serviceLift.update(dt,player);if(priorLift!=='descending'&&serviceLift.mode==='descending'){audio.startLiftMotor();renderer.shadowMap.needsUpdate=true;}if(serviceLift.active){player.speed=0;state.ads=lerp(state.ads,0,Math.min(1,dt*8));state.recoil=0;state.damage=Math.max(0,state.damage-dt);if(arrived){audio.stopLiftMotor();state.score+=500;audio.noise(.3,.1,500);finish(true);}return;}state.damage=Math.max(0,state.damage-dt*.75);state.hit=Math.max(0,state.hit-dt);state.recoil*=Math.exp(-dt*19);state.ads=lerp(state.ads,aimDown&&!state.climbing&&!state.map&&!state.reloading?1:0,1-Math.exp(-dt*12));if(state.reloading>0){state.reloading-=dt;if(state.reloading<=0){const amount=Math.min(36-state.ammo,state.reserve);state.ammo+=amount;state.reserve-=amount;state.reloading=0;audio.tone(700,.09,'triangle',.08,350);}}updatePlayer(dt);security.update(dt,player,state);if(mouseDown)shoot();boss.update(dt,player,state);updateEnemies(dt);updateProjectiles(dt);if(!state.over)interact(dt);}
// Warden title: a lower western view across the pad, distinct from Compound's southern overview.
function updateCamera(){if(!state.started||state.over){camera.fov=adsConfig.baseFov;camera.updateProjectionMatrix();camera.position.set(-31+Math.sin(realClock*.05)*.8,8.4,8);camera.lookAt(-7,5.8,-25);return;}const motion=state.motion&&player.grounded&&player.speed>.1?Math.sin(bob)*.027*(1-state.ads*.92):0;camera.position.set(player.x,player.y+player.height+motion,player.z);camera.rotation.set(player.pitch+(state.motion?state.recoil*.006*(1-state.ads*.9):0),player.yaw,0,'YXZ');const fov=lerp(adsConfig.baseFov,adsConfig.aimFov,state.ads)+(keys.has('ShiftLeft')&&player.speed>5?4:0);if(Math.abs(camera.fov-fov)>.01){camera.fov=fov;camera.updateProjectionMatrix();}headlamp.position.copy(camera.position);headlamp.intensity=serviceLift.inCab(player)||serviceLift.active?.025:.22;
const reloadPose=state.reloading>0?Math.sin(clamp((1.65-state.reloading)/1.65,0,1)*Math.PI):0,walk=state.motion?Math.min(player.speed,5)/5*(1-state.ads*.94):0;weapon.visible=!state.climbing;weapon.position.set(lerp(.32,-.0009321677,state.ads)+Math.cos(bob*.5)*.008*walk,-.47+state.ads*.101911695+Math.sin(bob)*.009*walk-reloadPose*.27-(serviceLift.active?.65:0),-.83+state.ads*.18+state.recoil*.063);weapon.rotation.set(reloadPose*.62,Math.PI+reloadPose*.24,-reloadPose*.28+Math.cos(bob*.5)*.006*walk);flash.visible=state.recoil>.5&&state.reloading===0;flash.rotation.z=realClock*40;weaponLight.intensity=state.recoil>.5?1.6:0;document.body.classList.toggle('aiming',state.ads>.5);document.body.classList.toggle('climbing',!!state.climbing);document.body.classList.toggle('lift-travelling',serviceLift.active);}
const compassParts=[];for(let i=-36;i<72;i++){const deg=((i*15)%360+360)%360,label=({0:'N',90:'E',180:'S',270:'W'})[deg]||deg;compassParts.push(`<span class="${deg%90===0?'cardinal':''}">${label}</span>`);}$('compass').innerHTML=compassParts.join('');
function mapDraw(canvas,large=false){const c=canvas.getContext('2d'),w=canvas.width,h=canvas.height;c.clearRect(0,0,w,h);c.fillStyle=large?'#142e3b':'rgba(15,39,53,.7)';c.fillRect(0,0,w,h);const scale=large?Math.min(w/97,h/138):1.48,cx=large?0:player.x,cz=large?-17:player.z,X=x=>w/2+(x-cx)*scale,Z=z=>h/2+(z-cz)*scale;c.strokeStyle='rgba(146,195,210,.10)';c.lineWidth=1;for(let x=-50;x<=50;x+=10){c.beginPath();c.moveTo(X(x),0);c.lineTo(X(x),h);c.stroke();}for(let z=-90;z<=50;z+=10){c.beginPath();c.moveTo(0,Z(z));c.lineTo(w,Z(z));c.stroke();}
for(const b of level.colliders){if(b.type==='boundary')continue;c.save();c.translate(X(b.x),Z(b.z));c.rotate(-b.angle);c.fillStyle=b.type==='roof'?'rgba(101,149,167,.14)':b.type==='deck'?'rgba(198,163,113,.25)':'rgba(132,170,184,.34)';c.strokeStyle='rgba(170,205,215,.34)';c.lineWidth=.5;c.fillRect(-b.w*scale/2,-b.d*scale/2,b.w*scale,b.d*scale);if(large)c.strokeRect(-b.w*scale/2,-b.d*scale/2,b.w*scale,b.d*scale);c.restore();}for(const r of level.ramps){c.save();c.translate(X(r.x),Z(r.z));c.rotate(-r.angle);c.fillStyle='#9b886347';c.fillRect(-r.w*scale/2,-r.d*scale/2,r.w*scale,r.d*scale);c.restore();}
if(large&&tuning().stealth){for(const route of stealth.routes){c.save();c.strokeStyle=route.band==='HIGH'?'#bcaadd78':'#85d5dc66';c.lineWidth=1;c.setLineDash([4,5]);c.beginPath();route.points.forEach((p,i)=>{if(i)c.lineTo(X(p[0]),Z(p[2]));else c.moveTo(X(p[0]),Z(p[2]));});c.closePath();c.stroke();c.restore();}}
for(const t of level.terminals){c.save();c.translate(X(t.x),Z(t.z));c.rotate(Math.PI/4);c.fillStyle=t.done?'#7fe5cc':'#efd1ac';const s=large?7:4;c.fillRect(-s,-s,s*2,s*2);c.restore();if(large){c.fillStyle='#dde9e9';c.font='11px monospace';c.fillText(`${t.id} / ${t.name.toUpperCase()}`,X(t.x)+(t.id==='A'?-126:13),Z(t.z)-9);}}for(const e of enemies){if(!e.alive||(!large&&Math.hypot(player.x-e.x,player.z-e.z)>31))continue;
 if(e.route&&tuning().stealth){const angle=Math.atan2(Math.cos(e.yaw),Math.sin(e.yaw)),radius=stealth.sensorInfo(e).range*scale;c.beginPath();c.moveTo(X(e.x),Z(e.z));c.arc(X(e.x),Z(e.z),radius,angle-e.halfFov,angle+e.halfFov);c.closePath();c.fillStyle=e.engaged?'#ff806335':e.suspicion>0?'#e7b57e2c':'#a5d7de12';c.fill();c.strokeStyle=e.engaged?'#ff806380':'#afcbd333';c.lineWidth=.65;c.stroke();
 if(e.route.band==='HIGH'){c.strokeStyle='#bfb0e7';c.beginPath();c.arc(X(e.x),Z(e.z),large?6:4,0,Math.PI*2);c.stroke();}
 if(large){c.font='9px monospace';c.fillStyle='#d1e0e3';c.fillText(`${e.id} / H${Math.round(e.y)} / R${e.range}m`,X(e.x)+8,Z(e.z)-8);}}
 c.fillStyle=e.engaged?'#ff756a':e.route?'#e7bc90':'#fa8b75';c.beginPath();c.arc(X(e.x),Z(e.z),large?3.3:2.4,0,Math.PI*2);c.fill();}
for(const cam of security.cameras){if(!tuning().cameras)continue;const px=X(cam.x),pz=Z(cam.z),r=large?4:2;
c.fillStyle=cam.online?'#eab780':'#607988';c.save();c.translate(px,pz);c.rotate(Math.PI/4);c.fillRect(-r,-r,r*2,r*2);c.restore();
if(large&&cam.online){const a=Math.atan2(cam.direction.z,cam.direction.x);c.beginPath();c.moveTo(px,pz);c.arc(px,pz,24*scale,a-.52,a+.52);c.closePath();c.fillStyle=security.alertRemaining>0?'#f2776928':'#eab78020';c.fill();}}
const bs=boss.status();if(!bs.defeated){c.fillStyle='#ff6652';c.beginPath();c.arc(X(bs.position[0]),Z(bs.position[2]),large?7:4,0,Math.PI*2);c.fill();if(large){c.fillStyle='#ffb2a0';c.fillText('WARDEN',X(bs.position[0])+10,Z(bs.position[2])-9);}}
const ex=level.extraction;c.strokeStyle=bs.settled?'#8af0d2':'#98afb8';c.lineWidth=large?2:1;c.strokeRect(X(ex.x)-3*scale,Z(ex.z)-3*scale,6*scale,6*scale);if(large){c.fillStyle='#c1d9df';c.font='10px monospace';c.fillText('LIFT / B1',X(ex.x)+21,Z(ex.z)+3);c.fillStyle='#7e9da9';c.fillText('SOUTH APPROACH',X(-14),Z(42));c.fillStyle='#c5dce3';c.font='14px monospace';c.fillText('N ↑',w-48,30);}c.save();c.translate(X(player.x),Z(player.z));c.rotate(-player.yaw);c.fillStyle='#ddf9fa';c.strokeStyle='#172f3f';c.lineWidth=2;c.beginPath();c.moveTo(0,-7);c.lineTo(-4.5,5);c.lineTo(0,3);c.lineTo(4.5,5);c.closePath();c.fill();c.stroke();c.restore();}
let lastFieldReadout='',lastRecordReadout='';
function updateFieldRecords(finds=humanObjectives.status()){
 const current=finds.charge?'1 HIT BUFFER READY':'';
 if(current!==lastFieldReadout){lastFieldReadout=current;$('field-findings').textContent=current;}$('field-findings').classList.toggle('hidden',!current);
 const records=JSON.stringify([finds.achievements,finds.storageAvailable]);
 if(records!==lastRecordReadout){lastRecordReadout=records;const count=Object.keys(finds.achievements).length;$('field-record-count').textContent=`${count} / 2`;
  for(const [id,definition] of Object.entries(HUMAN_ACHIEVEMENTS)){const unlocked=!!finds.achievements[id],row=$('record-'+id);row.classList.toggle('unlocked',unlocked);row.querySelector('strong').textContent=unlocked?definition.name:'Undiscovered';row.querySelector('small').textContent=unlocked?definition.description:'Explore beyond the directive.';row.querySelector('span').textContent=unlocked?'◆':'◇';}
  $('field-record-storage').textContent=finds.storageAvailable?'Trophies save in this browser when storage is available. Run-only protection resets on redeploy.':'Browser storage is unavailable. Trophies last for this session only.';
 }
}
function setHUDText(id,value){const el=$(id),text=String(value);if(el.textContent!==text)el.textContent=text;}
function updateHUD(){updateCombatUI(state,player);const covert=tuning().stealth&&state.mode==='combat';const finds=humanObjectives.status();updateFieldRecords(finds);$('hud').classList.toggle('covert',covert);$('hud').classList.toggle('buffered',covert&&!!finds.charge);const complete=level.terminals.filter(t=>t.done).length;setHUDText('mission-count','NETWORK OFFLINE');setHUDText('shield-value',covert?(finds.charge?'1':'—'):Math.ceil(player.shield));setHUDText('shield-label',covert?(finds.charge?'HIT BUFFER':'UNARMORED'):'SHIELD');setHUDText('health-value',Math.ceil(player.health));$('shield-bar').style.width=covert?(finds.charge?'100%':'0%'):`${player.shield/80*100}%`;$('shield-bar').classList.toggle('ration-buffer',covert&&!!finds.charge);$('stamina-bar').style.width=state.stamina+'%';setHUDText('ammo',String(state.ammo).padStart(2,'0'));setHUDText('reserve',state.reserve);setHUDText('weapon-state',state.reloading?'RELOADING…':state.ammo?'':'EMPTY');setHUDText('hostiles',`${boss.status().defeated?0:1} WARDEN · ${enemies.filter(e=>e.alive).length} ESCORTS`);setHUDText('suit-status',covert?(finds.charge?'ONE HIT BUFFERED':'ONE HIT IS FATAL'):player.shield<15?'SHIELD CRITICAL':state.time-state.lastDamage>5&&player.shield<80?'SHIELD RECHARGING':'EXOSUIT ONLINE');$('damage').style.opacity=state.damage;$('hitmarker').style.opacity=Math.min(1,state.hit*12);$('hitmarker').classList.toggle('core-hit',!!state.coreHit);setHUDText('hit-confirm',state.hit>0?(state.hitLabel||'HIT'):'');$('toast').style.opacity=state.time<state.toastUntil?'1':'0';
const watch=$('security-status'),count=security.cameras.filter(c=>c.online).length,alert=security.alertRemaining>0;
const threat=covert?enemies.find(e=>e.id===state.threatId):null,droneMore=covert&&state.droneSuspicion>security.suspicion;
const suspicion=Math.max(security.suspicion,covert?state.droneSuspicion:0),locked=covert&&state.droneEngaged,searching=covert&&enemies.some(e=>e.alive&&e.interest>0);
watch.classList.toggle('hidden',state.mode==='recon'||!tuning().cameras);watch.classList.toggle('alert',alert||locked);watch.classList.toggle('detecting',!alert&&!locked&&suspicion>0);watch.classList.toggle('covert',covert);
let bearing='';if(threat){const dx=threat.x-player.x,dz=threat.z-player.z,side=dx*Math.cos(player.yaw)-dz*Math.sin(player.yaw),front=-dx*Math.sin(player.yaw)-dz*Math.cos(player.yaw);bearing=Math.abs(front)>Math.abs(side)?front>0?'AHEAD':'BEHIND':side>0?'RIGHT':'LEFT';}
setHUDText('security-label',locked?'LOCKED / BREAK SIGHT':droneMore?(threat?.seen?'DRONE ACQUIRING':'CONTACT LOST / STAY HIDDEN'):alert?'GRID SEARCH':security.suspicion>0?'CAMERA ACQUIRING':searching?'PATROL INVESTIGATING':covert?'UNSEEN / STAY LOW':count?'SURVEILLANCE ACTIVE':'SURVEILLANCE OFFLINE');
setHUDText('security-detail',droneMore&&threat?`${threat.id} · ${bearing} · H${Math.round(threat.y)}m · SENSOR ${threat.range}m`:alert?`Stay hidden · ${Math.ceil(security.alertRemaining)}s`:security.suspicion>0?`${security.detectedBy} · take cover`:covert?`${count} CCTV online · watch the patrol gaps`:`${count} / 3 cameras online`);
$('detection-fill').style.width=`${alert?100:Math.round(suspicion*100)}%`;
$('stealth-readout').classList.toggle('hidden',!covert);setHUDText('stealth-posture',player.height<1.3?'CROUCHED / QUIET':player.speed>5?'SPRINTING / AUDIBLE':player.speed>.1?'MOVING / EXPOSED':'STILL / WATCH THE SCAN');
setHUDText('stealth-stats',`${state.droneAlerts+security.alerts} ALERTS · ${state.shots} SHOTS`);
let zone='CENTRAL YARD';if(player.z>17)zone='SOUTH APPROACH';if(player.x<-16&&player.z<10&&player.z>-19)zone='THERMAL SERVICE TUNNEL';if(player.x>17&&player.y>2.6)zone='EAST LOADING DECK';if(Math.abs(player.x)<6.7&&Math.abs(player.z+13)<6.7&&player.y>4.8)zone='DRONE PAD';if(state.climbing)zone='PAD ACCESS LADDER';if(player.z<-31)zone='NIVALIS RELAY ARRAY';if(player.z<-60)zone='NORTH SERVICE LIFT';if(serviceLift.active)zone=serviceLift.mode==='arrived'?'B1 / LOWER STATION':`SERVICE LIFT / −${Math.round(serviceLift.travel*18)} m`;setHUDText('zone-name',zone);const heading=(((-player.yaw*180/Math.PI)%360)+360)%360;setHUDText('heading',`${String(Math.round(heading)%360).padStart(3,'0')}°`);$('compass').style.transform=`translateX(${$('compass').parentElement.clientWidth/2-22.5-(36+heading/15)*45}px)`;
const bs=boss.status(),next=state.liftPreview?level.extraction:{x:bs.position[0],z:bs.position[2]};
setHUDText('objective-name',serviceLift.active?'Descending to B1':state.liftPreview?'Board the service lift':bs.defeated?(bs.settled?'Warden neutralized':'Keep clear of the launch pad'):'Disable the Warden');
setHUDText('objective-distance',`${Math.round(Math.hypot(player.x-next.x,player.z-next.z))} m`);
setHUDText('boss-phase',bs.defeated?'NEUTRALIZED':`PHASE 0${bs.phase} / 03`);
$('boss-health').style.width=`${bs.health/bs.maxHealth*100}%`;setHUDText('boss-health-value',`${Math.ceil(bs.health/bs.maxHealth*100)}%`);
$('aftermath-skip').classList.toggle('hidden',!bs.settled||state.over||state.mode!=='combat');
$('attack-warning').classList.toggle('hidden',!bs.warningSeconds&&bs.mode!=='sweep');setHUDText('attack-warning',bs.mode==='sweep'?'SWEEP ACTIVE · STAY CLEAR':bs.mode==='sweep-aim'?`SWEEP LANE · MOVE OFF THE LINE · ${bs.warningSeconds.toFixed(1)}s`:bs.mode==='strike'?`GROUND STRIKE · MOVE · ${bs.warningSeconds.toFixed(1)}s`:`TARGET LOCK · TAKE COVER · ${bs.warningSeconds.toFixed(1)}s`);
setHUDText('boss-status',bs.defeated?(bs.settled?'DEFENSE SYSTEM OFFLINE':'WARDEN FALLING · STAND CLEAR'):bs.mode==='repair'?'REPAIRING · HIT AMBER CORE':bs.vulnerable?'COOLING · BLUE CORE EXPOSED':bs.mode==='aim'?'TARGET LOCK · BREAK SIGHT':bs.mode.startsWith('sweep')?'SWEEP LANE · MOVE OR TAKE COVER':bs.mode==='strike'?'GROUND STRIKE · MOVE':bs.mode==='launch'?'LAUNCH SEQUENCE':bs.seen?'TRACKING':'SEARCHING LAST CONTACT');
$('boss-panel').classList.toggle('vulnerable',bs.vulnerable);$('security-status').classList.add('hidden');
camera.updateMatrixWorld();const showMarker=(m,x,y,z,done=false)=>{const p=v3(x,y,z),dist=p.distanceTo(camera.position),towards=p.clone().sub(camera.position).dot(camera.getWorldDirection(v3()));p.project(camera);const visible=towards>0&&Math.abs(p.x)<.92&&Math.abs(p.y)<.79&&dist>3.3&&!done;m.style.display=visible?'flex':'none';if(visible){m.style.transform=`translate(${(p.x*.5+.5)*innerWidth-10}px,${(-p.y*.5+.5)*innerHeight}px)`;m.querySelector('span').textContent=`${Math.round(dist)} m`;}};for(const t of level.terminals)showMarker(markers.get(t.id),t.x,t.y+2.3,t.z,t.done);exitMarker.classList.toggle('hidden',!state.liftPreview||serviceLift.active);if(state.liftPreview&&!serviceLift.active)showMarker(exitMarker,level.extraction.x,3.3,level.extraction.z);if(state.navigation)mapDraw($('radar'));if(state.map)mapDraw($('map'),true);}
function resize(){renderer.setSize(innerWidth,innerHeight,false);camera.aspect=viewCamera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();viewCamera.updateProjectionMatrix();}window.addEventListener('resize',resize);
function skipAftermath(){if(!state.paused&&!state.over&&state.mode==='combat'&&boss.status().settled)finish(true);}
$('aftermath-skip').addEventListener('click',skipAftermath);
$('deploy').addEventListener('click',()=>start('combat'));$('explore').addEventListener('click',()=>liftTour?startLiftTour():start('recon'));$('resume').addEventListener('click',resume);$('restart').addEventListener('click',()=>liftTour&&state.mode==='recon'?startLiftTour():start(state.mode));$('touch-pause').addEventListener('click',pause);$('hud-pause').addEventListener('click',pause);$('map-close').addEventListener('click',()=>{state.map=false;$('tactical').classList.add('hidden');document.activeElement?.blur?.();});$('touch-map').addEventListener('click',()=>{if(!state.started||state.paused||state.over)return;humanObjectives.cancel();aimDown=rightAimHeld=false;state.map=!state.map;touchLook?.reset();$('tactical').classList.toggle('hidden',!state.map);mouseDown=false;});$('sensitivity').addEventListener('input',e=>{state.sensitivity=Number(e.target.value);savePreferences();});$('audio-toggle').addEventListener('click',()=>{audio.setMuted(!audio.muted);$('audio-toggle').textContent=audio.muted?'OFF':'ON';savePreferences();});$('motion-toggle').addEventListener('click',()=>{state.motion=!state.motion;$('motion-toggle').textContent=state.motion?'ON':'OFF';savePreferences();});$('quality').addEventListener('change',e=>{const q=e.target.value;renderer.setPixelRatio(Math.min(devicePixelRatio||1,q==='high'?1.75:q==='low'?.8:1.35));renderer.shadowMap.enabled=q!=='low';resize();renderer.shadowMap.needsUpdate=true;environment.setQuality(q);atmosphere.setQuality(q);storm.setQuality(q);security.setQuality(q);savePreferences();});
state.navigation=preferences.navigation===true;$('navigation-toggle').checked=state.navigation;document.body.classList.toggle('navigation-enabled',state.navigation);$('navigation-toggle').addEventListener('change',e=>{state.navigation=e.target.checked;document.body.classList.toggle('navigation-enabled',state.navigation);savePreferences();});
state.reducedFlashing=preferences.reducedFlashing===true||matchMedia('(prefers-reduced-motion: reduce)').matches;
function showFlashing(){serviceLift.setReducedFlashing(state.reducedFlashing);boss.setReducedFlashing(state.reducedFlashing);storm.setReducedFlashing(state.reducedFlashing);atmosphere.setReducedFlashing(state.reducedFlashing);$('flashing-toggle').textContent=state.reducedFlashing?'REDUCED':'STANDARD';}
$('flashing-toggle').addEventListener('click',()=>{state.reducedFlashing=!state.reducedFlashing;showFlashing();savePreferences();});showFlashing();
$('ambience').value=Math.round((typeof preferences.ambience==='number'?clamp(preferences.ambience,0,1):.58)*100);audio.setAmbience(Number($('ambience').value)/100);$('ambience-value').textContent=$('ambience').value+'%';
$('ambience').addEventListener('input',e=>{audio.setAmbience(Number(e.target.value)/100);$('ambience-value').textContent=e.target.value+'%';savePreferences();});
$('music').value=Math.round((typeof preferences.music==='number'&&Number.isFinite(preferences.music)?clamp(preferences.music,0,1):.70)*100);audio.setMusic(Number($('music').value)/100);$('music-value').textContent=$('music').value+'%';
$('music').addEventListener('input',e=>{audio.setMusic(Number(e.target.value)/100);$('music-value').textContent=e.target.value+'%';savePreferences();});
$('breathing').value=Math.round((typeof preferences.breathing==='number'&&Number.isFinite(preferences.breathing)?clamp(preferences.breathing,0,1):.45)*100);audio.setBreathing(Number($('breathing').value)/100);$('breathing-value').textContent=$('breathing').value+'%';
$('breathing').addEventListener('input',e=>{audio.setBreathing(Number(e.target.value)/100);$('breathing-value').textContent=e.target.value+'%';savePreferences();});
state.motion=preferences.motion??!matchMedia('(prefers-reduced-motion: reduce)').matches;state.sensitivity=clamp(Number(preferences.sensitivity)||1,.4,2);audio.setMuted(preferences.muted===true);$('motion-toggle').textContent=state.motion?'ON':'OFF';$('audio-toggle').textContent=audio.muted?'OFF':'ON';$('sensitivity').value=state.sensitivity;
// New preference only; retain the existing storage key and every prior setting.
environment.setFog(preferences.fog);$('fog-density').value=environment.fogStyle;
$('fog-density').addEventListener('change',e=>{environment.setFog(e.target.value);savePreferences();});
if(['high','balanced','low'].includes(preferences.quality)){$('quality').value=preferences.quality;$('quality').dispatchEvent(new Event('change'));}
disableNetwork();
document.addEventListener('pointerlockchange',()=>{if(campaign.enabled)return;locked=document.pointerLockElement===canvas;if(!locked&&state.started&&!state.paused&&!state.over)pause();});document.addEventListener('mousemove',e=>{if(campaign.look(e))return;if(state.started&&!state.paused&&!state.map&&(locked||dragLook)){const mx=locked?e.movementX:e.clientX-lastMouse.x,my=locked?e.movementY:e.clientY-lastMouse.y;player.yaw-=mx*.0021*state.sensitivity*lerp(1,adsConfig.sensitivity,state.ads);player.pitch=clamp(player.pitch-my*.0021*state.sensitivity*lerp(1,adsConfig.sensitivity,state.ads),-1.4,1.4);}lastMouse={x:e.clientX,y:e.clientY};});document.addEventListener('mousedown',e=>{if(e.sourceCapabilities?.firesTouchEvents)return;if(!state.started||state.paused||state.map||e.target.closest('button,input,select'))return;if(e.button===0)mouseDown=true;if(e.button===2){rightAimHeld=true;aimDown=!state.climbing;};if(!locked&&!touch){if(campaign.enabled)requestLock();dragLook=true;lastMouse={x:e.clientX,y:e.clientY};}});document.addEventListener('mouseup',e=>{if(e.sourceCapabilities?.firesTouchEvents)return;if(e.button===0)mouseDown=false;if(e.button===2){rightAimHeld=false;aimDown=keys.has('KeyQ')&&!state.climbing;};dragLook=false;});document.addEventListener('contextmenu',e=>{if(state.started)e.preventDefault();});
document.addEventListener('keydown',e=>{if(e.code!=='Escape'&&e.target.closest('.title-dialog,#menu,#pause'))return;if(e.target.matches('input,select'))return;const accepted=['KeyW','KeyA','KeyS','KeyD','KeyE','KeyR','KeyC','KeyM','KeyP','KeyF','KeyQ','Space','ShiftLeft','ControlLeft','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Escape'];if(accepted.includes(e.code))e.preventDefault();if(e.code==='Escape'){if(state.started&&!state.over){if(state.paused)resume();else pause();}return;}if(!state.started||state.paused)return;if(!e.repeat){if(e.code==='KeyE'&&boss.status().settled){skipAftermath();return;}if(e.code==='KeyR')reload();if(e.code==='Space')jumpQueued=true;if(e.code==='KeyM'){humanObjectives.cancel();aimDown=rightAimHeld=false;state.map=!state.map;touchLook?.reset();$('tactical').classList.toggle('hidden',!state.map);mouseDown=false;}if(e.code==='KeyP'){state.photo=!state.photo;$('hud').classList.toggle('photo',state.photo);}if(e.code==='KeyF'){if(!document.fullscreenElement)document.documentElement.requestFullscreen?.().catch(()=>{});else document.exitFullscreen?.();}}keys.add(e.code);if(e.code==='KeyQ'&&!state.climbing&&!state.map)aimDown=true;});document.addEventListener('keyup',e=>{keys.delete(e.code);if(e.code==='KeyQ')aimDown=rightAimHeld&&!state.climbing;});window.addEventListener('blur',()=>{if(!campaign.enabled)pause();});document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
touchLook=createTouchLook({
 surfaces:[canvas,$('look-pad')],active:()=>state.started&&!state.paused&&!state.over&&!state.map,
 accept:event=>event.clientX>innerWidth*.35,
 look(dx,dy){player.yaw-=dx*.005;player.pitch=clamp(player.pitch-dy*.005,-1.4,1.4);}
});
if(touch){let moveId=null,moveStart={x:0,y:0};const pad=$('move-pad');pad.addEventListener('pointerdown',e=>{e.preventDefault();moveId=e.pointerId;moveStart={x:e.clientX,y:e.clientY};pad.setPointerCapture(e.pointerId);});pad.addEventListener('pointermove',e=>{if(e.pointerId!==moveId)return;let dx=e.clientX-moveStart.x,dy=e.clientY-moveStart.y,d=Math.hypot(dx,dy);if(d>38){dx*=38/d;dy*=38/d;}analog={x:dx/38,y:dy/38};$('move-knob').style.transform=`translate(${dx}px,${dy}px)`;});for(const event of ['pointerup','pointercancel'])pad.addEventListener(event,()=>{moveId=null;analog={x:0,y:0};$('move-knob').style.transform='';});document.querySelectorAll('[data-touch]').forEach(button=>{const action=button.dataset.touch;button.addEventListener('pointerdown',e=>{e.preventDefault();button.setPointerCapture(e.pointerId);if(action==='fire')mouseDown=true;else if(action==='aim')aimDown=!state.climbing;else{keys.add(action);if(action==='Space')jumpQueued=true;if(action==='KeyR')reload();}});for(const event of ['pointerup','pointercancel'])button.addEventListener(event,()=>{if(action==='fire')mouseDown=false;else if(action==='aim')aimDown=false;else keys.delete(action);});});}
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();pause();$('error-message').textContent='The graphics context was lost. Reload this page to reconnect.';$('error').classList.remove('hidden');});window.__START__=()=>start('recon',false);window.__READY__=true;window.__DEBUG__={storm,boss,serviceLift,ladder,adsConfig,weapon,viewCamera,updateCamera,grounding,surfacePilotInfo,state,player,level,humanWorld,humanObjectives,interact,keys,enemies,security,stealth,projectiles,audio,atmosphere,environment,renderer,camera,tuning,rayBox,wallDistance,floorAt,resolvePosition,start,simulate,updateEnemies,updatePlayer,updateProjectiles,updateHUD,shoot,finish,teleport(x,z,y=0){Object.assign(player,{x,z,y,vy:0,grounded:true});},damage};
campaign.attach({
 start:()=>start('combat',false),pause,resume,
 applySettings(p){
  state.motion=p.motion;state.reducedFlashing=p.reducedFlashing;state.sensitivity=p.sensitivity;state.navigation=p.navigation;
  audio.setMuted(p.muted);audio.setMusic(p.music);audio.setAmbience(p.ambience);audio.setBreathing(p.breathing);
  document.body.classList.toggle('navigation-enabled',state.navigation);showFlashing();
  $('sensitivity').value=p.sensitivity;$('navigation-toggle').checked=p.navigation;$('motion-toggle').textContent=p.motion?'ON':'OFF';$('audio-toggle').textContent=p.muted?'OFF':'ON';
  for(const k of ['music','ambience','breathing']){$(k).value=Math.round(p[k]*100);$(k+'-value').textContent=$(k).value+'%';}
  if($('quality').value!==p.quality){$('quality').value=p.quality;$('quality').dispatchEvent(new Event('change'));}
  environment.setFog(p.fog);$('fog-density').value=p.fog;
 },
 look(x,y){if(state.paused||state.over||state.map)return;player.yaw-=x*.0021*state.sensitivity*lerp(1,adsConfig.sensitivity,state.ads);player.pitch=clamp(player.pitch-y*.0021*state.sensitivity*lerp(1,adsConfig.sensitivity,state.ads),-1.4,1.4);},
 mouse(button,down){if(state.paused||state.over||state.map)return;if(button===0)mouseDown=down;if(button===2){rightAimHeld=down;aimDown=down&&!state.climbing;}},
 dispose(){touchLook.dispose();campaign.disposed=true;state.paused=true;audio.setPaused(true);audio.stopLiftMotor();clearTimeout(audio.suspendTimer);audio.ctx?.close().catch(()=>{});celRenderer.dispose();weaponInk.dispose();renderer.dispose();}
});
titleScreen.ready();if(liftTour){$('explore').textContent='LIFT TOUR';}updateFieldRecords();
registerEncounterTools({start,status:()=>({started:state.started,paused:state.paused,over:state.over,won:state.won,mode:state.mode,mission:boss.status(),player:{health:player.health,shield:player.shield,ammo:state.ammo,reserve:state.reserve},escorts:enemies.filter(e=>e.alive).length,cameras:security.cameras.filter(c=>c.online).length})});
const celRenderer=createCelRenderer(renderer,[scene,viewScene],camera,{chapter:'warden'});
const weaponInk=createWeaponInk(renderer);
function frame(now){if(campaign.disposed)return;requestAnimationFrame(frame);const realDt=Math.max(.0001,(now-rafPrevious)/1000);rafPrevious=now;realClock+=realDt;frames++;frameWindow+=realDt;if(frameWindow>=.75){fps=frames/frameWindow;frames=0;frameWindow=0;}const dt=Math.min(realDt,.12);if(state.started&&!state.paused&&!state.over){let left=dt;while(left>.00001){const step=Math.min(left,1/60);simulate(step);left-=step;if(state.over)break;}}updateCamera();if(!state.paused){if(humanWorld.update(dt))renderer.shadowMap.needsUpdate=true;environment.update(dt,state.started?player:{x:31,z:41},realClock);storm.update(dt,state.started?player:{x:31,z:41},realClock);atmosphere.update(dt,state.started?player:{x:22,z:23},realClock,security.alertRemaining);if(!state.started)boss.idle(realClock);}
if(state.started){audio.update(dt,{boss:boss.status(),listener:player,occluded:!boss.status().seen,bossPhase:boss.status().defeated?0:boss.status().phase,tension:boss.status().defeated?0:Math.max(.45,boss.status().phase*.25),indoor:serviceLift.inCab(player)||serviceLift.active||(player.x<-17&&player.x>-23&&player.z<5&&player.z>-17),time:state.time,speed:player.speed,stamina:state.stamina,crouching:player.height<1.3});}
celRenderer.begin();renderer.autoClear=true;renderer.render(scene,camera);celRenderer.finish();renderer.shadowMap.autoUpdate=false;const worldCalls=renderer.info.render.calls,worldTris=renderer.info.render.triangles;if(state.started&&!state.over){renderer.autoClear=false;renderer.clearDepth();weaponInk.render(viewScene,viewCamera);renderer.autoClear=true;}hudAccumulator+=realDt;if(state.started&&hudAccumulator>.07){updateHUD();hudAccumulator=0;}window.__GAME__={version:'2.0.0',lift:serviceLift.status(),boss:boss.status(),findings:humanObjectives.status(),pos:[player.x,player.z],height:player.y,fps,speed:player.speed,score:state.score,over:state.over,won:state.won,paused:state.paused,draws:worldCalls+(state.started&&!state.over?renderer.info.render.calls:0),tris:worldTris+(state.started&&!state.over?renderer.info.render.triangles:0),ammo:state.ammo,shield:player.shield,health:player.health,kills:state.kills,uplinks:level.terminals.filter(t=>t.done).length,mode:state.mode,time:state.time,difficulty:state.difficulty,droneSuspicion:state.droneSuspicion,droneAlerts:state.droneAlerts,alert:security.alertRemaining,cameras:security.cameras.filter(c=>c.online).length};}requestAnimationFrame(frame);
}
boot().catch(error=>{console.error(error);$('loading').classList.add('hidden');$('error-message').textContent=error.message;$('error').classList.remove('hidden');});
