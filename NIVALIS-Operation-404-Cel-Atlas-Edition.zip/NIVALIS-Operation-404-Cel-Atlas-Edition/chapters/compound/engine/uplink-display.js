// Atlas-directed screen art. Live text and signal state stay local; the concept
// image is a reference only. Draw only when the console state changes.
export function drawCelUplink(ink, {id, name, offline}) {
  const black = '#080f13', cream = '#e3ece9';
  const accent = offline ? '#7d9887' : '#c48642';
  const pale = offline ? '#b8cbbf' : cream;
  ink.save();
  ink.fillStyle = '#142129';
  ink.fillRect(0, 0, 1024, 640);
  ink.lineJoin = 'miter';
  ink.lineCap = 'square';
  ink.textBaseline = 'alphabetic';
  ink.textAlign = 'left';

  function shape(points, fill, stroke = black, width = 5) {
    ink.beginPath();
    points.forEach(([x,y], i) => i ? ink.lineTo(x,y) : ink.moveTo(x,y));
    ink.closePath();
    ink.fillStyle = fill;
    ink.fill();
    if (width) { ink.lineWidth = width; ink.strokeStyle = stroke; ink.stroke(); }
  }
  function panel(x,y,w,h,fill,cut=14) {
    shape([[x,y],[x+w-cut,y],[x+w,y+cut],[x+w,y+h],
      [x+cut,y+h],[x,y+h-cut]],fill);
  }
  function text(value,x,y,size,colour,{heavy=false,outline=0,shadow=0,max=916}={}) {
    const font = px => heavy
      ? `900 ${px}px "Arial Black", Arial, sans-serif`
      : `bold ${px}px monospace`;
    ink.font = font(size);
    const measured = ink.measureText(value).width;
    if (measured > max) ink.font = font(size * max / measured);
    if (shadow) {
      ink.fillStyle = black;
      ink.fillText(value,x+shadow,y+shadow);
      ink.strokeStyle = black; ink.lineWidth = outline;
      ink.strokeText(value,x+shadow,y+shadow);
    }
    if (outline) {
      ink.strokeStyle = black; ink.lineWidth = outline;
      ink.strokeText(value,x,y);
    }
    ink.fillStyle = colour;
    ink.fillText(value,x,y);
  }

  // Three flat screen planes, with no fine grid, gradient or scanline texture.
  panel(12,12,1000,616,'#263943',18);
  panel(22,22,980,596,'#142129',12);
  shape([[27,27],[979,27],[996,44],[996,76],[27,76]],'#20313b',black,0);
  text('NIVALIS / SIGNAL CONTROL',48,60,28,'#b0c3c4');
  text(`UPLINK ${id}`,44,186,136,pale,{heavy:true,outline:8,shadow:5});
  text(name.toUpperCase(),49,228,30,'#d0ded8');

  panel(46,249,932,67,accent,16);
  // A broken connector vs a connected trace reinforces the worded status.
  ink.strokeStyle=black; ink.lineWidth=5;
  ink.beginPath(); ink.moveTo(65,282); ink.lineTo(78,282);
  if (offline) ink.moveTo(90,282);
  ink.lineTo(103,282); ink.stroke();
  text(offline?'LINK ISOLATED / OFFLINE':'ENCRYPTED LINK / ACTIVE',123,293,34,black,{max:826});

  panel(46,337,643,118,'#1a2830',14);
  panel(708,337,270,118,'#20313b',14);
  const signal = offline
    ? [[69,399],[665,399]]
    : [[69,402],[123,402],[123,369],[177,369],[177,392],
       [234,392],[234,425],[288,425],[288,383],[341,383],
       [341,359],[397,359],[397,403],[450,403],[450,422],
       [505,422],[505,379],[561,379],[561,402],[665,402]];
  function trace(colour,width) {
    ink.strokeStyle=colour;ink.lineWidth=width;ink.beginPath();
    signal.forEach(([x,y],i)=>i?ink.lineTo(x,y):ink.moveTo(x,y));ink.stroke();
  }
  trace(black,14);trace(pale,6);
  for (let i=0;i<6;i++) {
    const h=offline?7:18+i*12, x=731+i*38;
    ink.fillStyle=black;ink.fillRect(x-3,434-h-3,30,h+6);
    ink.fillStyle=offline?'#526d66':pale;ink.fillRect(x,434-h,24,h);
  }
  text('ARRAY 09       SECURE CHANNEL',48,490,27,'#a9bdc0');
  panel(46,514,932,82,'#263943',14);
  shape([[46,514],[60,514],[60,582],[74,596],[60,596],[46,582]],accent,black,0);
  text(offline?'OVERRIDE COMPLETE':'HOLD [E]  /  SEVER UPLINK',80,568,39,pale,
    {heavy:true,outline:3,shadow:2,max:864});
  ink.restore();
}
