// Atlas-directed enamel signs. Flat painted facets keep the print crisp under
// the existing cel lighting; no texture grain, glow or additional backing mesh.
export function makeCelSign(text, {
  width = 2.4, height = .75, bg, color, sub = '', orange = false,
  family = 'exterior',
} = {}) {
  const bunker = family === 'bunker', medical = text.startsWith('+');
  const canvas = document.createElement('canvas');
  canvas.width = 768;
  canvas.height = Math.round(canvas.width * height / width);
  const c = canvas.getContext('2d'), w = canvas.width, h = canvas.height;
  const palette = bunker
    ? {face:'#303a28', ink:'#17201b', edge:'#49563f', text:'#e4dfc9'}
    : {face:'#26363f', ink:'#142129', edge:'#4a5d68', text:'#e3ece9'};
  const face = bg || palette.face, lettering = color || palette.text;
  function polygon(points, fill) {
    c.beginPath();
    points.forEach(([x,y], i) => i ? c.lineTo(x,y) : c.moveTo(x,y));
    c.closePath();c.fillStyle = fill;c.fill();
  }
  function plaque(inset, cut, fill) {
    const x=inset,y=inset,r=w-inset,b=h-inset;
    polygon([[x+cut,y],[r-cut,y],[r,y+cut],[r,b-cut],
      [r-cut,b],[x+cut,b],[x,b-cut],[x,y+cut]],fill);
  }
  const cut = bunker ? h*.10 : h*.045;
  plaque(0,cut,palette.ink);
  plaque(h*.035,cut*.75,palette.edge);
  plaque(h*.095,cut*.45,face);
  // Two hard edge planes, with no illustrated shadow extending off the plaque.
  polygon([[h*.04,h*.92],[w-h*.04,h*.92],[w-cut,h],[cut,h]],palette.ink);
  const border=h*.135, corner=cut*.42;
  c.beginPath();
  [[border+corner,border],[w-border-corner,border],
    [w-border,border+corner],[w-border,h-border-corner],
    [w-border-corner,h-border],[border+corner,h-border],
    [border,h-border-corner],[border,border+corner]].forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));
  c.closePath();c.strokeStyle=bunker?'#a7af8b':'#657a82';
  c.lineWidth=Math.max(1.5,h*.011);c.stroke();
  // Field-kit print keeps its medical colour; other exterior IDs share ochre.
  if(!bunker){
    const accent=medical?lettering:(orange?'#c07a49':'#b5673d');
    polygon([[h*.17,h*.22],[h*.29,h*.22],[h*.29,h*.78],[h*.17,h*.78]],accent);
  }
  // Sparse, angular edge wear stays outside the lettering area.
  polygon([[w*.71,h*.038],[w*.74,h*.038],[w*.733,h*.078],[w*.704,h*.078]],face);
  polygon([[w*.86,h*.925],[w*.89,h*.925],[w*.878,h*.965],[w*.855,h*.965]],palette.edge);
  c.fillStyle=lettering;c.textBaseline='middle';
  c.textAlign=bunker?'center':'left';
  // The small kit has physical catches at both edges of its existing label.
  const left=medical?w*.17:bunker?h*.22:h*.40, right=medical?w*.18:h*.22;
  const size=h*(bunker?.40625:medical?.43:sub?.40:.51);
  function line(value, size, font, x, y) {
    c.font=font(size);
    const measured=c.measureText(value).width, available=w-left-right;
    // Shorter, taller plaques (such as the lift) still use proportional type.
    if(measured>available)c.font=font(size*available/measured);
    c.fillText(value,x,y);
  }
  const mainFont=size=>bunker?`${size}px BunkerSign, Impact, sans-serif`:`900 ${size}px "Arial Black", Arial, sans-serif`;
  line(text,size,mainFont,left+(bunker?(w-left-right)/2:0),h*(sub?.405:.535));
  if(sub){
    c.fillStyle=lettering;
    line(sub,h*.17,size=>`600 ${size}px monospace`,left,h*.735);
  }
  const texture=new THREE.CanvasTexture(canvas);
  texture.encoding=THREE.sRGBEncoding;texture.anisotropy=4;
  // Alpha cutout clips the corners while preserving opaque cel shading and
  // normal depth testing. Mesh dimensions and all wall offsets stay unchanged.
  const material=new THREE.MeshStandardMaterial({map:texture,roughness:.96,metalness:.02,alphaTest:.5});
  return new THREE.Mesh(new THREE.PlaneGeometry(width,height),material);
}
