// Approved cel-art finish: shaped snow, service variants and material separation.
// Runs once before surface mapping and static baking; never changes scene placement.
function snowCap(T,w,h,d,index){
  // Angular, tapered snow inside the former rectangular envelope. The bottom
  // remains seated on its original support, including sloping container roofs.
  const outline=[[-.50,-.32],[-.42,-.50],[-.06,-.50],[.08,-.39],[.26,-.50],[.44,-.46],[.50,-.28],[.43,-.08],[.50,.10],[.45,.37],[.24,.50],[-.03,.50],[-.19,.40],[-.40,.50],[-.50,.26],[-.46,.04]];
  const p=[],ix=[],n=outline.length,flip=index%2?-1:1;
  for(const [x,z] of outline)p.push(x*w,-h/2,z*d);
  for(let i=0;i<n;i++){const [x,z]=outline[i];p.push(x*w,-h/2+h*(.32+((i+index)%3)*.09),z*d);}
  for(const [x,z] of outline)p.push(x*w*.78+flip*w*.018,h/2,z*d*.78);
  p.push(0,h/2,0);
  for(let i=0;i<n;i++){const j=(i+1)%n;ix.push(i,j,n+i,j,n+j,n+i,n+i,n+j,2*n+i,n+j,2*n+j,2*n+i,2*n+i,2*n+j,3*n);}
  // The cap is viewed from above; consistent outward faces allow normal culling.
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(p,3));geo.setIndex(ix);
  // Outline travels counter-clockwise in X/Z, so the roof winding is reversed.
  const a=geo.index.array;for(let i=0;i<a.length;i+=3){const t=a[i+1];a[i+1]=a[i+2];a[i+2]=t;}
  const flat=geo.toNonIndexed();flat.computeVertexNormals();geo.dispose();return flat;
}

const snowAssets=new Set(['cargo_module','supply_crate','station_rover','service_crawler','barricade','floodlight','helipad']);
function shapedSnow(root,asset,T){
  if(!snowAssets.has(asset))return;let n=0;
  root.traverse(o=>{const m=o.material,q=o.geometry?.parameters;if(!o.isMesh||Array.isArray(m)||!q?.width||!q?.depth)return;
    const c=m.color?.clone().convertLinearToSRGB();
    if(!c||Math.min(c.r,c.g,c.b)<.80||m.metalness>.06||m.roughness<.9||m.emissive?.getHex()>0)return;
    o.geometry=snowCap(T,q.width,q.height,q.depth,n++);
  });
}

function paint(T,hex,name){const m=new T.MeshStandardMaterial({color:hex,roughness:.92,metalness:.28});m.color.convertSRGBToLinear();m.name=name;return m;}
function box(T,root,m,x,y,z,w,h,d){const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;root.add(o);return o;}
function variety(root,asset,variant,T){
  if(asset==='cargo_module'){
    const colours=[0x718383,0x987858,0x536575],body=paint(T,colours[variant%3],'art / service-role panel');
    root.traverse(o=>{const q=o.geometry?.parameters;if(o.isMesh&&q?.width===.26&&q?.height===3.3&&q?.depth===10)o.material=body;});
    const inset=paint(T,0x26353c,'art / inset'),edge=paint(T,0xa8b4b0,'art / maintenance steel');
    for(const side of [-1,1]){
      // Fit inside existing rib bays; do not cover signs, entrances or graffiti.
      const x=side*2.625,z=.60;
      box(T,root,inset,x,1.65,z,.036,1.32,.91);
      if(variant===1){for(const y of [1.22,1.55,1.88])box(T,root,edge,x+side*.026,y,z,.028,.115,.75);}
      else if(variant===2){box(T,root,edge,x+side*.026,1.65,z,.028,1.13,.72);box(T,root,inset,x+side*.045,1.65,z,.022,.09,.56);}
      else{for(const zz of [.36,.84])box(T,root,edge,x+side*.026,1.65,zz,.028,.92,.19);}
    }
  }
  if(asset==='cryo_tank'){
    const shell=paint(T,[0xbdc8c8,0x6f858c,0x4c6168][variant%3],'art / tank body');shell.flatShading=true;
    root.traverse(o=>{if(o.isMesh&&o.geometry.type==='LatheGeometry')o.material=shell;});
    if(variant===2){
      const dark=paint(T,0x283640,'art / service face'),cream=paint(T,0xc6c6ae,'art / service plate');
      box(T,root,dark,0,1.92,1.225,.65,.51,.095);
      box(T,root,cream,0,2.08,1.279,.53,.11,.025);
      for(const y of [1.88,1.77])box(T,root,cream,0,y,1.28,.42,.045,.027);
    }
  }
}

export function enhancePropReadability(root){
  const mapped=new Map();root.traverse(o=>{if(!o.isMesh)return;
    const update=m=>{if(mapped.has(m))return mapped.get(m);
      if(!m.isMeshStandardMaterial||m.transparent||m.emissive?.getHex()>0||!m.color){mapped.set(m,m);return m;}
      const c=m.color.clone().convertLinearToSRGB(),hi=Math.max(c.r,c.g,c.b),lo=Math.min(c.r,c.g,c.b);
      // Lift material values on metal and cloth, preserving black recesses,
      // semantic colours, displays and light emission. No scene-light changes.
      const metal=m.metalness>=.28&&hi>.18&&hi<.76&&hi-lo<.23;
      const cloth=/blanket|linen/i.test(m.name);
      if(!metal&&!cloth){mapped.set(m,m);return m;}
      const next=m.clone(),gain=cloth?1.23:1.35;
      c.multiplyScalar(gain);c.r=Math.min(.86,c.r);c.g=Math.min(.86,c.g);c.b=Math.min(.86,c.b);
      next.color.copy(c.convertSRGBToLinear());next.roughness=Math.max(.78,m.roughness);next.metalness=Math.min(.50,m.metalness);
      mapped.set(m,next);return next;
    };o.material=Array.isArray(o.material)?o.material.map(update):update(o.material);
  });return root;
}

export function applyCelArtFinish(root,asset,variant=0){
  const T=THREE;
  shapedSnow(root,asset,T);
  variety(root,asset,variant,T);
  if(!['rifle','drone','heavy_drone','ration_bar','boulder','shale_ledge','ice_outcrop'].includes(asset))enhancePropReadability(root);
  return root;
}

export function paintBunkerSurfaces(canvas,base,floor){
  const c=canvas.getContext('2d'),s=canvas.width;c.fillStyle=base;c.fillRect(0,0,s,s);
  const polygon=(points,colour)=>{c.fillStyle=colour;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x*s,y*s):c.moveTo(x*s,y*s));c.closePath();c.fill();};
  // Three broad paint values instead of thousands of pores and soft stains.
  polygon([[0,.08],[.19,.08],[.28,.20],[.24,.38],[.12,.44],[0,.34]],'rgba(10,17,12,.14)');
  polygon([[.44,.48],[.79,.38],[1,.54],[1,.76],[.81,.84],[.62,.70],[.43,.73]],'rgba(10,17,12,.12)');
  polygon([[.18,.69],[.35,.63],[.50,.76],[.41,.92],[.19,.94]],'rgba(173,174,147,.065)');
  if(floor){
    polygon([[.14,.28],[.37,.18],[.65,.25],[.70,.30],[.50,.32],[.30,.40]],'rgba(165,169,142,.07)');
    c.strokeStyle='rgba(9,14,10,.22)';c.lineWidth=2.3;c.beginPath();c.moveTo(s*.64,s*.11);c.lineTo(s*.59,s*.18);c.lineTo(s*.65,s*.26);c.lineTo(s*.59,s*.32);c.stroke();
  }else{
    polygon([[.58,0],[.74,0],[.74,.18],[.67,.26],[.66,.49],[.62,.52],[.60,.28]],'rgba(10,17,12,.12)');
    polygon([[.11,.83],[.21,.77],[.30,.83],[.28,.88],[.14,.92]],'rgba(10,17,12,.10)');
  }
}
