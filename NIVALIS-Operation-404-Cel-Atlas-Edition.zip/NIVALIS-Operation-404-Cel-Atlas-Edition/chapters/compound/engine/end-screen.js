import {campaign} from './campaign-bridge.js';
// Shared chapter endings use the same scene, fonts and palette as the titles.
export function makeEndScreen({onReplay}){
 const el=id=>document.getElementById(id),screen=el('ending'),primary=el('end-primary'),replay=el('end-replay');
 let next='';
 primary.addEventListener('click',event=>{if(!next){event.preventDefault();onReplay();}});
 replay.addEventListener('click',onReplay);
 el('end-title').addEventListener('click',()=>campaign.enabled?campaign.title():location.reload());
 return {
  show({won=true,outcome,nextUrl='',nextLabel='',report=''}){
   if(campaign.enabled&&won){campaign.complete({outcome,report});return;}
   if(campaign.enabled)campaign.failed();
   next=won?nextUrl:'';
   el('end-state').textContent=won?'COMPLETE':'FAILED';
   el('end-outcome').textContent=outcome;
   primary.textContent=next?nextLabel:won?'REPLAY CHAPTER':'TRY AGAIN';
   primary.setAttribute('href',next||'#');
   replay.hidden=!next;
   el('end-report').textContent=report;
   el('end-report-link').hidden=!report;
   screen.hidden=false;screen.classList.remove('hidden');document.body.classList.add('ui-ended');
   primary.focus?.();
  },
  hide(){screen.hidden=true;screen.classList.add('hidden');document.body.classList.remove('ui-ended');}
 };
}
