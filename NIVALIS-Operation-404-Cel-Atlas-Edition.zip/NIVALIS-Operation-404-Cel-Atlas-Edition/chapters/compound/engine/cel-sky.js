// Polar Silence, adapted from the approved Atlas concept as a seamless sky.
// The return trip shares its celestial coordinates, with red storm atmosphere.
export function applyCelSky(sky,storm=false){
 const material=sky.material;
 material.uniforms.celSky={value:.83};
 material.uniforms.celStorm={value:storm?1:0};
 // Approved subtle cloud motion, driven by the existing environment clock.
 material.uniforms.weatherTime={value:0};
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 let previousTime=null, driftTime=0;
 const beforeRender=sky.onBeforeRender;
 sky.onBeforeRender=function(...args){
   beforeRender?.apply(this,args);
   const now=material.uniforms.skyTime.value;
   if(previousTime!==null&&!reduced.matches)driftTime+=Math.max(0,Math.min(.12,now-previousTime));
   previousTime=now;material.uniforms.weatherTime.value=driftTime;
 };
 const code=`
 uniform float celSky,celStorm,weatherTime;
 float polarCloud(vec2 p){
   vec2 i=floor(p),f=fract(p);
   float a=hash(i),b=hash(i+vec2(1.,0.)),c=hash(i+vec2(0.,1.)),e=hash(i+vec2(1.));
   return f.x+f.y<1.?a+(b-a)*f.x+(c-a)*f.y:e+(c-e)*(1.-f.x)+(b-e)*(1.-f.y);
 }
 vec3 illustratedSky(vec3 d,vec3 fog,float t){
   float h=max(d.y,0.);
   vec3 zenith=mix(vec3(.145,.205,.250),vec3(.120,.155,.195),celStorm);
   vec3 horizon=mix(vec3(.32,.40,.46),fog*.64+vec3(.065,.070,.085),celStorm);
   vec3 color=mix(horizon,zenith,smoothstep(.02,.86,h));
   // Stable scale and direction: same planet, ring and moon in both chapters.
   vec3 pole=normalize(vec3(-.36,.62,-.70));
   vec3 right=normalize(cross(pole,vec3(0.,1.,0.)));
   vec3 up=normalize(cross(right,pole));
   float facing=dot(d,pole),front=step(0.,facing);
   vec2 q=vec2(dot(d,right),dot(d,up))/max(.1,facing)/.285;
   float radius=length(q),disk=1.-smoothstep(.993,1.007,radius);
   float z=sqrt(max(0.,1.-dot(q,q)));
   float light=dot(vec3(q,z),normalize(vec3(-.75,.60,-.35)));
   float lit=smoothstep(-.015,.025,light)*.42+smoothstep(.27,.31,light)*.58;
   vec3 body=mix(vec3(.24,.30,.345),vec3(.63,.69,.705),lit);
   // A little atmospheric fill integrates the flat values with the snowy valley.
   body=mix(body,color,.13);
   vec2 rq=mat2(.883,-.469,.469,.883)*q;
   float ringRadius=length(vec2(rq.x,rq.y/.31));
   float rings=smoothstep(1.17,1.19,ringRadius)*(1.-smoothstep(1.90,1.92,ringRadius));
   rings*=1.-smoothstep(1.65,1.66,ringRadius)*(1.-smoothstep(1.70,1.71,ringRadius));
   float ringLight=smoothstep(.65,1.3,abs(rq.x));
   vec3 ringColor=mix(vec3(.33,.385,.40),vec3(.58,.60,.58),ringLight);
   color=mix(color,ringColor,rings*front*.85);
   color=mix(color,body,disk*front);
   color=mix(color,ringColor,rings*(1.-smoothstep(-.008,.008,rq.y))*front*.90);
   vec3 moon=normalize(vec3(.10,.82,-.56));
   float moonMask=smoothstep(.99930,.99943,dot(d,moon));
   vec3 moonRight=normalize(cross(moon,vec3(0.,1.,0.)));
   float moonLight=1.-smoothstep(.008,.019,dot(d,moonRight));
   color=mix(color,mix(vec3(.35,.42,.46),vec3(.63,.70,.72),moonLight),moonMask);
   // Faceted wind-sheared banks, continuous around the dome and free of grain.
   vec2 wind=mix(vec2(.0036,.0010),vec2(.010,.0028),celStorm);
   vec2 uv=d.xz/(max(d.y,0.)+.36)+t*wind;
   float n=polarCloud(uv*vec2(1.35,4.2)+vec2(8.7,2.1))*.74;
   n+=polarCloud(uv*vec2(2.5,6.)+vec2(3.1,7.6))*.26;
   float threshold=mix(.59,.46,celStorm);
   float gap=(q.x+q.y*.5)*.74;
   threshold+=exp(-gap*gap)*smoothstep(.25,.62,h)*front*celStorm*.19;
   float cloud=smoothstep(threshold,threshold+.028,n);
   float shade=smoothstep(threshold+.10,threshold+.13,n);
   float layer=smoothstep(.08,.20,h)*(1.-smoothstep(mix(.36,.74,celStorm),mix(.60,.94,celStorm),h));
   vec3 cloudColor=mix(vec3(.31,.385,.43),vec3(.22,.29,.335),shade);
   cloudColor=mix(cloudColor,cloudColor*.72+fog*.13,celStorm);
   color=mix(color,cloudColor,cloud*layer*mix(.55,.90,celStorm));
   // A second, higher deck drifts on a different heading and scale. The
   // projected direction is seamless around the dome; celestial anchors do not move.
   vec2 highUV=d.xz/(max(d.y,0.)+.52)*vec2(1.55,3.7);
   highUV+=vec2(t*mix(.003,.007,celStorm),t*mix(-.0012,-.0027,celStorm));
   float highNoise=polarCloud(highUV+vec2(2.6,9.2))*.72;
   highNoise+=polarCloud(highUV*1.87+vec2(6.8,1.3))*.28;
   float highThreshold=mix(.50,.44,celStorm);
   float highBank=smoothstep(highThreshold,highThreshold+.07,highNoise);
   float highFacet=smoothstep(highThreshold+.13,highThreshold+.16,highNoise);
   float highAltitude=smoothstep(.17,.38,h)*(1.-smoothstep(.92,1.,h));
   vec3 highColor=mix(vec3(.325,.400,.45),vec3(.25,.325,.38),highFacet);
   // Clouds can pass over the planet, but the rings and small moon remain readable.
   float celestialReadability=1.-.40*max(disk*front,moonMask);
   float highAlpha=highBank*highAltitude*mix(.25,.37,celStorm)*celestialReadability;
   color=mix(color,highColor,highAlpha);
   // Low wind-torn vapour stays in the distant sky, behind mountains and buildings.
   vec2 lowUV=d.xz/(max(d.y,0.)+.30)*vec2(.9,6.0);
   lowUV+=t*mix(vec2(.009,.003),vec2(.024,.007),celStorm);
   float lowNoise=polarCloud(lowUV+vec2(5.4,3.8))*.8+polarCloud(lowUV*1.8+2.3)*.2;
   float lowBank=smoothstep(.52,.62,lowNoise);
   float lowAltitude=smoothstep(.055,.13,h)*(1.-smoothstep(.34,.48,h));
   vec3 vapour=mix(vec3(.40,.46,.48),vec3(.33,.37,.40),celStorm);
   color=mix(color,vapour,lowBank*lowAltitude*mix(.15,.24,celStorm));
   // Warden: carry the compound's alarm hue through the entire distant sky.
   // Dark burgundy sits behind the brighter mountain faces; retain enough
   // tonal separation to read the crescent, rings, moon and cloud planes.
   float skyValue=dot(color,vec3(.2126,.7152,.0722));
   vec3 redSky=vec3(.055,.012,.018)+skyValue*vec3(.40,.095,.090);
   color=mix(color,redSky,celStorm);
   return mix(fog,color,smoothstep(.01,.32,h));
 }
 `;
 material.fragmentShader=material.fragmentShader.replace('void main(){',code+'\nvoid main(){')
  .replace('gl_FragColor=vec4(col,1.);','col=mix(col,illustratedSky(d,fogTint,weatherTime),min(1.,celSky*1.205));gl_FragColor=vec4(col,1.);');
 material.needsUpdate=true;
}
