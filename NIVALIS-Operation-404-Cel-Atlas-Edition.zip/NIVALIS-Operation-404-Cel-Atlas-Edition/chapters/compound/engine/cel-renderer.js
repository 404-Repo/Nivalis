// Cel Edition renderer. Atlas-directed lighting; all rendering is local.
export function createCelRenderer(renderer, scenes, camera, options) {
  const T = THREE, style = 'cel';
  let ticks = 0, activeTarget = false;
  const amount = {value: style === 'original' ? 0 : style === 'graphic' ? 1 : .83};
  const bold = {value:style === 'graphic' ? 1 : 0};
  const palette = {compound:[0x121720,.70,1.2],lower:[0x18140f,.65,1],warden:[0x1c0609,.85,1.4]}[options.chapter] || [0x121720,.70,1.2];
  const seen = new WeakSet(), size = new T.Vector2();
  const target = new T.WebGLRenderTarget(1, 1, {minFilter:T.LinearFilter, magFilter:T.LinearFilter, depthBuffer:true});
  target.texture.encoding = T.LinearEncoding;
  target.samples = renderer.capabilities.isWebGL2 ? 4 : 0;
  target.depthTexture = new T.DepthTexture(1, 1, T.UnsignedIntType);
  const uniforms = {
    image:{value:target.texture}, depthImage:{value:target.depthTexture}, pixel:{value:new T.Vector2(1,1)},
    nearPlane:{value:camera.near}, farPlane:{value:camera.far}, ink:{value:style==='graphic'?.90:palette[1]}, inkColor:{value:new T.Color(palette[0])},
  };
  const screen = new T.Scene(), screenCamera = new T.OrthographicCamera(-1,1,1,-1,0,1);
  const screenMaterial = new T.ShaderMaterial({
    uniforms, depthTest:false, depthWrite:false, toneMapped:false,
    vertexShader:'varying vec2 uvScreen; void main(){uvScreen=uv;gl_Position=vec4(position.xy,0.,1.);}',
    fragmentShader:`
      varying vec2 uvScreen;
      uniform sampler2D image, depthImage;
      uniform vec2 pixel;
      uniform float nearPlane, farPlane, ink;
      uniform vec3 inkColor;
      float distanceAt(vec2 uv) {
        float d=texture2D(depthImage,uv).r;
        return nearPlane*farPlane/(farPlane-d*(farPlane-nearPlane));
      }
      void main(){
        vec3 base=texture2D(image,uvScreen).rgb;
        float d=distanceAt(uvScreen);
        float a=distanceAt(uvScreen+vec2(pixel.x,0.));
        float b=distanceAt(uvScreen-vec2(pixel.x,0.));
        float c=distanceAt(uvScreen+vec2(0.,pixel.y));
        float e=distanceAt(uvScreen-vec2(0.,pixel.y));
        // Opposing derivatives reject continuous slopes; silhouettes remain inked.
        float ridge=max(abs(a+b-2.*d),abs(c+e-2.*d))/max(.4,d);
        float edge=smoothstep(.010,.045,ridge);
        float fogFade=(1.-smoothstep(20.,75.,d))*(1.-step(.999999,texture2D(depthImage,uvScreen).r));
        float luminance=dot(base,vec3(.2126,.7152,.0722));
        float glowProtection=1.-smoothstep(.62,.95,luminance)*.8;
        gl_FragColor=vec4(mix(base,min(base,inkColor),edge*ink*fogFade*glowProtection),1.);

      }`
  });
  screen.add(new T.Mesh(new T.PlaneGeometry(2,2), screenMaterial));
  function patch(material) {
    if(!material || seen.has(material)) return;
    seen.add(material);
    if(material.uniforms?.celSky)material.uniforms.celSky=amount;
    const lit=(material.isMeshStandardMaterial || material.isMeshPhongMaterial) && !material.transparent;
    const previous=material.onBeforeCompile, cache=material.customProgramCacheKey.bind(material);
    const oldKey=cache();
    material.onBeforeCompile=function(shader, r) {
      previous.call(this, shader, r);
      // This r140 scene applies display-space fog after encoding. Preserve that
      // order while drawing to a target; do not gamma-correct the fog twice.
      shader.fragmentShader=shader.fragmentShader.replace('#include <encodings_fragment>','gl_FragColor = LinearTosRGB(gl_FragColor);');
      if(!lit)return;
      shader.uniforms.celAmount=amount;
      shader.uniforms.celBold=bold;
      shader.fragmentShader='uniform float celAmount; uniform float celBold;\n'+shader.fragmentShader;
      // Filter fine weathering only. Never soften print, signs or live displays.
      if(material.map && (material.userData.surfaceRecipe || material.userData.celBroadSurface)){
        const mapChunk=T.ShaderChunk.map_fragment.replace('texture2D( map, vUv )','texture2D( map, vUv, celAmount * 2.5 )');
        shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',mapChunk);
      }
      shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_begin>','#include <normal_fragment_begin>\nvec3 celFaceNormal=normal;')
        .replace('#include <normal_fragment_maps>','#include <normal_fragment_maps>\nnormal=normalize(mix(celFaceNormal,normal,mix(1.,mix(.42,.30,celBold),celAmount)));');
      shader.fragmentShader=shader.fragmentShader.replace('#include <aomap_fragment>', `
        #include <aomap_fragment>
        vec3 celDiffuse=reflectedLight.directDiffuse+reflectedLight.indirectDiffuse;
        vec3 celIrradiance=celDiffuse/max(diffuseColor.rgb,vec3(.018));
        float celLuma=max(.0001,dot(celIrradiance,vec3(.2126,.7152,.0722)));
        float celBand=.045;
        celBand=mix(celBand,.180,smoothstep(.075,.105,celLuma));
        celBand=mix(celBand,.420,smoothstep(.225,.255,celLuma));
        celBand=mix(celBand,.740,smoothstep(.485,.515,celLuma));
        celBand=mix(celBand,1.,smoothstep(.735,.765,celLuma));
        float celGraphic=.05;
        celGraphic=mix(celGraphic,.24,smoothstep(.128,.152,celLuma));
        celGraphic=mix(celGraphic,.70,smoothstep(.408,.432,celLuma));
        celGraphic=mix(celGraphic,1.,smoothstep(.708,.732,celLuma));
        celBand=mix(celBand,celGraphic,celBold);
        // Preserve near-black falloff, coloured light, signs and emissive displays.
        celBand*=smoothstep(0.,.023,celLuma);
        float celRatio=mix(1.,celBand/celLuma,celAmount);
        reflectedLight.directDiffuse*=celRatio;
        reflectedLight.indirectDiffuse*=celRatio;
        reflectedLight.directSpecular*=mix(1.,mix(.28,.20,celBold),celAmount);
        reflectedLight.indirectSpecular*=mix(1.,mix(.28,.20,celBold),celAmount);
      `);
    };
    material.customProgramCacheKey=()=>oldKey+'-nivalis-atlas-cel-preview-2';
    material.needsUpdate=true;
  }
  function discover() {
    for(const scene of scenes) scene.traverse(object=>{
      if(object.material) (Array.isArray(object.material)?object.material:[object.material]).forEach(patch);
    });
  }
  discover();
  return {
    refresh:discover,
    begin() {
      if(++ticks%120===0)discover();
      if(amount.value===0){activeTarget=false;return;}
      renderer.getDrawingBufferSize(size);
      if(target.width!==size.x||target.height!==size.y)target.setSize(size.x,size.y);
      const width=(style==='graphic'?1.6:palette[2])*renderer.getPixelRatio();
      uniforms.pixel.value.set(width/size.x,width/size.y);
      uniforms.nearPlane.value=camera.near;uniforms.farPlane.value=camera.far;
      renderer.setRenderTarget(target);activeTarget=true;
    },
    finish() {
      if(!activeTarget)return;
      renderer.setRenderTarget(null);renderer.render(screen,screenCamera);
    },
    dispose(){target.dispose();screenMaterial.dispose();screen.children[0].geometry.dispose();}
  };
}
