// Own one touch-look gesture from its first contact, in either direction.
// Movement and action controls are separate surfaces and retain their pointers.
export function createTouchLook({surfaces, active, accept=()=>true, look, root=window}) {
  let pointer=null;
  const removers=[];
  function listen(target,type,handler,options) {
    target.addEventListener(type,handler,options);
    removers.push(()=>target.removeEventListener(type,handler,options));
  }
  function prevent(event) { if(event.cancelable)event.preventDefault(); }
  function reset() {
    const previous=pointer;pointer=null;
    if(previous)try {
      if(previous.surface.hasPointerCapture(previous.id))previous.surface.releasePointerCapture(previous.id);
    } catch { /* Capture can already be lost when the browser cancels a touch. */ }
  }
  function down(event) {
    if(!active()||pointer||!['touch','pen'].includes(event.pointerType)||!accept(event))return;
    prevent(event);
    pointer={id:event.pointerId,x:event.clientX,y:event.clientY,surface:event.currentTarget};
    try { pointer.surface.setPointerCapture(pointer.id); } catch { /* Window listeners still track the gesture. */ }
  }
  function move(event) {
    if(!pointer||event.pointerId!==pointer.id)return;
    if(!active()){reset();return;}
    prevent(event);
    const dx=event.clientX-pointer.x,dy=event.clientY-pointer.y;
    pointer.x=event.clientX;pointer.y=event.clientY;
    if(dx||dy)look(dx,dy);
  }
  function end(event) { if(pointer?.id===event.pointerId)reset(); }
  function nativeTouch(event) {
    // Cancel native panning from touchstart, before the browser chooses a swipe
    // direction. Pointer capture alone does not cancel browser gestures.
    if(active()&&(pointer||Array.from(event.changedTouches||[]).some(accept)))prevent(event);
  }
  for(const surface of surfaces) {
    listen(surface,'pointerdown',down,{passive:false});
    listen(surface,'lostpointercapture',end);
    listen(surface,'touchstart',nativeTouch,{passive:false});
    listen(surface,'touchmove',nativeTouch,{passive:false});
  }
  listen(root,'pointermove',move,{passive:false});
  listen(root,'pointerup',end);
  listen(root,'pointercancel',end);
  listen(root,'blur',reset);
  return {reset,dispose(){reset();removers.forEach(remove=>remove());}};
}
