// Presentation only: combat rules, health, detection and movement stay in main.js.
export function updateCombatUI(state,player){
 const el=id=>document.getElementById(id),hud=el('hud');
 document.body.classList.toggle('ui-paused',state.paused);
 hud.classList.toggle('exerting',state.stamina<99.5);
 hud.classList.toggle('needs-reload',state.ammo<=9);
 hud.classList.toggle('reloading',state.reloading>0);
 hud.classList.toggle('vitals-warning',player.shield<15||player.health<30);
 el('health-bar').style.width=Math.max(0,Math.min(100,player.health))+'%';
 el('mode-name').hidden=state.mode!=='recon';
 el('mode-name').textContent='EXPLORE';
}
