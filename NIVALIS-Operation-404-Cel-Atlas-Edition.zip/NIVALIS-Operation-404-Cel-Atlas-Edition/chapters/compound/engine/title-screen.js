import {campaign} from './campaign-bridge.js';
// Shared title controls over the actual 3D level. No illustrated backdrop.
const menu=document.getElementById('menu');
const loading=document.getElementById('loading');
let revealQueued=false;
const dialogs=[...document.querySelectorAll('.title-dialog')];
document.querySelectorAll('[data-open-panel]').forEach(button=>button.addEventListener('click',()=>{
 const dialog=document.getElementById(button.dataset.openPanel);
 if(!dialog.open)dialog.showModal();
}));
dialogs.forEach(dialog=>{
 dialog.querySelector('[data-close-panel]').addEventListener('click',()=>dialog.close());
 // Native dialogs trap focus and restore it to their invoking button.
 dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
});
// Escape closes settings without also resuming the paused game underneath.
document.addEventListener('keydown',event=>{
 const dialog=dialogs.find(item=>item.open);
 if(dialog&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();dialog.close();}
},true);

export const titleScreen={
 progress(value){
  const progress=Math.max(0,Math.min(100,Math.round(value)));
  document.getElementById('load-fill').style.width=progress+'%';
  document.getElementById('load-progress').textContent=progress+'%';
  document.getElementById('title-progress').setAttribute('aria-valuenow',progress);
 },
 ready(){
  if(revealQueued)return;
  revealQueued=true;
  this.progress(100);
  // The game schedules its first render after ready(). Keep the dark loader
  // through that frame, then reveal the scene without a blank canvas flash.
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
   loading.classList.add('hidden');if(campaign.enabled){campaign.ready();}else{menu.hidden=false;menu.classList.remove('hidden');}
  }));
 },
 closePanels(){dialogs.forEach(dialog=>{if(dialog.open)dialog.close();});}
};
