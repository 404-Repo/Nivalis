// Explicit campaign adapter. Standalone source still runs without a parent shell.
const host=window.name==='nivalis-campaign'&&window.parent!==window?window.parent.__NIVALIS_CAMPAIGN__:null;
let adapter=null,lastPointer=null;
export const campaign={
 enabled:!!host,disposed:false,
 attach(value){adapter=value;},
 ready(){if(host&&adapter)host.ready(window,adapter);},
 complete(result){host?.complete(window,result);},
 failed(){host?.failed(window);},
 prepare(){host?.prepare(window);},
 playing(){lastPointer=null;host?.playing(window);},
 paused(){lastPointer=null;host?.paused(window);},
 // Trackpads must still turn the camera when automatic capture is refused after a lift ride.
 look(event){
  if(!host||(event.pointerType&&event.pointerType!=='mouse'))return false;
  if(event.sourceCapabilities?.firesTouchEvents)return true;
  if(!host.canLook(window)||!event.target.matches('canvas')){lastPointer=null;return true;}
  if(lastPointer)adapter?.look(event.clientX-lastPointer.x,event.clientY-lastPointer.y);
  lastPointer={x:event.clientX,y:event.clientY};
  return true;
 },
 lock(){host?.lock(window);},
 title(){host?.title(window);},
 settings(){host?.settings(window);},
 mementos(value){return host?.mementos(window,value);}
};
if(host){
 document.addEventListener('click',event=>{
  if(event.target.closest('[data-open-panel="title-settings"]')){event.preventDefault();event.stopImmediatePropagation();host.settings(window);}
 },true);
 const target=document.querySelector('#pause .pause-panel')||document.querySelector('#pause .panel')||document.getElementById('pause');
 const button=document.createElement('button');button.textContent='MAIN TITLE';button.className='title-panel-link campaign-title';button.addEventListener('click',()=>host.title(window));target?.append(button);
}
