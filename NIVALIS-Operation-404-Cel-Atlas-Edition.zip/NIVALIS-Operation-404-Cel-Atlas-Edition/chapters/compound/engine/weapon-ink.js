// The first-person layer is drawn after the world's cel composite. Give it
// its own depth contours, with a stable pixel width rather than enlarged meshes.
export function createWeaponInk(renderer) {
  const T=THREE, size=new T.Vector2(), clearColor=new T.Color();
  const target=new T.WebGLRenderTarget(1,1,{minFilter:T.LinearFilter,magFilter:T.LinearFilter,depthBuffer:true});
  target.texture.encoding=T.LinearEncoding;
  target.samples=renderer.capabilities.isWebGL2?4:0;
  target.depthTexture=new T.DepthTexture(1,1,T.UnsignedIntType);
  const uniforms={image:{value:target.texture},depthImage:{value:target.depthTexture},
    pixel:{value:new T.Vector2()},nearPlane:{value:.01},farPlane:{value:6}};
  const scene=new T.Scene(),camera=new T.OrthographicCamera(-1,1,1,-1,0,1);
  const material=new T.ShaderMaterial({
    uniforms,transparent:true,premultipliedAlpha:true,depthTest:false,depthWrite:false,toneMapped:false,
    vertexShader:'varying vec2 uvScreen;void main(){uvScreen=uv;gl_Position=vec4(position.xy,0.,1.);}',
    fragmentShader:`
      varying vec2 uvScreen;
      uniform sampler2D image,depthImage;
      uniform vec2 pixel;
      uniform float nearPlane,farPlane;
      float distanceAt(vec2 uv){
        float d=texture2D(depthImage,uv).r;
        return nearPlane*farPlane/(farPlane-d*(farPlane-nearPlane));
      }
      float luminous(vec4 p){
        // Preserve the cyan reticle and additive muzzle flare, not pale armour.
        return smoothstep(.62,.90,max(p.g,p.b))*smoothstep(.10,.27,min(p.g,p.b)-p.r);
      }
      float solidAt(vec2 uv){
        vec4 p=texture2D(image,uv);
        return smoothstep(.94,.999,p.a)*(1.-luminous(p));
      }
      void main(){
        vec4 base=texture2D(image,uvScreen);
        vec2 stroke=pixel*2.25;
        float nearby=0.;
        nearby=max(nearby,solidAt(uvScreen+vec2(stroke.x,0.)));
        nearby=max(nearby,solidAt(uvScreen-vec2(stroke.x,0.)));
        nearby=max(nearby,solidAt(uvScreen+vec2(0.,stroke.y)));
        nearby=max(nearby,solidAt(uvScreen-vec2(0.,stroke.y)));
        nearby=max(nearby,solidAt(uvScreen+stroke*.7071));
        nearby=max(nearby,solidAt(uvScreen-stroke*.7071));
        nearby=max(nearby,solidAt(uvScreen+vec2(stroke.x,-stroke.y)*.7071));
        nearby=max(nearby,solidAt(uvScreen+vec2(-stroke.x,stroke.y)*.7071));
        float d=distanceAt(uvScreen);
        vec2 crease=pixel*1.15;
        float a=distanceAt(uvScreen+vec2(crease.x,0.));
        float b=distanceAt(uvScreen-vec2(crease.x,0.));
        float c=distanceAt(uvScreen+vec2(0.,crease.y));
        float e=distanceAt(uvScreen-vec2(0.,crease.y));
        float ridge=max(abs(a+b-2.*d),abs(c+e-2.*d))/max(.08,d);
        float interior=smoothstep(.003,.017,ridge)*solidAt(uvScreen)*.92;
        vec3 ink=vec3(.012,.016,.021);
        vec3 painted=mix(base.rgb,ink*base.a,interior);
        float outside=nearby*(1.-base.a)*(1.-luminous(base));
        gl_FragColor=vec4(painted+ink*outside,base.a+outside);
      }`
  });
  const quad=new T.Mesh(new T.PlaneGeometry(2,2),material);scene.add(quad);
  const additive=[];
  function preserveAdditiveAlpha(viewScene){
    additive.length=0;
    viewScene.traverse(object=>{
      const materials=Array.isArray(object.material)?object.material:[object.material];
      for(const m of materials){
        if(!m||m.blending!==T.AdditiveBlending)continue;
        additive.push([m,m.blending,m.blendSrc,m.blendDst,m.blendEquation,m.blendSrcAlpha,m.blendDstAlpha,m.blendEquationAlpha]);
        // Keep flare RGB additive without stamping opaque alpha into the overlay.
        m.blending=T.CustomBlending;m.blendSrc=m.premultipliedAlpha?T.OneFactor:T.SrcAlphaFactor;
        m.blendDst=T.OneFactor;m.blendEquation=T.AddEquation;
        m.blendSrcAlpha=T.ZeroFactor;m.blendDstAlpha=T.OneFactor;m.blendEquationAlpha=T.AddEquation;
      }
    });
  }
  return {
    render(viewScene,viewCamera){
      renderer.getDrawingBufferSize(size);
      if(target.width!==size.x||target.height!==size.y)target.setSize(size.x,size.y);
      const ratio=renderer.getPixelRatio();uniforms.pixel.value.set(ratio/size.x,ratio/size.y);
      uniforms.nearPlane.value=viewCamera.near;uniforms.farPlane.value=viewCamera.far;
      const previousTarget=renderer.getRenderTarget(),autoClear=renderer.autoClear,alpha=renderer.getClearAlpha();
      renderer.getClearColor(clearColor);preserveAdditiveAlpha(viewScene);
      try{
        renderer.setRenderTarget(target);renderer.setClearColor(0x000000,0);renderer.autoClear=false;
        renderer.clear(true,true,true);renderer.render(viewScene,viewCamera);
        renderer.setRenderTarget(previousTarget);renderer.render(scene,camera);
      }finally{
        for(const saved of additive){const [m,blending,src,dst,equation,srcAlpha,dstAlpha,equationAlpha]=saved;
          Object.assign(m,{blending,blendSrc:src,blendDst:dst,blendEquation:equation,blendSrcAlpha:srcAlpha,blendDstAlpha:dstAlpha,blendEquationAlpha:equationAlpha});}
        renderer.setRenderTarget(previousTarget);renderer.setClearColor(clearColor,alpha);renderer.autoClear=autoClear;
      }
    },
    dispose(){target.dispose();material.dispose();quad.geometry.dispose();}
  };
}
