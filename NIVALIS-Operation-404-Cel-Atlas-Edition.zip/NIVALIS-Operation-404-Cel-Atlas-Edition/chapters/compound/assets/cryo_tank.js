// NIVALIS / Atlas-directed local geometry study | cryo_tank | construction 2
// Units: meters. Y up. Front +Z. No external assets.
export default function generate(THREE,variant=0) {

  const g = new THREE.Group();
  const mat = (hex, metal=0.55, rough=0.65, emission=0) => {
    const m = new THREE.MeshStandardMaterial({color:hex, metalness:metal, roughness:rough});
    m.color.convertSRGBToLinear();
    if(emission) {m.emissive.set(hex).convertSRGBToLinear();m.emissiveIntensity=emission;}
    m.name=metal>0.3?'metal':'stone'; return m;
  };
  const steel=mat(0x627580), dark=mat(0x283640), black=mat(0x17242b), pale=mat(0xbdc8c8,0.42), orange=mat(0xd56b36,0.45),
        snow=mat(0xe1eaf0,0,0.98), bolt=mat(0x81969e,0.8), cyan=mat(0x70e4f0,0.15,0.3,2.5), warm=mat(0xffc894,0.05,0.3,2), red=mat(0xfa755e,0.1,0.3,2);
  function mesh(geo,m,x=0,y=0,z=0) {const a=new THREE.Mesh(geo,m);a.position.set(x,y,z);a.castShadow=true;a.receiveShadow=true;g.add(a);return a;}
  function B(x,y,z,w,h,d,m=steel,rz=0) {const a=mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z);a.rotation.z=rz;return a;}
  function C(x,y,z,r1,r2,h,m=steel,n=16,rx=0) {const a=mesh(new THREE.CylinderGeometry(r1,r2,h,n),m,x,y,z);a.rotation.x=rx;return a;}
  function S(x,y,z,rx,ry,rz,m=snow,detail=1) {const a=mesh(new THREE.IcosahedronGeometry(1,detail),m,x,y,z);a.scale.set(rx,ry,rz);return a;}
  function T(x,y,z,r,t,m=steel,rx=0,ry=0) {const a=mesh(new THREE.TorusGeometry(r,t,6,32),m,x,y,z);a.rotation.set(rx,ry,0);return a;}
  function beam(a,b,w,m=steel) {const p=new THREE.Vector3(...a),q=new THREE.Vector3(...b),d=q.clone().sub(p);const o=mesh(new THREE.CylinderGeometry(w,w,d.length(),6),m);o.position.copy(p.add(q).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());return o;}
  function E(points,depth,m=steel,x=0,y=0,z=0,bevel=0) {const s=new THREE.Shape();s.moveTo(...points[0]);points.slice(1).forEach(p=>s.lineTo(...p));s.closePath();const o=mesh(new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:bevel>0,bevelSize:bevel,bevelThickness:bevel,bevelSegments:1,steps:1}),m,x,y,z-depth/2);return o;}
  function chamfer(w,h,d,m,x=0,y=0,z=0,c=.12) {return E([[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]],d,m,x,y,z);}
  function bolts(x,y,z,n=3,dx=.3) {for(let k=0;k<n;k++)C(x+k*dx,y,z,.035,.035,.04,bolt,6,Math.PI/2);}
  function finish() {
    g.updateMatrixWorld(true);const bb=new THREE.Box3(),v=new THREE.Vector3();
    g.traverse(o=>{if(o.isMesh){const p=o.geometry.attributes.position;for(let i=0;i<p.count;i++)bb.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld));}});
    const c=bb.getCenter(new THREE.Vector3());g.children.forEach(o=>{o.position.x-=c.x;o.position.z-=c.z;o.position.y-=bb.min.y;});
    return g;
  }

  B(0,.16,0,3.1,.32,3.1,dark);for(const x of [-1.23,1.23])for(const z of [-1.23,1.23])B(x,.4,z,.33,.8,.33,steel);

  C(0,.43,0,.77,.80,.24,dark,12);
  const points=[[0,.53],[.76,.53],[1.06,.7],[1.23,1.03],[1.23,2.75],[1.08,3.02],[.72,3.18],[0,3.18]].map(p=>new THREE.Vector2(...p));
  const shell=pale.clone();shell.flatShading=true;mesh(new THREE.LatheGeometry(points,12),shell);C(0,3.25,0,.79,.87,.16,snow,24);
  for(const y of [1,2.67]){
    C(0,y,0,1.31,1.31,.17,steel,12);
    for(const x of [-.8,.8])chamfer(.20,.25,.15,pale,x,y,1.05,.035);
  }

  C(0,3.43,0,.25,.25,.3,dark);C(0,3.61,0,.37,.37,.09,steel);C(0,3.69,0,.36,.36,.06,snow);
  for(const y of [1.25,2.4]) {C(0,y,0,1.26,1.26,.09,orange,12);}
  C(1.36,1.43,.52,.09,.09,2.24,steel,8);for(const y of [.55,1.15,2.45])C(1.36,y,.52,.14,.14,.14,dark,8);beam([.55,3.15,0],[1.36,3.15,.52],.065,steel);beam([1.36,2.55,.52],[1.36,3.15,.52],.065,steel);
  C(0,1.1,1.32,.2,.2,.3,dark,12,Math.PI/2);mesh(new THREE.TorusGeometry(.255,.04,4,8),orange,0,1.1,1.51);C(0,1.1,1.51,.07,.07,.07,steel,8,Math.PI/2);
  for(let a=0;a<Math.PI*2;a+=Math.PI/2)beam([0,1.1,1.51],[Math.cos(a)*.24,1.1+Math.sin(a)*.24,1.51],.029,orange);
  B(.55,1.9,1.15,.1,.75,.06,dark);B(.55,1.95,1.2,.045,.45,.03,cyan);

  const rust=mat(0x815237,.1,.97),gaugeFace=mat(0xb9b9a4,0,.94);
  const z=1.29;
  C(-.58,2.11,1.20,.052,.052,.23,steel,8,Math.PI/2);
  C(-.58,2.11,z,.185,.185,.12,dark,12,Math.PI/2);
  C(-.58,2.11,z+.068,.145,.145,.015,gaugeFace,12,Math.PI/2);
  B(-.58,2.11,z+.079,.018,.195,.008,dark,-.5);
  for(let a=-2.2;a<.8;a+=.6){const o=B(-.58+Math.sin(a)*.12,2.11+Math.cos(a)*.12,z+.08,.014,.024,.005,steel);o.rotation.z=-a;}
  if(variant===1){
    C(-1.25,1.86,.46,.13,.13,1.55,steel,10);
    for(const y of [1.2,1.65,2.1,2.5])C(-1.25,y,.46,.145,.145,.055,dark,10);
    beam([-.5,2.95,.45],[-1.25,2.65,.46],.08,steel);
  }
  for(const side of [-1,1])B(side*.70,.86,1.09,.30,.044,.02,rust,side*.08);
  return finish();
}
