// Atlas Polar Service Carbine reference; authored geometry, metres, +Z forward.
export default function generate(T) {
 const g=new T.Group();
 function mat(hex,metal=.35,rough=.85){const m=new T.MeshStandardMaterial({color:hex,metalness:metal,roughness:rough});m.color.convertSRGBToLinear();m.name=metal>.2?'metal':'fabric';return m;}
 const dark=mat(0x34424b),edge=mat(0x52616a),black=mat(0x18232b,.04),pale=mat(0xb7c5c6,.3),orange=mat(0xc17740,.1),steel=mat(0x71838a,.5);
 const add=(geo,m,x=0,y=0,z=0)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const box=(x,y,z,w,h,d,m)=>add(new T.BoxGeometry(w,h,d),m,x,y,z);
 // Side silhouette is in Z/Y; extrusion thickness is along X.
 function profile(points,width,m,x=0){const shape=new T.Shape();shape.moveTo(...points[0]);points.slice(1).forEach(p=>shape.lineTo(...p));shape.closePath();const geo=new T.ExtrudeGeometry(shape,{depth:width,bevelEnabled:false,steps:1});const p=geo.attributes.position;for(let i=0;i<p.count;i++){const z=p.getX(i),y=p.getY(i),xx=p.getZ(i)-width/2;p.setXYZ(i,xx+x,y,-z);}geo.computeVertexNormals();return add(geo,m);}
 // An eight-sided longitudinal shell, built from cross-section rings.
 function shell(rings,m){const pts=[],indices=[];const section=[[-.7,-1],[.7,-1],[1,-.6],[1,.6],[.7,1],[-.7,1],[-1,.6],[-1,-.6]];for(const [z,w,h,y] of rings)for(const [x,dy]of section)pts.push(x*w/2,y+dy*h/2,z);for(let j=0;j<rings.length-1;j++)for(let i=0;i<8;i++){const a=j*8+i,b=j*8+(i+1)%8;indices.push(a,b,a+8,b,b+8,a+8);}for(let i=1;i<7;i++){indices.push(0,i+1,i);const a=(rings.length-1)*8;indices.push(a,a+i,a+i+1);}const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pts,3));geo.setIndex(indices);const non=geo.toNonIndexed();non.computeVertexNormals();return add(non,m);}
 const tube=(z,length,r,m)=>{const o=add(new T.CylinderGeometry(r,r,length,12),m,0,.316,z);o.rotation.x=Math.PI/2;return o;};
 // B: connected angular side profiles, supported by chamfered fore-end shells.
 profile([[.602,.128],[.602,.390],[.52,.408],[.39,.375],[.38,.275],[.49,.242],[.52,.128]],.10,black);
 shell([[-.47,.073,.078,.328],[-.275,.09,.088,.328]],edge);
 profile([[.315,.253],[.315,.356],[.273,.413],[-.045,.413],[-.117,.353],[-.104,.237],[-.035,.223],[.20,.223]],.179,dark);
 profile([[.273,.257],[.297,.346],[.264,.394],[.217,.394],[.249,.344],[.20,.257]],.189,pale);
 shell([[.072,.199,.176,.324],[.144,.207,.18,.324]],pale);
 shell([[.14,.185,.158,.324],[.411,.178,.153,.324],[.451,.148,.119,.324]],dark);
 profile([[.22,.267],[.126,.254],[.123,.191],[.157,.027],[.199,0],[.25,.04],[.212,.157]],.091,black);
 profile([[.057,.245],[-.069,.245],[-.075,.035],[.038,.024]],.11,dark);
 box(0,.034,.017,.119,.027,.136,black);

 // Small functional details. One barrel, open sight, separate magazine.
 tube(.499,.15,.029,edge);tube(.583,.037,.033,dark);
 const bore=add(new T.CircleGeometry(.019,12),black,0,.316,.602); // Front-facing bore.
 box(0,.102,.023,.117,.024,.141,orange);
 for(const x of [-.096,.096]){
  box(x,.32,-.08,.008,.049,.090,steel);
  for(const z of [.202,.287,.371]){box(x,.326,z,.009,.049,.056,black);box(x*1.019,.302,z,.008,.009,.050,edge);}
  box(x,.26,-.184,.01,.022,.035,steel);
 }
 box(0,.227,-.08,.082,.016,.19,dark);box(0,.154,-.072,.084,.014,.126,dark);box(0,.188,-.018,.084,.070,.014,dark);
 box(0,.193,-.074,.013,.057,.016,edge).rotation.x=-.28;
 box(0,.419,-.08,.098,.029,.335,black);
 for(const z of [-.23,-.20,.039,.073])box(0,.441,z,.108,.016,.018,edge);
 const sight=new T.Group();sight.name='sight';g.add(sight);
 for(const x of [-.075,.075])box(x,.5313,-.1115,.026,.150,.045,dark);
 box(0,.6123,-.1115,.175,.024,.045,dark);box(0,.454,-.1115,.17,.018,.057,dark);
 const glass=mat(0x80dfee,.1,.32);glass.transparent=true;glass.opacity=.10;glass.depthWrite=false;glass.side=T.DoubleSide;
 const pane=box(0,.5273,-.1115,.114,.122,.012,glass);pane.name='sight-glass';
 const cyan=mat(0x70e4f0,.1,.3);cyan.emissive.set(0x70e4f0).convertSRGBToLinear();cyan.emissiveIntensity=2.5;
 const reticle=box(0,.5413,-.1265,.0035,.0035,.004,cyan);reticle.name='sight-reticle';
 return g;
}
