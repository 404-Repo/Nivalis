// NIVALIS / Atlas-directed local geometry study. Not an Atlas-generated mesh.
// Meter scale. Y up. Front +Z. No imports, external textures or credentials.
export default function generate(THREE) {
 const g=new THREE.Group();let parent=g;
 const mat=(hex,metal=.5,rough=.72,emission=0)=>{const m=new THREE.MeshStandardMaterial({color:hex,metalness:metal,roughness:rough});m.color.convertSRGBToLinear();if(emission){m.emissive.set(hex).convertSRGBToLinear();m.emissiveIntensity=emission;}return m;};
 const steel=mat(0x627580),dark=mat(0x283640),black=mat(0x142129,.12),pale=mat(0xbdc8c8,.35),orange=mat(0xb5673d,.32),snow=mat(0xe1eaf0,0,.98),bolt=mat(0x81969e,.8),glass=mat(0x172e39,.4,.27),rubber=mat(0x1a262c,0,.97),card=mat(0x8f806d,0,.98),paper=mat(0xc5c0ae,0,.98),warm=mat(0xffc894,.1,.45,.6);
 function M(geo,m,x=0,y=0,z=0){const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;parent.add(o);return o;}
 function B(x,y,z,w,h,d,m=steel,rz=0){const o=M(new THREE.BoxGeometry(w,h,d),m,x,y,z);o.rotation.z=rz;return o;}
 function C(x,y,z,r1,r2,h,m=steel,n=14){return M(new THREE.CylinderGeometry(r1,r2,h,n),m,x,y,z);}
 function T(x,y,z,r,t,m=steel){return M(new THREE.TorusGeometry(r,t,6,24),m,x,y,z);}
 function beam(a,b,r,m=steel){const p=new THREE.Vector3(...a),q=new THREE.Vector3(...b),d=q.clone().sub(p),o=M(new THREE.CylinderGeometry(r,r,d.length(),6),m);o.position.copy(p.add(q).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());return o;}
 function plate(w,h,d,x,y,z,m=steel,c=.08){const s=new THREE.Shape(),p=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];s.moveTo(...p[0]);p.slice(1).forEach(v=>s.lineTo(...v));s.closePath();return M(new THREE.ExtrudeGeometry(s,{depth:d,bevelEnabled:false,steps:1}),m,x,y,z-d/2);}
 function wheel(x,y,z,r,width){const w=C(x,y,z,r,r,width,rubber,20);w.rotation.z=Math.PI/2;const h=C(x+Math.sign(x)*(width/2+.008),y,z,r*.56,r*.56,.045,steel,12);h.rotation.z=Math.PI/2;const hub=C(x+Math.sign(x)*(width/2+.035),y,z,r*.21,r*.21,.075,bolt,10);hub.rotation.z=Math.PI/2;return w;}
 function finish(){g.updateMatrixWorld(true);const box=new THREE.Box3(),v=new THREE.Vector3();g.traverse(o=>{if(o.isMesh){const p=o.geometry.attributes.position;for(let i=0;i<p.count;i++)box.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(o.matrixWorld));}});const c=box.getCenter(new THREE.Vector3());for(const o of g.children){o.position.x-=c.x;o.position.z-=c.z;o.position.y-=box.min.y;}g.name='station_rover';return g;}

 // Six-wheel cold-weather station rover. Three visible axles, separate roof load.
 plate(2.64,.82,5.53,0,1.08,0,dark,.17);B(0,1.57,0,2.66,.16,5.25,pale);
 for(const z of [-1.87,0,1.87]){const axle=C(0,.66,z,.15,.15,3.2,steel,10);axle.rotation.z=Math.PI/2;for(const x of [-1.52,1.52]){
 wheel(x,.67,z,.67,.51);for(let i=0;i<6;i++){
  const a=i*Math.PI/3,lug=new THREE.Group();lug.position.set(x,.67+Math.sin(a)*.642,z+Math.cos(a)*.642);lug.rotation.x=-a;g.add(lug);
  parent=lug;for(const side of [-1,1])B(side*.126,0,0,.285,.13,.10,black,side*.28);parent=g;
 }
 B(x,1.37,z,.68,.11,1.31,steel);B(x,1.439,z,.68,.029,1.19,snow);
 }}
 plate(2.55,1.46,2.26,0,2.25,1.49,pale,.22);plate(2.15,.73,.05,0,2.5,2.637,glass,.13);B(0,2.49,2.675,.06,.81,.045,steel);
 for(const x of [-1.292,1.292]){B(x,2.48,1.54,.035,.79,1.68,glass);B(x*1.018,2.025,1.48,.082,.025,.23,bolt);B(x,1.76,1.18,.05,.12,1.55,orange);B(x*1.06,1.12,1.28,.28,.09,1.27,black);}
 plate(2.53,1.11,2.53,0,2.08,-1.1,steel,.23);B(0,2.66,-1.1,2.42,.075,2.37,snow);
 for(const x of [-1.3,1.3]){B(x,2.04,-1.12,.035,.69,1.96,dark);for(const z of [-1.76,-1.12,-.48])B(x*1.008,2.01,z,.047,.48,.14,steel);B(x*1.01,2.32,-1.12,.052,.055,1.76,pale);}
 B(0,1.73,-2.46,2.23,.19,.15,orange);B(0,.98,-2.87,2.7,.21,.2,steel);
 B(0,1.1,2.86,2.84,.25,.27,black);plate(1.3,.32,.09,0,1.89,2.648,pale,.075);plate(1.12,.20,.045,0,1.89,2.704,black,.05);for(const x of [-.35,0,.35])B(x,1.89,2.727,.055,.18,.018,steel);
 for(const x of [-1,1]){plate(.36,.22,.11,x,1.88,2.67,black,.036);B(x,1.88,2.732,.28,.115,.024,warm);}
 B(0,3.002,1.48,2.34,.04,2.03,snow);
 for(const x of [-.98,.98])beam([x,3.13,.58],[x,3.13,2.2],.058,steel);for(const z of [.65,2.12]){beam([-1,3.13,z],[1,3.13,z],.058,steel);for(const x of [-.98,.98])B(x,3.08,z,.085,.16,.085,steel);}
 plate(1.18,.23,.78,-.03,3.18,1.31,dark,.075);B(-.05,3.316,1.31,1.09,.035,.72,snow);
 C(1.01,2.726,-1.84,.06,.06,.09,dark,10);
 beam([1.01,2.76,-1.84],[1.01,3.59,-1.91],.015,black);
 // Machinery recessed against the retained rear body; no elevated mast.
 for(const side of [-1,1]){
  const x=side*1.337;
  B(x,2.015,-.84,.023,.59,1.27,pale);
  B(x+side*.02,2.015,-.79,.025,.46,1.03,dark);
  B(x+side*.033,2.06,-.63,.021,.37,.62,steel);
  for(const z of [-.88,-.41])B(x+side*.048,2.07,z,.013,.12,.045,bolt);
  const reel=new THREE.Group();reel.position.set(side*1.37,2.02,-1.79);reel.rotation.y=side*Math.PI/2;g.add(reel);
  const spool=new THREE.Mesh(new THREE.CylinderGeometry(.23,.23,.09,14),black);spool.rotation.x=Math.PI/2;reel.add(spool);
  for(const z of [-.047,.047]){const disc=new THREE.Mesh(new THREE.TorusGeometry(.23,.018,4,14),steel);disc.position.z=z;reel.add(disc);}
  const hub=new THREE.Mesh(new THREE.CylinderGeometry(.057,.057,.12,8),bolt);hub.rotation.x=Math.PI/2;reel.add(hub);
  for(const z of [-1.87,0,1.87]){
    B(side*1.62,1.24,z-.48,.36,.28,.075,dark,.12*side);
    B(side*1.62,1.24,z+.48,.36,.28,.075,dark,-.12*side);
  }
  const rust=mat(0x815237,.12,.98);
  B(side*1.278,1.89,2.02,.012,.043,.38,rust);
  B(side*1.34,1.77,-.77,.013,.035,.50,rust);
 }
 return finish();
}
