// Pure puzzle state: all failed attempts are recoverable. No campaign save writes.
export const N=1,E=2,S=4,W=8;
export const rotate=m=>((m<<1)&15)|((m>>3)&1);
export const INITIAL=[6,10,12,6,10, 5,3,5,9,5, 5,9,10,12,5, 3,10,6,5,12, 10,3,5,10,9];
export const SOLUTION=[6,10,12,6,10, 5,6,10,12,5, 10,9,10,3,10, 3,10,6,5,12, 10,3,5,10,9];
export const PORTS=[{name:'LIFT',cell:14,bit:E},{name:'CORE',cell:4,bit:E},{name:'BACKUP',cell:24,bit:E},{name:'RECOVERY',cell:22,bit:S}];
export function circuit(tiles){
 const live=new Set(),queue=(tiles[10]&W)?[10]:[];
 while(queue.length){const i=queue.shift();if(live.has(i))continue;live.add(i);const x=i%5,y=Math.floor(i/5);
  for(const [bit,other,dx,dy] of [[N,S,0,-1],[E,W,1,0],[S,N,0,1],[W,E,-1,0]]){const nx=x+dx,ny=y+dy;if(nx>=0&&nx<5&&ny>=0&&ny<5){const j=ny*5+nx;if((tiles[i]&bit)&&(tiles[j]&other)&&!live.has(j))queue.push(j);}}
 }
 const ports=PORTS.map(p=>({...p,powered:live.has(p.cell)&&!!(tiles[p.cell]&p.bit)}));
 return {live,ports,valid:ports[0].powered&&!ports.slice(1).some(p=>p.powered)};
}
export const LOADS=[2,2,1,2];
export const POWER_HINTS=[
 'The crew left a shift note beside the bunks. The control terminal also lists its safety interlock.',
 'Keep a way back, a working console and moving air. The archive holds records, not life support.',
 'Enable LIFT (2 A), CONSOLE (2 A) and AIR SUPPLY (1 A). Leave ARCHIVE off: exactly 5 A.'
];
export const ROUTING_HINTS=[
 'Begin at AUX on the left of row 3. A track lights only when both neighbouring junctions connect.',
 'A safe route rises into row 2, crosses above the centre, then drops back to the LIFT in row 3. Keep the outer CORE, BACKUP and RECOVERY ports dark.'
];
export function routingHint(tiles){
 if(circuit(tiles).valid)return {cell:-1,text:'The lift is live and all three AI feeds are isolated. Commit core shutdown when ready.'};
 const cell=tiles.findIndex((m,i)=>m!==SOLUTION[i]);
 return {cell,text:`Try the marked junction: row ${Math.floor(cell/5)+1}, column ${cell%5+1}. Turn it clockwise to follow the service route.`};
}
export function createMission(){return {power:false,cartridge:false,isolated:false,shutdownTime:0,readTerminal:false,readNote:false,powerHint:0,routingHint:0,breakers:[true,false,false,false],tiles:[...INITIAL],attempts:0};}
export function energize(m){const load=m.breakers.reduce((s,on,i)=>s+(on?LOADS[i]:0),0);
 if(load>5)return {ok:false,message:`OVERLOAD / ${load} A exceeds the 5 A supply. Shed a non-essential load and retry.`};
 if(!m.breakers[0])return {ok:false,message:'LIFT FEED OPEN / Keep the return route powered.'};
 if(!m.breakers[1])return {ok:false,message:'CONSOLE FEED OPEN / Maintenance terminal cannot start.'};
 if(!m.breakers[2])return {ok:false,message:'AIRFLOW INTERLOCK / Equipment cooling unavailable. Check the terminal requirements.'};
 m.power=true;return {ok:true,message:'AUXILIARY BUS STABLE / 5 A. Maintenance console online.'};}
export function isolate(m){if(!m.power)return {ok:false,message:'NO AUXILIARY POWER / Restore the maintenance bus.'};if(!m.cartridge)return {ok:false,message:'OVERRIDE CARTRIDGE MISSING / Check the supply store.'};
 const c=circuit(m.tiles);m.attempts++;
 if(!c.ports[0].powered)return {ok:false,message:'LIFT HAS NO POWER / Trace a continuous route from AUX to LIFT.'};
 if(c.ports.slice(1).some(p=>p.powered))return {ok:false,message:'AI SUPPLY STILL LIVE / Disconnect CORE, BACKUP and RECOVERY.'};
 m.isolated=true;return {ok:true,message:'COMMAND CORE OFFLINE / LIFT FEED RETAINED'};
}
