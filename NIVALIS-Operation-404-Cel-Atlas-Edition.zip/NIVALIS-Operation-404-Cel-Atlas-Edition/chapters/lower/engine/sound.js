// Original procedural score and bunker ambience. No external recordings or samples.
import {addRadioAmbience} from './radio.js';
import {addFailsafeAlarm} from './failsafe-alarm.js';
import {addLiftPulse} from './lift-pulse.js';
import {addShutdownEffects} from './shutdown-sound.js';
const midi=n=>440*2**((n-69)/12);
const HARMONIES=[[38,45,50,57],[38,45,51,56],[38,44,51,56]];
export function addStringBed(ac,destination,at=ac.currentTime){
 const bus=ac.createGain();bus.gain.setValueAtTime(1.85,at);bus.connect(destination);
 const voices=[];
 for(let i=0;i<4;i++){
  const filter=ac.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(420+i*130,at);filter.Q.value=.48;
  const amp=ac.createGain();amp.gain.setValueAtTime(.0001,at);amp.gain.linearRampToValueAtTime(.026-i*.002,at+3.4+i*.4);
  const pan=ac.createStereoPanner();pan.pan.value=[-.62,.42,-.27,.66][i];filter.connect(amp).connect(pan).connect(bus);
  const wave=ac.createOscillator(),drift=ac.createGain();wave.frequency.value=.11+i*.017;drift.gain.value=2.1;wave.connect(drift);wave.start(at);
  const swell=ac.createOscillator(),depth=ac.createGain();swell.frequency.value=.037+i*.013;depth.gain.setValueAtTime(0,at);depth.gain.linearRampToValueAtTime(.008,at+4);swell.connect(depth).connect(amp.gain);swell.start(at);
  const oscillators=[];
  for(const detune of [-7,7]){const o=ac.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(midi(HARMONIES[0][i]),at);o.detune.value=detune+i*.3;drift.connect(o.detune);o.connect(filter);o.start(at);oscillators.push(o);}
  voices.push({filter,amp,oscillators});
 }
 return {setStage(stage,when=ac.currentTime){const notes=HARMONIES[Math.max(0,Math.min(2,stage))];voices.forEach((v,i)=>{for(const o of v.oscillators)o.frequency.setTargetAtTime(midi(notes[i]),when,stage===2?2.8:4.5);v.filter.frequency.setTargetAtTime(420+i*130+stage*125,when,3.8);});bus.gain.setTargetAtTime([1.85,2.10,2.35][stage],when,3);},voices,bus};
}
export function soundscape(){
 let ac,master,bed,musicBus,ambienceBus,musicMix=.7,ambienceMix=.58,filter,strings,radio,alarm,liftPulse,shutdownEffects,buzzGain,quiet=false,stage=0,enabled=true,clock=0,nextPulse=0,pulse=0,lastBallast=-1,controlClock=0;
 const transientVoices=new Map();
 function tone(hz,duration=.2,type='sine',volume=.12,delay=0,destination=master){if(!ac||!enabled)return;const at=ac.currentTime+delay,o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.setValueAtTime(hz,at);g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(volume,at+.012);g.gain.exponentialRampToValueAtTime(.0001,at+duration);o.connect(g).connect(destination);o.start(at);o.stop(at+duration+.04);transientVoices.set(o,g);o.onended=()=>{o.disconnect();g.disconnect();transientVoices.delete(o);};}
 function setStage(value){if(value===stage)return;stage=value;strings?.setStage(stage);alarm?.setActive(stage===2);if(filter)filter.frequency.setTargetAtTime(stage===2?510:300,ac.currentTime,3);nextPulse=clock+.35;pulse=0;}
 function setQuiet(value){if(value===quiet)return;quiet=value;bed?.gain.setTargetAtTime(quiet?.015:1,ac.currentTime,quiet?.14:.75);}
 async function start(){
  if(!ac){const C=window.AudioContext||window.webkitAudioContext;if(!C)return;ac=new C();
   master=ac.createGain();master.gain.value=enabled?.52:0;const compressor=ac.createDynamicsCompressor();compressor.threshold.value=-14;compressor.knee.value=18;compressor.ratio.value=3;compressor.attack.value=.04;compressor.release.value=.4;master.connect(compressor).connect(ac.destination);bed=ac.createGain();bed.gain.value=quiet?.015:1;bed.connect(master);musicBus=ac.createGain();musicBus.gain.value=musicMix/.7;musicBus.connect(bed);ambienceBus=ac.createGain();ambienceBus.gain.value=ambienceMix/.58;ambienceBus.connect(bed);
   const noise=ac.createBuffer(1,ac.sampleRate*4,ac.sampleRate),d=noise.getChannelData(0);let b=0;for(let i=0;i<d.length;i++){b=(b+(Math.random()*2-1)*.02)/1.02;d[i]=b;}const source=ac.createBufferSource();source.buffer=noise;source.loop=true;filter=ac.createBiquadFilter();filter.type='lowpass';filter.frequency.value=300;const ventilation=ac.createGain();ventilation.gain.value=.11;source.connect(filter).connect(ventilation).connect(ambienceBus);source.start();
   const hum=ac.createOscillator();hum.frequency.value=48;const humGain=ac.createGain();humGain.gain.value=.022;hum.connect(humGain).connect(ambienceBus);hum.start();
   // A narrow electrical buzz follows proximity and the same lamp-failure envelope.
   const buzz=ac.createOscillator();buzz.type='sawtooth';buzz.frequency.value=100;const buzzFilter=ac.createBiquadFilter();buzzFilter.type='bandpass';buzzFilter.frequency.value=390;buzzFilter.Q.value=1.5;buzzGain=ac.createGain();buzzGain.gain.value=0;buzz.connect(buzzFilter).connect(buzzGain).connect(ambienceBus);buzz.start();
   strings=addStringBed(ac,musicBus);strings.setStage(stage);radio=addRadioAmbience(ac,ambienceBus);shutdownEffects=addShutdownEffects(ac,master);alarm=addFailsafeAlarm(ac,master);liftPulse=addLiftPulse(ac,master);alarm.setActive(stage===2);nextPulse=clock+10;
  }
  await ac.resume();
 }
 return {
  start,
  update(dt,state){liftPulse?.setActive(!!state.ascending&&state.active);if(!state.active||!ac||ac.state!=='running')return;clock+=dt;controlClock+=dt;setStage(state.stage);setQuiet(!!state.quiet);
   if(!quiet)radio.update(stage,!!state.focused);alarm.update();liftPulse.update();
   if(controlClock>.08){controlClock=0;const level=Math.max(0,Math.min(1,state.ballast));if(Math.abs(level-lastBallast)>.012){buzzGain.gain.setTargetAtTime(level*.015,ac.currentTime,.035);lastBallast=level;}}
   if(!quiet&&clock>=nextPulse){
    if(stage===2){tone([73.42,110,103.83,82.41,73.42,146.83,103.83,82.41][pulse%8],.52,'triangle',state.ascending?.016:.042,0,musicBus);if(pulse%8===0)tone(36.71,1.9,'sine',.060,0,musicBus);nextPulse=clock+.29;}
    else if(stage===1){tone([73.42,110,103.83,82.41][pulse%4],1.15,'triangle',.023,0,musicBus);nextPulse=clock+1.6;}
    else {tone([36.71,41.2,34.65,36.71][pulse%4],3.7,'sine',.037,0,musicBus);nextPulse=clock+11.4;}
    pulse++;
   }
  },
  dispose(){ac?.close().catch(()=>{});},
  setMix(music,ambience){musicMix=music;ambienceMix=ambience;if(ac){musicBus?.gain.setTargetAtTime(music/.7,ac.currentTime,.2);ambienceBus?.gain.setTargetAtTime(ambience/.58,ac.currentTime,.2);}},
  setEnabled(v){enabled=v;if(master)master.gain.setTargetAtTime(v?.52:0,ac.currentTime,.25);},
  setAlarm(v){setStage(v?2:0);},
  beginShutdown(){radio?.reset();setQuiet(true);},
  shutdownCue(cue){if(cue==='alarm')setStage(2);else shutdownEffects?.play(cue);},
  click(){tone(210,.055,'square',.022);},step(){tone(57+Math.random()*15,.07,'triangle',.050);},
  power(){tone(55,1.6,'sawtooth',.050);tone(220,.3,'sine',.045,.7);},pickup(){tone(440,.16,'sine',.07);tone(660,.23,'sine',.045,.12);},
  deny(){tone(123,.16,'square',.022);tone(116,.20,'square',.022,.16);},
  awaken(){tone(31,4.6,'sine',.16);tone(38.89,3.9,'triangle',.075,.3);tone(146.83,2,'sine',.035,1.2);},lift(){tone(42,4.5,'sawtooth',.06);},
  pause(){ac?.suspend();},reset(){alarm?.reset();liftPulse?.reset();shutdownEffects?.reset();quiet=false;if(bed)bed.gain.setTargetAtTime(1,ac.currentTime,.04);for(const [o,g] of transientVoices){o.onended=null;o.stop();o.disconnect();g.disconnect();}transientVoices.clear();stage=0;clock=pulse=controlClock=0;nextPulse=10;lastBallast=-1;strings?.setStage(0);radio?.reset();if(filter)filter.frequency.setTargetAtTime(300,ac.currentTime,.3);if(buzzGain)buzzGain.gain.setTargetAtTime(0,ac.currentTime,.04);},
  status(){return {stage,quiet,shutdown:shutdownEffects?.status()??null,strings:!!strings,enabled,ballast:Math.max(0,lastBallast),radio:radio?.status()??null,alarm:alarm?.status()??null,liftPulse:liftPulse?.status()??null};},get active(){return ac?.state==='running';}
 };
}
