// A slow, detuned industrial horn. Original synthesis; no external samples.
// All voices feed the normal sound bus, so mute and AudioContext pause apply.
export function addFailsafeAlarm(ac,destination){
 const voices=new Map();let active=false,next=0,calls=0;
 function horn(at){
  calls++;
  for(const [hz,volume,pan,type] of [[82,.160,-.23,'sawtooth'],[86.7,.130,.23,'sawtooth'],[41,.145,0,'sine']]){
   const source=ac.createOscillator(),filter=ac.createBiquadFilter(),gain=ac.createGain(),stereo=ac.createStereoPanner();
   source.type=type;source.frequency.setValueAtTime(hz,at);source.frequency.linearRampToValueAtTime(hz*1.045,at+.42);source.frequency.exponentialRampToValueAtTime(hz*.77,at+2.9);
   filter.type='lowpass';filter.Q.value=.65;filter.frequency.setValueAtTime(580,at);filter.frequency.exponentialRampToValueAtTime(220,at+3.2);
   gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(volume,at+.28);gain.gain.linearRampToValueAtTime(volume*.82,at+1.4);gain.gain.exponentialRampToValueAtTime(.0001,at+3.3);gain.gain.linearRampToValueAtTime(0,at+3.5);
   stereo.pan.value=pan;source.connect(filter).connect(gain).connect(stereo).connect(destination);
   const nodes=[filter,gain,stereo];voices.set(source,nodes);
   source.onended=()=>{source.disconnect();for(const n of nodes)n.disconnect();voices.delete(source);};
   source.start(at);source.stop(at+3.55);
  }
 }
 function clear(){for(const [source,nodes] of voices){source.onended=null;source.stop();source.disconnect();for(const n of nodes)n.disconnect();}voices.clear();}
 return {
  setActive(value){if(value===active)return;active=value;if(active)next=ac.currentTime+.12;else clear();},
  update(){if(!active||ac.currentTime<next)return;horn(ac.currentTime+.025);next=ac.currentTime+5.4;},
  reset(){active=false;next=calls=0;clear();},
  status(){return {active,calls,activeVoices:voices.size};}
 };
}
