// Original muffled debris and heavy machinery. No external recordings.
// Finite voices, shared mute bus, and explicit cleanup on restart.
export function addShutdownEffects(ac,destination){
 const voices=new Map();let calls=0,seed=404;
 const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
 const buffer=ac.createBuffer(1,Math.ceil(ac.sampleRate*3),ac.sampleRate),samples=buffer.getChannelData(0);
 let brown=0;for(let i=0;i<samples.length;i++){brown=(brown+(random()*2-1)*.045)/1.035;samples[i]=brown;}
 function track(source,nodes,end){voices.set(source,nodes);source.onended=()=>{source.disconnect();nodes.forEach(n=>n.disconnect());voices.delete(source);};source.stop(end);}
 function rumble(at,duration,volume,pan){
  const source=ac.createBufferSource(),filter=ac.createBiquadFilter(),gain=ac.createGain(),stereo=ac.createStereoPanner();source.buffer=buffer;filter.type='lowpass';filter.frequency.setValueAtTime(620,at);filter.frequency.exponentialRampToValueAtTime(110,at+duration);filter.Q.value=.55;stereo.pan.value=pan;
  gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(volume,at+.045);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);
  source.connect(filter).connect(gain).connect(stereo).connect(destination);source.start(at);track(source,[filter,gain,stereo],at+duration+.02);
 }
 function motor(at,hz,endHz,duration,volume){
  const source=ac.createOscillator(),filter=ac.createBiquadFilter(),gain=ac.createGain();source.type='sawtooth';source.frequency.setValueAtTime(hz,at);source.frequency.exponentialRampToValueAtTime(endHz,at+duration);filter.type='lowpass';filter.frequency.value=185;filter.Q.value=.65;
  gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(volume,at+.32);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);
  source.connect(filter).connect(gain).connect(destination);source.start(at);track(source,[filter,gain],at+duration+.02);
 }
 return {
  play(cue){const at=ac.currentTime+.015;if(cue==='crash-near'||cue==='crash-far'){calls++;const far=cue==='crash-far';rumble(at,far?1.4:2.1,far?.6:1.1,far?.25:-.3);rumble(at+.19,.65,far?.25:.5,-.1);motor(at,far?44:51,27,.85,.09);}
   else if(cue==='warden'){calls++;motor(at,29,47,2.4,.15);motor(at+.16,31,49,2.7,.07);rumble(at+.5,2,.35,0);}
  },
  reset(){for(const [source,nodes] of voices){source.onended=null;source.stop();source.disconnect();nodes.forEach(n=>n.disconnect());}voices.clear();calls=0;},
  status(){return {calls,activeVoices:voices.size};}
 };
}
