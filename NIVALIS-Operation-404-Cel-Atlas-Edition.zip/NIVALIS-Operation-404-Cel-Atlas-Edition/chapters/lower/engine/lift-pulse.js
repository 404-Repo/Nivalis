// Original steady low synth pulse for the moving lift; no recordings or samples.
export function addLiftPulse(ac,destination){
 const voices=new Map();let active=false,next=0,beats=0,bpm=240;
 function throb(at){
  for(const [hz,volume,type] of [[46.25,.24,'sine'],[92.5,.065,'triangle']]){
   const source=ac.createOscillator(),filter=ac.createBiquadFilter(),gain=ac.createGain();
   source.type=type;source.frequency.setValueAtTime(hz,at);
   filter.type='lowpass';filter.frequency.value=230;filter.Q.value=.55;
   gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(volume,at+.018);gain.gain.exponentialRampToValueAtTime(.0001,at+.18);gain.gain.linearRampToValueAtTime(0,at+.215);
   source.connect(filter).connect(gain).connect(destination);voices.set(source,[filter,gain]);
   source.onended=()=>{source.disconnect();filter.disconnect();gain.disconnect();voices.delete(source);};source.start(at);source.stop(at+.22);
  }
 }
 function clear(){for(const [source,nodes] of voices){source.onended=null;source.stop();source.disconnect();for(const n of nodes)n.disconnect();}voices.clear();}
 return {
  setActive(value){if(value===active)return;active=value;if(active){next=ac.currentTime+.025;bpm=240;}else clear();},
  update(){
   if(!active||ac.currentTime+.065<next)return;
   // A delayed frame resumes from now instead of queuing a burst of missed beats.
   const at=Math.max(next,ac.currentTime+.005);
   throb(at);beats++;next=at+60/bpm;
  },
  reset(){active=false;beats=0;bpm=240;clear();},
  status(){return {active,beats,bpm:Math.round(bpm),activeVoices:voices.size};}
 };
}
