// Original synthetic shortwave stutters, digital pulse calls and sonar echoes.
// No speech, samples or encoded puzzle clues. All nodes share the game's mute bus.
export function addRadioAmbience(ac,destination,at=ac.currentTime){
 const bus=ac.createGain();bus.gain.value=1;bus.connect(destination);
 let seed=904117,next=at+7,nextStatic=at+1.2,index=0,lastMix=-1,last='none',events=0;
 const voices=new Map(),random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
 const noise=ac.createBuffer(1,Math.ceil(ac.sampleRate*2),ac.sampleRate),samples=noise.getChannelData(0);
 for(let i=0;i<samples.length;i++)samples[i]=(random()*2-1)*(i%379<3?1:.42);
 function track(source,nodes,end){
  voices.set(source,nodes);source.onended=()=>{source.disconnect();for(const n of nodes)n.disconnect();voices.delete(source);};source.stop(end);
 }
 function pip(when,hz,duration,volume,pan=0,type='sine',endHz=hz){
  const source=ac.createOscillator(),filter=ac.createBiquadFilter(),gain=ac.createGain(),stereo=ac.createStereoPanner();
  source.type=type;source.frequency.setValueAtTime(hz,when);source.frequency.exponentialRampToValueAtTime(endHz,when+duration);
  filter.type='lowpass';filter.frequency.value=1600;filter.Q.value=.5;stereo.pan.value=pan;
  gain.gain.setValueAtTime(.0001,when);gain.gain.linearRampToValueAtTime(volume,when+.018);gain.gain.exponentialRampToValueAtTime(.0001,when+duration);
  source.connect(filter).connect(gain).connect(stereo).connect(bus);source.start(when);track(source,[filter,gain,stereo],when+duration+.02);
 }
 function staticBurst(when,duration=.7,volume=.095,pan=-.3){
  volume*=.60; // Softer interference; digital pulses, sonar and the score keep their levels.
  const source=ac.createBufferSource(),filter=ac.createBiquadFilter(),gain=ac.createGain(),stereo=ac.createStereoPanner();source.buffer=noise;
  filter.type='bandpass';filter.frequency.setValueAtTime(1050,when);filter.frequency.linearRampToValueAtTime(630,when+duration);filter.Q.value=.72;stereo.pan.value=pan;
  gain.gain.setValueAtTime(.0001,when);gain.gain.linearRampToValueAtTime(volume,when+Math.min(.008,duration*.1));
  for(const [t,v] of [[.2,.28],[.34,.75],[.51,.12],[.69,.65],[.86,.19]])gain.gain.linearRampToValueAtTime(volume*v,when+duration*t);
  gain.gain.linearRampToValueAtTime(.0001,when+duration);source.connect(filter).connect(gain).connect(stereo).connect(bus);
  source.start(when,random()*.5,duration);track(source,[filter,gain,stereo],when+duration+.02);
 }
 function stutter(when,count=7,volume=.14,pan=-.3){
  let cursor=when;
  for(let i=0;i<count;i++){
   const duration=.025+random()*.065;
   staticBurst(cursor,duration,volume*(.55+random()*.45),pan+(random()-.5)*.12);
   cursor+=duration+.023+random()*.065+(i===2?.11:0);
  }
 }
 function play(kind,when=ac.currentTime){
  last=kind;events++;const pan=(random()-.5)*.8;
  if(kind==='static')stutter(when,5+Math.floor(random()*4),.15,pan);
  else if(kind==='numbers'){
   stutter(when,3,.075,pan);
   // Repeated untuned carrier: phrasing suggests a transmission, never a melody.
   const carrier=1037+random()*22;
   for(const [offset,duration] of [[.48,.065],[.70,.065],[1.15,.13],[1.62,.065],[1.91,.10]])pip(when+offset,carrier,duration,.029,pan,'square');
   stutter(when+2.35,3,.068,-pan);
  }else if(kind==='sonar'){
   const hz=739.99+random()*90;
   for(let i=0;i<3;i++)pip(when+i*.62,hz,.95,.066*(.34**i),i%2?-pan:pan,'sine',hz*.976);
  }else if(kind==='bleeps'){
   const carrier=1379+random()*35;
   for(const [offset,duration] of [[0,.045],[.105,.045],[.39,.075],[.78,.045]])pip(when+offset,carrier,duration,.026,pan,'square');
  }
 }
 return {
  play,
  update(stage=0,focused=false){
   const now=ac.currentTime,mix=focused?.34:stage===2?.58:1;
   if(mix!==lastMix){bus.gain.setTargetAtTime(mix,now,.25);lastMix=mix;}
   if(now>=nextStatic){play('static',now+.03);nextStatic=now+3.0+random()*2.8;}
   if(now<next)return;
   // Following core shutdown, transmissions cease; residual static and pings remain.
   const kinds=stage===2?['sonar']:['bleeps','numbers','sonar'];play(kinds[index++%kinds.length],now+.04);
   next=now+(stage===1?10:13)+random()*7;
  },
  reset(){for(const [source,nodes] of voices){source.onended=null;try{source.stop();}catch{}source.disconnect();for(const n of nodes)n.disconnect();}voices.clear();next=ac.currentTime+7;nextStatic=ac.currentTime+1.2;index=events=0;last='none';lastMix=-1;},
  status(){return {last,events,activeVoices:voices.size,mix:lastMix};}
 };
}
