import {paintBunkerSurfaces,enhancePropReadability} from './cel-art-finish.js';
import { makeCelSign } from './signage.js';
import {shutdownState} from './shutdown.js';
import {bakeStatic} from './assets.js';
import {applySurfacePilot} from './surfaces.js';
import {makeServiceLift} from './service-lift.js';
import {lampLevel,nearbyBallast,emergencyPulse} from './atmosphere.js';
import litterAsset from '../assets/ration_litter.js';
import stockAsset from '../assets/supply_stack.js';
import cartonsAsset from '../assets/cardboard_cartons.js';
import sparesAsset from '../assets/maintenance_spares.js';
import consoleAsset from '../assets/bunker_console.js';
import breakerAsset from '../assets/breaker_cabinet.js';
import shelfAsset from '../assets/survival_shelf.js';
import bunkAsset from '../assets/crew_bunk.js';
import cartridgeAsset from '../assets/service_cartridge.js';
export function createBasement(scene){
 const T=THREE,Y=.406,staticRoot=new T.Group(),colliders=[],items=[],lights=[],alarmLights=[],decorations=[],propCache=new Map();
 let seed=707;const rand=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
 function surface(base,floor=false){const c=document.createElement('canvas');c.width=c.height=512;const x=c.getContext('2d');x.fillStyle=base;x.fillRect(0,0,512,512);for(let i=0;i<12500;i++){const v=rand();x.fillStyle=v<.5?'rgba(12,18,15,.07)':'rgba(180,184,164,.06)';x.fillRect(rand()*512,rand()*512,1+rand()*3,1+rand()*4);}for(let i=0;i<23;i++){let a=rand()*512,b=rand()*512,r=rand()*75+30;const s=x.createRadialGradient(a,b,0,a,b,r);s.addColorStop(0,'rgba(9,17,13,.16)');s.addColorStop(1,'rgba(9,17,13,0)');x.fillStyle=s;x.fillRect(a-r,b-r,2*r,2*r);}if(!floor){for(let i=0;i<20;i++){let a=rand()*512,b=rand()*100,h=100+rand()*390;let s=x.createLinearGradient(a,b,a,b+h);s.addColorStop(0,'rgba(13,23,18,.25)');s.addColorStop(1,'rgba(13,23,18,0)');x.fillStyle=s;x.fillRect(a,b,2+rand()*9,h);}}
 paintBunkerSurfaces(c,base,floor);
 const tex=new T.CanvasTexture(c);tex.encoding=T.sRGBEncoding;tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.repeat.set(floor?4:2,floor?4:1);tex.anisotropy=4;const m=new T.MeshStandardMaterial({map:tex,roughness:.98,metalness:floor?0:.08});m.userData.celBroadSurface=true;return m;}
 const concrete=surface('#5b5b4f'),floorMat=surface('#3c3d34',true),steel=new T.MeshStandardMaterial({color:0x414939,metalness:.65,roughness:.77}),dark=new T.MeshStandardMaterial({color:0x252b2c,metalness:.4,roughness:.86}),pipeMat=new T.MeshStandardMaterial({color:0x555648,metalness:.6,roughness:.74});
 // Horizontal concrete uses broad painted shapes without wall drips or fine bump.
 const ceilingMat=surface('#57594a',true);ceilingMat.map.repeat.set(2,2);ceilingMat.bumpMap=ceilingMat.map;ceilingMat.bumpScale=0;
 const B=(x,y,z,w,h,d,m=concrete,solid=false)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y+Y,z);o.castShadow=o.receiveShadow=true;staticRoot.add(o);if(solid)colliders.push({x,z,w,d,minY:Y,maxY:Y+h+1,angle:0});return o;};
 function pipe(a,b,r=.05){const p=new T.Vector3(...a),q=new T.Vector3(...b),v=q.clone().sub(p);const o=new T.Mesh(new T.CylinderGeometry(r,r,v.length(),12),pipeMat);o.position.copy(p.add(q).multiplyScalar(.5));o.position.y+=Y;o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());staticRoot.add(o);return o;}
 const wall=(x,z,w,d,h=3.55,y=h/2)=>B(x,y,z,w,h,d,concrete,true);
 function wallZ(x,z1,z2,doors=[]){let a=z1;for(const [center,width] of doors.sort((a,b)=>a[0]-b[0])){if(center-width/2>a)wall(x,(a+center-width/2)/2,.28,center-width/2-a);B(x,2.925,center,.30,1.25,width,concrete);a=center+width/2;}if(z2>a)wall(x,(a+z2)/2,.28,z2-a);}
 function wallX(z,x1,x2,doors=[],openingHeight=2.30){let a=x1;for(const [center,width] of doors.sort((a,b)=>a[0]-b[0])){if(center-width/2>a)wall((a+center-width/2)/2,z,center-width/2-a,.28);B(center,(3.55+openingHeight)/2,z,width,3.55-openingHeight,.30,concrete);a=center+width/2;}if(x2>a)wall((a+x2)/2,z,x2-a,.28);}
 // A small loop, with every doorway open in both geometry and collision.
 // Leave the cabin footprint out of the landing slab: coplanar decks caused z-fighting.
 B(0,-.12,14.675,22.5,.24,25.45,floorMat);
 for(const x of [-6.6125,6.6125])B(x,-.12,1.275,9.275,.24,1.35,floorMat);
 B(0,3.64,14,22.5,.20,26.8,ceilingMat);
 wallX(8,-11,11,[[0,3.6]]);wallX(27,-11,11);wallZ(-11,8,27);wallZ(11,8,27);
 wallZ(-2,8,27,[[12.2,2],[21.4,2]]);wallZ(2,8,14.6,[[11.5,2]]);
 // Wired observation window looks into the control room, above a low concrete sill.
 wall(2,16.3,.28,3.4,1.08,.54);B(2,2.81,16.3,.29,.56,3.4);for(const z of [14.65,17.95])B(2,1.88,z,.32,1.65,.075,steel);
 // Grille meets the sill, with each upright seated in the lower frame.
 B(2,1.10,16.3,.032,.04,3.30,steel);
 for(let z=14.8;z<18;z+=.30)B(2,1.805,z,.021,1.47,.012,dark);for(let y=1.4;y<2.65;y+=.3)B(2,y,16.3,.022,.012,3.22,dark);
 wallZ(2,18,27,[[23.1,2]]);wallX(17,-11,-2,[[-6.5,1.9]]);wallX(19,2,11,[[7.3,1.9]]);
 // Low suspended slabs retain the original footprint and all door locations.
 // The side rooms are 2.70 m high; service ducts sit just above standing headroom.
 for(const [x,z,w,d] of [[-6.5,12.5,8.74,8.74],[-6.5,22,8.74,9.74],[6.5,13.5,8.74,10.74],[6.5,23,8.74,7.74]]){
  B(x,2.82,z,w,.24,d,ceilingMat);for(const side of [-1,1])B(x+side*(w/2-.13),2.64,z,.16,.14,d,steel);
 }
 B(0,2.95,17.5,3.73,.24,18.7,ceilingMat);
 for(const z of [9.2,14.3,19.6,25.7]){B(0,2.71,z,3.68,.23,.22,steel);for(const x of [-1.7,1.7])B(x,2.30,z,.14,.68,.24,steel);}
 // Flattened ducts, raised cable trays and pipe saddles reinforce the close ceiling.
 for(const [x,z,w,d] of [[-6.5,20.1,6.5,.44],[6.5,14.8,6.5,.44],[6.5,22.7,6.5,.38]]){
  B(x,2.54,z,w,.23,d,pipeMat);for(let a=x-w/2+.3;a<x+w/2;a+=1.1)B(a,2.535,z,.04,.25,d+.015,dark);
 }
 for(const x of [-1.22,-.91])pipe([x,2.62,8.4],[x,2.62,26.5],.045);
 // Lift landing narrows naturally into the centre corridor.
 wallZ(-4,2,8);wallZ(4,2,8);wallX(2,-4,4,[[0,3.7]],3.40);
 B(-7.5,1.7,4,7,3.4,8,dark,true);B(7.5,1.7,4,7,3.4,8,dark,true);
 // Dado strips, slab seams, overhead structural ribs and functioning conduits.
 for(const x of [-10.82,10.82,-1.81,1.81])for(const [z,d] of [[9,1.3],[15.3,1.2],[25.8,1.6]])B(x,.20,z,.075,.27,d,dark);
 for(let z=9;z<27;z+=3.5){B(0,3.30,z,3.65,.31,.22,steel);for(const x of [-1.69,1.69])B(x,2.81,z,.16,.69,.22,steel);}
 // Stop before the lift frame; 90-degree elbows rise into ceiling sleeves.
 for(const x of [-1.20,-.85,1.25]){
  const radius=x===1.25?.085:.043;
  pipe([x,3.12,3.20],[x,3.12,26],radius);
  const bend=new T.Curve();bend.getPoint=(t,target=new T.Vector3())=>target.set(x,3.28-.16*Math.cos(t*Math.PI/2),3.20-.16*Math.sin(t*Math.PI/2));
  const elbow=new T.Mesh(new T.TubeGeometry(bend,10,radius,12,false),pipeMat);elbow.position.y=Y;elbow.castShadow=elbow.receiveShadow=true;staticRoot.add(elbow);
  pipe([x,3.28,3.04],[x,3.60,3.04],radius);
  B(x,3.527,3.04,radius*3.2,.024,radius*3.2,dark);
  for(let z=4;z<26;z+=3)B(x,3.19,z,.26,.04,.095,dark);
 }
 for(const [a,b] of [[[-10.65,.6,18],[-10.65,.6,26]],[[-10.65,.6,25],[-10.65,2.9,25]],[[-10.65,3.0,25],[-2.5,3.0,25]],[[3,3.05,18],[10.5,3.05,18]]])pipe(a,b,.075);
 for(let z=4;z<27;z+=4.5)B(0,.003,z,3.48,.003,.015,dark); // concrete construction joints, not raised floor panels
 // Bulb appearance, illumination and ballast hum share one failure envelope.
 function lamp(x,z,color=0xd4b782,intensity=1.35,range=8,height=2.70,failure=-1){
  B(x,height-.06,z,1.05,.12,.30,dark);const mat=new T.MeshStandardMaterial({color,emissive:color,emissiveIntensity:.85});const baseColor=mat.color.clone();
  B(x,height-.132,z,.83,.026,.14,mat);const l=new T.SpotLight(color,intensity*2.15,range*1.5,1.14,.69,1.3);l.position.set(x,Y+height-.22,z);l.target.position.set(x,Y,z);l.castShadow=true;l.shadow.mapSize.set(512,512);l.shadow.bias=-.001;l.shadow.normalBias=.03;scene.add(l,l.target);lights.push({light:l,base:intensity*2.15,mat,baseColor,failure});
 }
 lamp(0,5,0xd9b676,1.18,8,3.32,0);lamp(0,12.6,0xc4c19a,1.20,8,2.83,1);lamp(0,23.5,0xcfad70,1.35,9,2.83);
 lamp(-7,11.5,0xd0af73,1.24,9);lamp(-7,22.5,0xb6b78d,1.18,10);lamp(7,23,0xc7aa72,1.17,9,2.70,2);lamp(7,16,0xb5bf92,1.04,9);
 // Small low-level lamps retain orientation when an overhead fitting fails.
 for(const [x,z,angle] of [[-1.80,10.0,Math.PI/2],[1.80,20.0,-Math.PI/2],[-3.92,5.8,Math.PI/2]]){
  B(x,.30,z,.09,.14,.35,dark);const guide=new T.MeshStandardMaterial({color:0x92733c,emissive:0xb58442,emissiveIntensity:.65});B(x,.30,z,.10,.054,.20,guide);
  const glow=new T.PointLight(0xc99852,.23,3.3,1.8);glow.position.set(x+Math.sin(angle)*.10,Y+.28,z);scene.add(glow);
 }
 for(const [x,z] of [[-1.63,6.6],[-1.63,18],[-1.63,25.8],[10.57,14.2]]){const redMat=new T.MeshStandardMaterial({color:0x240503,emissive:0xdb1007,emissiveIntensity:0});B(x,2.46,z,.14,.23,.22,redMat);const l=new T.PointLight(0xda0c05,0,11,1.5);l.position.set(x<0?x+.38:x-.38,Y+2.43,z);scene.add(l);alarmLights.push({light:l,mat:redMat,controlRoom:x>0});}
 function label(text,x,y,z,w=1.6,angle=0){
  const o=makeCelSign(text.toUpperCase(),{width:w,height:w/4,family:'bunker'});
  o.name='Bunker sign / '+text;
  o.position.set(x,y+Y,z);o.rotation.y=angle;staticRoot.add(o);return o;
 }
 label('LOCAL CONTROL',2.16,2.46,11.5,1.20,Math.PI/2);label('SUPPLY 01',-2.16,2.46,12.2,1.24,-Math.PI/2);label('AUXILIARY',-2.16,2.46,21.4,1.22,-Math.PI/2);label('CREW',2.16,2.46,23.1,.92,Math.PI/2);
 label('B1  /  LOWER STATION',0,2.56,7.83,1.92,Math.PI);
 function prop(fn,x,z,angle=0){
  const varying=fn===stockAsset||fn===litterAsset||fn===bunkAsset;
  const variant=fn===bunkAsset?Math.abs(Math.round(x))%2:varying?Math.abs(Math.round(x*11)+Math.round(z*7))%3:0;
  if(!propCache.has(fn))propCache.set(fn,new Map());const variants=propCache.get(fn);
  if(!variants.has(variant)){const raw=fn(T,variant);enhancePropReadability(raw);applySurfacePilot(raw,'cargo_module');variants.set(variant,{raw,mesh:bakeStatic(raw)});}const cached=variants.get(variant),p=cached.mesh.clone(true);p.position.set(x,Y,z);p.rotation.y=angle;scene.add(p);if(fn!==cartridgeAsset)decorations.push(p);return {group:p,raw:cached.raw};}
 // Desk faces west into the room; built-in monitor has a separate live texture.
 const deskRaw=consoleAsset(T);enhancePropReadability(deskRaw);applySurfacePilot(deskRaw,'cargo_module');const anchor=deskRaw.getObjectByName('display-anchor');const displayPoint=new T.Vector3();anchor.getWorldPosition(displayPoint);const desk=bakeStatic(deskRaw);desk.position.set(9.2,Y,12);desk.rotation.y=-Math.PI/2;scene.add(desk);
 const monitor=new T.Group();monitor.position.copy(displayPoint);const display=document.createElement('canvas');display.width=1024;display.height=768;const tx=new T.CanvasTexture(display);tx.encoding=T.sRGBEncoding;const screen=new T.Mesh(new T.PlaneGeometry(.89,.68),new T.MeshBasicMaterial({map:tx,toneMapped:false}));monitor.add(screen);desk.add(monitor);
 colliders.push({x:9.2,z:12,w:1.15,d:2.8});items.push({id:'terminal',x:8.3,y:Y+1.6,z:12.4,radius:2.45,label:'Use control terminal'});
 const greenLight=new T.PointLight(0x79dea0,1.1,6,1.6);greenLight.position.set(8.2,Y+1.7,12.4);scene.add(greenLight);
 // Wall-mounted archive cabinets leave the console approach open.
 for(const x of [5.7,6.6]){B(x,1.04,18.49,.74,2.08,.65,steel,true);for(let y=.4;y<1.9;y+=.3)B(x,y,18.151,.58,.16,.028,dark);}
 const rationShelf=T=>shelfAsset(T,1),equipmentShelf=T=>shelfAsset(T,2);
 prop(shelfAsset,-7.6,9.0,0);prop(rationShelf,-10.0,13,Math.PI/2);colliders.push({x:-7.6,z:9,w:2.9,d:.9},{x:-10,z:13,w:.9,d:2.9});
 prop(equipmentShelf,-3.4,15.7,Math.PI);colliders.push({x:-3.4,z:15.7,w:2.9,d:.9});
 // Service shelf: isolated cartridge silhouette and a dedicated task light.
 B(-8.7,.84,15.4,1.54,.09,.79,steel,true);for(const x of [-9.3,-8.1])B(x,.4,15.4,.08,.8,.68,dark);const cart=prop(cartridgeAsset,-8.65,15.30,0);cart.group.position.y+=.887;
 const cartridgeLight=new T.PointLight(0x8fc39d,.50,3,1.7);cartridgeLight.position.set(-8.65,Y+1.25,15.3);scene.add(cartridgeLight);
 items.push({id:'cartridge',x:-8.65,y:Y+1,z:15.3,radius:1.95,label:'Take override cartridge'});
 prop(breakerAsset,-7.3,25.65,Math.PI);colliders.push({x:-7.3,z:25.65,w:3.4,d:.75});items.push({id:'power',x:-7.3,y:Y+1.4,z:25.3,radius:2.4,label:'Inspect auxiliary breakers'});
 for(const x of [-4.4,-3.3]){B(x,1.04,25.9,.75,2.08,.68,dark,true);for(let y=.35;y<1.9;y+=.16)B(x,y,25.55,.57,.035,.021,steel);}
 prop(bunkAsset,8.5,25.8,Math.PI);prop(bunkAsset,9.9,21.7,-Math.PI/2);colliders.push({x:8.5,z:25.8,w:2.45,d:1.25},{x:9.9,z:21.7,w:1.25,d:2.45});
 for(const x of [3.0,3.8]){B(x,1.07,26.45,.68,2.14,.69,steel,true);B(x,1.12,26.09,.56,1.91,.027,dark);B(x+.18,1.02,26.06,.024,.18,.043,pipeMat);}
 // Quiet environmental note, directly on a lived-in bedside table.
 B(5.3,.65,24.4,1.45,.10,.75,steel,true);for(const x of [4.7,5.9])B(x,.3,24.4,.05,.6,.61,dark);B(5.2,.707,24.35,.38,.015,.28,new T.MeshStandardMaterial({color:0xa09e80,roughness:1})).rotation.y=.15;
 items.push({id:'note',x:5.3,y:Y+.8,z:24.4,radius:1.9,label:'Read shift note'});
 // Ventilation fan in a thick, slatted housing.
 B(-10.7,2.35,21,.19,1.20,1.35,dark);for(let z=20.43;z<21.6;z+=.13)B(-10.58,2.35,z,.03,1.09,.025,steel);
 // Overflow stock breaks up the large rooms, leaving the established loop open.
 function stock(x,z,angle=0,scale=1){const q=prop(stockAsset,x,z,angle).group;q.scale.setScalar(scale);const w=1.7*scale,d=1.10*scale;colliders.push({x,z,w:Math.abs(Math.cos(angle))*w+Math.abs(Math.sin(angle))*d,d:Math.abs(Math.sin(angle))*w+Math.abs(Math.cos(angle))*d});return q;}
 prop(rationShelf,-4.35,9.0,0);colliders.push({x:-4.35,z:9,w:2.94,d:.9});
 prop(equipmentShelf,-4.25,14.45,Math.PI/2);colliders.push({x:-4.25,z:14.45,w:.90,d:2.94});
 stock(-9.1,10.7,.06,.86);stock(-9.7,18.9,.08,.92);stock(-9.65,23.4,-.08,.94);stock(-3.7,23.7,.11,.83);
 stock(3.55,9.55,.08,.80);stock(8.65,23.35,-.07,.76);stock(4.3,20.25,.08,.85);
 stock(-1.43,17.7,Math.PI/2,.64);stock(1.40,25.8,Math.PI/2,.62);
 // A second dead desk; the observation window has a clear view into control.
 const broken=prop(consoleAsset,9.2,16.4,-Math.PI/2).group;colliders.push({x:9.2,z:16.4,w:1.15,d:2.8});
 // A dim fault raster and steady red status lamp distinguish the failed station.
 const faultCanvas=document.createElement('canvas');faultCanvas.width=512;faultCanvas.height=384;const f=faultCanvas.getContext('2d');
 f.fillStyle='#050806';f.fillRect(0,0,512,384);f.fillStyle='#813c31';f.font='bold 29px monospace';f.fillText('TERMINAL FAULT',34,110);f.font='20px monospace';f.fillText('DISPLAY LINK LOST',34,160);f.fillText('SERVICE REQUIRED',34,205);f.fillRect(34,283,16,5);
 const faultTexture=new T.CanvasTexture(faultCanvas);faultTexture.encoding=T.sRGBEncoding;const faultScreen=new T.Mesh(new T.PlaneGeometry(.89,.68),new T.MeshBasicMaterial({map:faultTexture,toneMapped:false}));faultScreen.position.copy(displayPoint);broken.add(faultScreen);
 const faultLamp=new T.Mesh(new T.BoxGeometry(.105,.044,.035),new T.MeshBasicMaterial({color:0xc7432e,toneMapped:false}));faultLamp.position.set(.88,1.485,.225);broken.add(faultLamp);
 // Overflow cartons stay at the blind end, outside the walking loop.
 prop(cartonsAsset,-.95,26.35,.05);colliders.push({x:-.95,z:26.35,w:1.64,d:.96});
 for(const [x,z,a] of [[-9.4,14.8,.2],[-3.35,15.8,1.2],[8.4,24.85,.4],[4.4,25.7,2],[9.3,20.4,-.3],[5.65,24.2,1.1],[9.8,9.2,.5],[3.6,17.9,2.2],[-1.47,16.2,.3]])prop(litterAsset,x,z,a);
 for(const [x,z,a] of [[-9.6,20.9,.5],[-8.8,25.95,0],[-3.4,19.1,.4],[8.9,17.95,.7],[-3.2,25.9,1.5]])prop(sparesAsset,x,z,a);
 // Paper and used tins on the spare desk; equipment is lifted onto a real surface.
 const deskWaste=prop(litterAsset,9.2,16.6,.25).group;deskWaste.scale.setScalar(.55);deskWaste.position.y+=1.19;
 // Lift is the exact approved cabin, repositioned below ground; exterior shell is omitted.
 const level={extraction:{x:0,z:0,pad:{visible:false}},colliders,surfaces:[],ramps:[]};const lift=makeServiceLift(scene,level);lift.shell.visible=false;lift.shaft.visible=false;lift.unlock();
 items.push({id:'lift',x:0,y:Y+1.1,z:.2,radius:1.6,label:'Return to the surface'});
 const environment=bakeStatic(staticRoot);scene.add(environment);
 const propRoot=new T.Group();for(const p of decorations){scene.remove(p);propRoot.add(p);}scene.add(bakeStatic(propRoot));
 const ambient=new T.AmbientLight(0x9b9d81,.18);scene.add(ambient);
 let lastScreen='';function updateScreen(m,time){
  const shutdown=shutdownState(m),key=[m.power,m.cartridge,m.isolated,Math.floor(shutdown.elapsed*2),Math.floor(time)].join();if(key===lastScreen)return;lastScreen=key;
  const c=display.getContext('2d');c.fillStyle='#04130c';c.fillRect(0,0,1024,768);c.fillStyle=shutdown.warden?'#ff7354':'#87e9a6';c.shadowBlur=8;c.shadowColor=c.fillStyle;c.font='bold 49px monospace';c.fillText('NIVALIS / CORE MAINTENANCE',55,90);c.font='31px monospace';
  const lines=m.isolated?(shutdown.complete?['COMMAND CORE: OFFLINE','SURFACE PATROLS: DOWN','','INDEPENDENT FAILSAFE ACTIVE','WARDEN PROTOCOL ACTIVE','','RETURN TO SURFACE']:shutdown.lines.filter(Boolean).slice(-7)):!m.power?['SURVEILLANCE: ISOLATED','SURFACE PATROLS: LOCAL','COMMAND CORE: ACTIVE','','RESTORE MAINTENANCE BUS','INTERLOCK: CONSOLE + AIR']:!m.cartridge?['AUXILIARY SUPPLY: ONLINE','COMMAND CORE: ACTIVE','','INSERT OVERRIDE CARTRIDGE','','SERVICE SHELF / SUPPLY STORE']:['OVERRIDE CARTRIDGE VERIFIED','','CORE SHUTDOWN AVAILABLE','','PRESERVE LIFT FEED','','[ ACCESS CIRCUIT ROUTING ]'];
  lines.forEach((s,i)=>c.fillText(s,55,195+i*66));if(Math.floor(time)%2===0)c.fillRect(55,685,23,35);c.shadowBlur=0;for(let y=0;y<768;y+=4){c.fillStyle='rgba(0,0,0,.12)';c.fillRect(0,y,1024,1);}tx.needsUpdate=true;
 }
 // Emergency supply replaces the warm room lights; blend over two seconds.
 const normalAmbient=ambient.color.clone(),emergencyAmbient=new T.Color(0x54211d),emergencyRed=new T.Color(0xc10c06);
 const normalFog=scene.fog?.color.clone(),emergencyFog=new T.Color(0x180806);
 let emergency=0,quietDim=1;
 function applyLighting(time,reduced){
  const pulse=emergencyPulse(time,reduced);
  for(const a of alarmLights){a.light.intensity=emergency*pulse*(a.controlRoom?.92:1.6);a.mat.emissiveIntensity=emergency*pulse*(a.controlRoom?.16:.24);}
  for(const a of lights){
   const normal=a.failure<0?1:lampLevel(time,a.failure,reduced),strength=normal*(1-emergency)+pulse*emergency;
   a.light.color.copy(a.baseColor).lerp(emergencyRed,emergency);
   a.light.intensity=a.base*(1-emergency*.78)*strength*quietDim;
   a.mat.emissive.copy(a.baseColor).lerp(emergencyRed,emergency);
   a.mat.emissiveIntensity=(.85-emergency*.42)*strength*quietDim;
   a.mat.color.copy(a.baseColor).lerp(emergencyRed,emergency).multiplyScalar(.02+.98*strength);
  }
  ambient.color.copy(normalAmbient).lerp(emergencyAmbient,emergency);ambient.intensity=(.18-emergency*.095)*quietDim;
  greenLight.color.setHex(0x79dea0).lerp(emergencyRed,emergency);
  greenLight.intensity*=1-emergency+emergency*.40*pulse;
  if(scene.fog){scene.fog.color.copy(normalFog).lerp(emergencyFog,emergency);scene.fog.density=.027+emergency*.014;}
 }
 return {
  Y,colliders,items,lift,environment,display,desk,
  ballast(p,time,reduced){return nearbyBallast(p,time,reduced);},
  lighting(time,reduced=false){return {emergency,cabin:lift.status(),ambient:ambient.intensity,fog:scene.fog?.density,alarms:alarmLights.map(a=>a.light.intensity),fittings:lights.filter(a=>a.failure>=0).map(a=>({failure:a.failure,level:lampLevel(time,a.failure,reduced),emission:a.mat.emissiveIntensity,intensity:a.light.intensity}))};},
  room(p){if(p.z<8)return'SERVICE LIFT';if(p.x< -2)return p.z<17?'SUPPLY STORE':'MAINTENANCE';if(p.x>2)return p.z<19?'LOCAL CONTROL':'EMERGENCY QUARTERS';return'LOWER CORRIDOR';},
  update(dt,p,m,time){
   const shutdown=shutdownState(m);const quietTarget=shutdown.quiet?.62:1;quietDim+=(quietTarget-quietDim)*(1-Math.exp(-dt*4));
   emergency=T.MathUtils.clamp(emergency+(shutdown.warden?dt/2:-dt*2),0,1);
   lift.setEmergency(emergency);lift.update(dt,p);updateScreen(m,time);cart.group.visible=!m.cartridge;cartridgeLight.intensity=m.cartridge?0:.5;greenLight.intensity=m.power?1.5:.6;
   const reduced=window.__reduceBunkerMotion??matchMedia('(prefers-reduced-motion: reduce)').matches;
   applyLighting(time,reduced);
  },
  reset(){lastScreen='';emergency=0;quietDim=1;greenLight.intensity=.6;applyLighting(0,true);lift.reset();lift.unlock();}
 };
}
