import { bakeStatic } from './assets.js';
import { applySurfacePilot } from './surfaces.js';
import { emergencyPulse } from './atmosphere.js';

// Approved surface cabin, reused below ground. This local copy ascends back
// to the surface; the original two levels and their authored locations are unchanged.
export function makeServiceLift(scene,level){
 const anchor={x:level.extraction.x,z:level.extraction.z,y:.406},depth=18;
 const shell=new THREE.Group(),cab=new THREE.Group(),shaft=new THREE.Group();
 shell.name='North service lift / original extraction location';cab.name='Service lift cabin';shaft.name='Service lift shaft';
 shell.position.set(anchor.x,anchor.y,anchor.z);cab.position.copy(shell.position);shaft.position.copy(shell.position);
 const mat=(color,metalness=.5,roughness=.78)=>{const m=new THREE.MeshStandardMaterial({color,metalness,roughness});m.color.convertSRGBToLinear();return m;};
 const steel=mat(0x61717a,.7),dark=mat(0x26343e),black=mat(0x121c23,.1),rust=mat(0x815237,.28,.95),snow=mat(0xdde7eb,0,.98);
 const warm=new THREE.MeshStandardMaterial({color:0xd48c43,emissive:0xff8b32,emissiveIntensity:.65,roughness:.7});
 // Local cabin finishes: worn graphite paint and dark water stains.
 // Keep the existing exterior coating separate so the threshold reads clearly.
 const finish=document.createElement('canvas');finish.width=finish.height=512;
 const ink=finish.getContext('2d');let seed=909;
 const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
 ink.fillStyle='#414744';ink.fillRect(0,0,512,512);
 for(let i=0;i<1800;i++){const x=random()*512,y=random()*512;ink.fillStyle=i%3?'rgba(12,18,17,.10)':'rgba(114,111,88,.08)';ink.fillRect(x,y,1+random()*8,1+random()*3);}
 for(let i=0;i<28;i++){const x=random()*512,y=random()*512,r=18+random()*65;const stain=ink.createRadialGradient(x,y,0,x,y,r);stain.addColorStop(0,'rgba(11,18,16,.24)');stain.addColorStop(1,'rgba(11,18,16,0)');ink.fillStyle=stain;ink.fillRect(x-r,y-r,r*2,r*2);}
 for(let i=0;i<38;i++){const x=random()*512,y=random()*.18*512,h=80+random()*230;const stain=ink.createLinearGradient(0,y,0,y+h);stain.addColorStop(0,'rgba(16,22,20,.42)');stain.addColorStop(1,'rgba(16,22,20,0)');ink.fillStyle=stain;ink.fillRect(x,y,1+random()*4,h);}
 const finishTexture=new THREE.CanvasTexture(finish);finishTexture.encoding=THREE.sRGBEncoding;finishTexture.anisotropy=4;
 const cabinPaint=new THREE.MeshStandardMaterial({map:finishTexture,metalness:.23,roughness:.94});
 const cabinSteel=mat(0x40463f,.55,.87),grime=mat(0x202821,.05,1);
 // A single flush concrete deck, with fine aggregate and soft wear instead of ribs.
 const floorCanvas=document.createElement('canvas');floorCanvas.width=floorCanvas.height=512;
 const floorInk=floorCanvas.getContext('2d'),aggregate=floorInk.createImageData(512,512);
 seed=9019;
 for(let y=0;y<512;y++)for(let x=0;x<512;x++){
  const i=(y*512+x)*4,cloud=Math.sin(x*.018+Math.sin(y*.026))*3+Math.sin(y*.041+x*.012)*2;
  const shade=108+cloud+(random()-.5)*14-(random()>.995?16:0);
  aggregate.data[i]=shade;aggregate.data[i+1]=shade+2;aggregate.data[i+2]=shade+1;aggregate.data[i+3]=255;
 }
 floorInk.putImageData(aggregate,0,0);
 for(let i=0;i<18;i++){const x=random()*512,y=random()*512,r=20+random()*70;const stain=floorInk.createRadialGradient(x,y,0,x,y,r);stain.addColorStop(0,'rgba(25,30,29,.09)');stain.addColorStop(1,'rgba(25,30,29,0)');floorInk.fillStyle=stain;floorInk.fillRect(x-r,y-r,r*2,r*2);}
 const concreteMap=new THREE.CanvasTexture(floorCanvas);concreteMap.encoding=THREE.sRGBEncoding;concreteMap.anisotropy=4;
 const concrete=new THREE.MeshStandardMaterial({map:concreteMap,roughness:.98,metalness:0});concrete.name='Worn concrete cabin floor';
 const mesh=(parent,geo,m,x,y,z)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;parent.add(o);return o;};
 const box=(p,x,y,z,w,h,d,m)=>mesh(p,new THREE.BoxGeometry(w,h,d),m,x,y,z);
 const bolt=(p,x,y,z)=>{const b=mesh(p,new THREE.CylinderGeometry(.035,.035,.025,6),steel,x,y,z);b.rotation.x=Math.PI/2;};
 const structural=new THREE.Group();
 for(const side of [-1,1]){
  box(structural,side*2.96,1.83,1.9,.07,3.20,.10,rust);
 }
 box(structural,0,3.59,2.0,5.90,.34,.70,dark);box(structural,0,3.792,2.01,5.76,.055,.72,snow);
 // The upper shaft is enclosed too; no exterior snow is visible through the cab.
 box(structural,0,1.57,-2.33,4.8,3.8,.28,black);
 for(const y of [.65,2.65])box(structural,0,y,-2.16,4.10,.06,.08,steel);
 box(structural,0,2.4,-2.145,.16,.1,.035,warm);
 box(structural,0,.015,2.06,4.12,.05,.46,steel);
 // Short threshold ramp connects the original ground route to the raised cab.
 const ramp=new THREE.BufferGeometry();ramp.setAttribute('position',new THREE.Float32BufferAttribute([-1.92,-anchor.y,3.3,1.92,0,2,-1.92,0,2,-1.92,-anchor.y,3.3,1.92,-anchor.y,3.3,1.92,0,2],3));ramp.computeVertexNormals();
 mesh(structural,ramp,dark,0,0,0);
 box(structural,2.98,1.55,2.04,.53,.83,.24,dark);
 const callLight=box(shell,2.98,1.50,2.19,.20,.09,.025,new THREE.MeshBasicMaterial({color:0xd29556}));
 applySurfacePilot(structural,'cargo_module');shell.add(bakeStatic(structural));scene.add(shell);
 // A dim, enclosed volume, with a guarded view into the shaft behind it.
 const inside=new THREE.Group();box(inside,0,-.06,0,3.95,.12,3.90,concrete);
 for(const side of [-1,1]){
  // Side walls end behind the separate door tracks, leaving a real pocket.
  box(inside,side*1.98,1.58,-.235,.12,3.16,3.43,dark);box(inside,side*1.901,1.77,-.235,.035,2.18,3.18,cabinPaint);
  box(inside,side*1.865,.99,-.235,.065,.045,3.15,cabinSteel);box(inside,side*1.9,.22,-.235,.035,.35,3.20,black);
  box(inside,side*1.11,1.57,-1.94,1.70,3.14,.13,dark);box(inside,side*1.15,1.74,-1.858,1.48,2.25,.035,cabinPaint);
  box(inside,side*.27,1.62,-1.825,.055,2.15,.08,cabinSteel);
  for(const x of [side*.48,side*1.77])for(const y of [.70,2.70])bolt(inside,x,y,-1.815);
  // Recessed ventilation and a low, rubbed kickplate break up the wall panels.
  for(let y=.28;y<.64;y+=.07)box(inside,side*1.18,y,-1.846,1.32,.035,.035,grime);
  box(inside,side*1.74,2.87,0,.16,.12,2.82,black);
 }
 box(inside,0,3.19,0,3.95,.15,3.9,dark);
 // The failing strip has its own material; shaft lamps remain steady.
 const cabinBulb=warm.clone(),bulbColor=cabinBulb.color.clone(),bulbEmission=cabinBulb.emissive.clone();
 const normalCabinLight=new THREE.Color(0xffb05d),alarmCabinLight=new THREE.Color(0xd30a05);cabinBulb.name='Cabin ceiling strip';
 box(inside,0,3.083,0,.19,.07,1.78,black);box(inside,0,3.037,0,.085,.025,1.55,cabinBulb);
 for(const y of [.65,1.32,2,2.65])box(inside,0,y,-1.84,.54,.035,.09,cabinSteel);
 box(inside,0,.23,-1.82,3.76,.40,.03,cabinSteel);
 const glass=new THREE.MeshStandardMaterial({color:0x5e685c,transparent:true,opacity:.12,roughness:.8,metalness:.1});
 box(inside,0,1.61,-1.86,.48,2.1,.018,glass);
 applySurfacePilot(inside,'cargo_module');cab.add(bakeStatic(inside));
 // Hollow side cassettes conceal two telescoping leaves on separate tracks.
 // Their outer edges fit inside the original cargo building's existing walls.
 const pockets=new THREE.Group();
 for(const side of [-1,1]){
  box(pockets,side*2.30,1.70,2.25,1.02,3.40,.16,dark);
  box(pockets,side*2.30,1.70,1.50,1.02,3.40,.14,dark);
  box(pockets,side*2.82,1.70,1.875,.10,3.40,.89,dark);
  box(pockets,side*2.30,3.35,1.88,1.08,.12,.89,dark);
  box(pockets,side*2.30,.06,1.88,1.08,.10,.89,black);
  // Basement landing: expose the dark door recesses without exterior enamel panels.
  box(pockets,side*2.30,1.77,1.414,.86,3.06,.025,cabinPaint);
  box(pockets,side*1.83,1.60,2.355,.055,3.12,.03,cabinSteel);
 }
 for(const z of [1.76,2.02]){box(pockets,0,3.10,z,5.55,.07,.075,steel);box(pockets,0,.008,z,5.55,.026,.036,black);}
 applySurfacePilot(pockets,'cargo_module');const housing=bakeStatic(pockets);housing.name='Service lift door pockets';cab.add(housing);
 const doorMat=cabinPaint.clone(),doors=[];
 for(const side of [-1,1])for(const track of [0,1]){
  const closed=track===0?.45:1.35,leaf=new THREE.Group();leaf.position.set(side*closed,0,track===0?2.02:1.76);
  box(leaf,0,1.52,0,track===0?.90:.92,3.04,.10,doorMat);box(leaf,0,.25,.064,.86,.32,.022,dark);
  box(leaf,0,1.60,-.064,.86,2.75,.022,cabinPaint);box(leaf,0,.23,-.068,.86,.32,.025,cabinSteel);
  for(let y=.5;y<2.7;y+=.39)box(leaf,0,y,.06,.72,.012,.016,dark);
  box(leaf,-side*.415,1.52,.067,.024,2.92,.02,cabinSteel);
  for(const x of [-.34,.34])for(const y of [.4,2.8])bolt(leaf,x,y,.076);
  applySurfacePilot(leaf,'cargo_module');const p=leaf.position.clone();leaf.position.set(0,0,0);const baked=bakeStatic(leaf);baked.position.copy(p);baked.name=`Lift door ${side<0?'left':'right'} / track ${track}`;cab.add(baked);doors.push({group:baked,side,closed});
 }
 const cabinLight=new THREE.PointLight(0xffb05d,1.85,5.5,1.8);cabinLight.position.set(0,2.74,0);cab.add(cabinLight);
 // Keep this light inside the cab instead of washing through its roof into
 // the container. The small local shadow volume excludes the distant compound.
 cabinLight.castShadow=true;cabinLight.shadow.mapSize.set(256,256);cabinLight.shadow.camera.near=.06;cabinLight.shadow.camera.far=5.5;cabinLight.shadow.bias=-.0002;cabinLight.shadow.normalBias=.015;
 const emergency=new THREE.MeshBasicMaterial({color:0xb64026});box(cab,1.69,2.75,-1.81,.085,.06,.03,emergency);
 scene.add(cab);
 const shaftStructure=new THREE.Group();
 for(const side of [-1,1])box(shaftStructure,side*2.30,depth/2,0,.35,depth+7,4.9,dark);
 box(shaftStructure,0,depth/2,-2.33,4.95,depth+7,.28,black);box(shaftStructure,0,depth/2,2.38,4.95,depth+7,.26,black);
 for(let y=-2.6;y<=depth+3;y+=2.6){box(shaftStructure,0,y,-2.155,4.10,.08,.08,steel);box(shaftStructure,0,y,-2.09,.32,.24,.025,warm);}
 shaft.add(bakeStatic(shaftStructure));shaft.visible=false;scene.add(shaft);
 const walls=[];const solid=(x,z,w,d,minY,maxY,type)=>{const c={x:anchor.x+x,z:anchor.z+z,w,d,minY:anchor.y+minY,maxY:anchor.y+maxY,angle:0,type};level.colliders.push(c);walls.push(c);return c;};
 solid(-1.98,-.235,.12,3.43,0,3.3,'lift-wall');solid(1.98,-.235,.12,3.43,0,3.3,'lift-wall');solid(0,-1.94,4.08,.13,0,3.3,'lift-wall');
 for(const side of [-1,1])solid(side*2.33,1.875,1.08,.96,0,3.4,'lift-pocket');
 const gate=solid(0,2.02,3.66,.18,0,3.1,'lift-doors');
 level.surfaces.push({x:anchor.x,z:anchor.z,w:3.85,d:3.8,y:anchor.y,angle:0});
 level.ramps.push({x:anchor.x,z:anchor.z+2.65,w:3.84,d:1.3,low:0,high:anchor.y,angle:0});
 level.extraction.pad.visible=false;
 let mode='locked',time=0,opening=0,travel=0,hidden=[];
 const reducedFlicker=matchMedia('(prefers-reduced-motion: reduce)').matches;
 let emergencyMix=0,lightClock=0,nextFlicker=1.6,flickerStart=-10,flickerCount=0,wasInside=false;
 function updateLight(dt){
  lightClock+=dt;
  if(lightClock>=nextFlicker){flickerStart=lightClock;flickerCount++;nextFlicker=lightClock+3.1+(Math.sin(flickerCount*12.9898)*43758.5453%1+1)*.7;}
  const t=lightClock-flickerStart;
  // A sustained dropout followed by one shorter failed restart. The pauses
  // between failures leave the room readable and avoid a repeating strobe.
  const pulse=(a,b)=>THREE.MathUtils.smoothstep(t,a-.04,a)*(1-THREE.MathUtils.smoothstep(t,b,b+.08));
  const reduced=window.__reduceBunkerMotion??reducedFlicker,normal=reduced?1:Math.max(.015,1-.985*pulse(.12,.48)-.92*pulse(.84,1.02));
  const strength=normal*(1-emergencyMix)+emergencyPulse(lightClock,reduced)*emergencyMix;
  cabinLight.color.copy(normalCabinLight).lerp(alarmCabinLight,emergencyMix);
  cabinLight.intensity=1.85*(1-emergencyMix*.55)*strength;
  cabinBulb.emissive.copy(bulbEmission).lerp(alarmCabinLight,emergencyMix);
  cabinBulb.emissiveIntensity=(.95-emergencyMix*.55)*strength;
  cabinBulb.color.copy(bulbColor).lerp(alarmCabinLight,emergencyMix).multiplyScalar(.025+.975*strength);
  // Shaft markers follow the same emergency supply throughout the ascent.
  warm.color.copy(bulbColor).lerp(alarmCabinLight,emergencyMix);
  warm.emissive.copy(bulbEmission).lerp(alarmCabinLight,emergencyMix);warm.emissiveIntensity=.65-emergencyMix*.42;
 }
 const inCab=p=>Math.abs(p.x-anchor.x)<1.47&&p.z>anchor.z-1.45&&p.z<anchor.z+1.38&&Math.abs(p.y-anchor.y)<.4;
 function restore(){for(const [o,visible] of hidden)o.visible=visible;hidden=[];shaft.visible=false;}
 function reset(){restore();emergencyMix=0;mode='locked';time=opening=travel=0;lightClock=flickerCount=0;nextFlicker=1.6;flickerStart=-10;wasInside=false;updateLight(0);cab.position.y=anchor.y;gate.minY=anchor.y;gate.maxY=anchor.y+3.1;doors.forEach(d=>d.group.position.x=d.side*d.closed);callLight.material.color.set(0xd29556);}
 function unlock(){if(mode!=='locked')return;mode='ready';callLight.material.color.set(0x80dbc7);}
 function begin(player){if(mode!=='ready'||!inCab(player))return false;mode='closing';time=0;return true;}
 function update(dt,player){
  const insideNow=inCab(player)||mode==='closing'||mode==='descending';
  if(insideNow&&!wasInside)nextFlicker=Math.min(nextFlicker,lightClock+.55);
  wasInside=insideNow;updateLight(dt);
  if(mode==='ready')opening=Math.min(1,opening+dt*.6);
  if(mode==='closing'){time+=dt;opening=Math.max(0,opening-dt*.6);if(opening===0&&time>1.7){mode='descending';time=0;hidden=scene.children.filter(o=>o!==cab&&o!==shaft).map(o=>[o,o.visible]);hidden.forEach(([o])=>o.visible=false);shaft.visible=true;}}
  const slide=opening*opening*(3-2*opening);
  gate.minY=slide>.94?100:anchor.y;gate.maxY=slide>.94?104:anchor.y+3.1;
  doors.forEach(d=>d.group.position.x=d.side*(d.closed+(2.28-d.closed)*slide));
  if(mode==='descending'){time+=dt;const t=Math.min(1,time/8.5);travel=t*t*(3-2*t);cab.position.y=anchor.y+travel*depth;player.y=cab.position.y;player.vy=0;player.grounded=true;if(t===1){mode='arrived';return true;}}
  return false;
 }
 // Restore the scene for an end-screen camera without changing completed travel.
 reset();return{showEndBackdrop:restore,anchor,shell,cab,shaft,inCab,unlock,begin,update,reset,setEmergency(value){emergencyMix=THREE.MathUtils.clamp(value,0,1);},get mode(){return mode;},get moving(){return mode==='ready'&&opening<1||mode==='closing'&&opening>0;},get active(){return mode==='closing'||mode==='descending'||mode==='arrived';},get travel(){return travel;},status(){return{mode,location:[anchor.x,anchor.z],depth:Math.round(travel*depth),destination:'Surface / WARDEN',emergency:emergencyMix,lightColor:cabinLight.color.getHexString(),light:Math.round(cabinLight.intensity/1.85*100),flicker:!(window.__reduceBunkerMotion??reducedFlicker)};}};
}
