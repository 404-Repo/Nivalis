// Slow failing-ballast interruptions, shared by the rendered fitting and its buzz.
// A steady alternative follows the player's reduced-motion preference.
export const FAILING_LIGHTS=[{x:0,z:5,period:13.7,phase:1.8},{x:0,z:12.6,period:17.3,phase:5.2},{x:7,z:23,period:15.1,phase:9.1}];
export function lampLevel(time,index,reduced=false){
 if(reduced)return 1;const f=FAILING_LIGHTS[index];const cycle=Math.floor((time+f.phase)/f.period),t=(time+f.phase)%f.period;
 const offset=Math.sin(cycle*7.17+index*1.31)*.45;
 const pulse=(a,b)=>{a+=offset;b+=offset;if(t<a-.05||t>b+.12)return 0;if(t<a)return(t-a+.05)/.05;if(t<b)return 1;return 1-(t-b)/.12;};
 return Math.max(.035,1-.965*pulse(1.3,2.04)-.84*pulse(3.16,3.43));
}
export function nearbyBallast(player,time,reduced=false){let level=0;for(let i=0;i<FAILING_LIGHTS.length;i++){const f=FAILING_LIGHTS[i],distance=Math.hypot(player.x-f.x,player.z-f.z),proximity=Math.max(0,1-distance/6.5);level+=proximity*(.30+.70*lampLevel(time,i,reduced));}return Math.min(1,level);}

// A six-second breathing swell, never an on/off flash.
export function emergencyPulse(time,reduced=false){return reduced?.56:.56+.28*Math.sin(time*Math.PI/3);}
