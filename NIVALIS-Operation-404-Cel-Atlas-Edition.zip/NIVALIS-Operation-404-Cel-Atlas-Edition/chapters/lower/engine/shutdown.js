// One mission-clock timeline drives the terminal, room and sound cues.
// Surviving patrols crash here; no infiltration kills or campaign scores change.
export const SHUTDOWN_BEATS=Object.freeze([
 {at:0,line:'COMMAND CORE .......... OFFLINE'},
 {at:.6,line:'BACKUP / RECOVERY ..... ISOLATED'},
 {at:1.1,line:'LIFT FEED ............. RETAINED'},
 {at:1.8,line:'CORE HEARTBEAT ........ LOST'},
 {at:2.5,line:'PATROL FLIGHT AUTHORITY REVOKED'},
 {at:3.1,line:'SURFACE MOTORS ........ STOPPED',cue:'crash-near'},
 {at:3.9,line:'',cue:'crash-far'},
 {at:4.6,line:'REMAINING PATROLS ..... DOWN'},
 {at:5.5,line:'INDEPENDENT POWER ..... DETECTED'},
 {at:6.3,line:'WARDEN FAILSAFE ....... RESPONDING',cue:'warden'},
 {at:7.6,line:'WARDEN PROTOCOL ....... ACTIVE',cue:'alarm'}
]);
export const SHUTDOWN_END=9.8;
export function shutdownState(m){
 const elapsed=m.isolated?m.shutdownTime??0:0;
 return {elapsed,quiet:m.isolated&&elapsed<6.3,patrolsDown:m.isolated&&elapsed>=4.6,warden:m.isolated&&elapsed>=6.3,alarm:m.isolated&&elapsed>=7.6,complete:m.isolated&&elapsed>=SHUTDOWN_END,
  lines:m.isolated?SHUTDOWN_BEATS.filter(b=>b.at<=elapsed).map(b=>b.line):[]};
}
export function advanceShutdown(m,dt){
 if(!m.isolated)return [];
 const before=m.shutdownTime??0;m.shutdownTime=Math.min(SHUTDOWN_END,before+Math.max(0,dt));
 return SHUTDOWN_BEATS.filter(b=>b.cue&&b.at>before&&b.at<=m.shutdownTime).map(b=>b.cue);
}
