// Reference: references/basement-props-reference.png (built-in image generation).
// Metres, Y-up, front +Z. Real model surfaces; no remote assets.
function kit(T){
 const g=new T.Group(),m={};
 const material=(name,color,metalness=.5,roughness=.8)=>{const a=new T.MeshStandardMaterial({color,metalness,roughness});a.color.convertSRGBToLinear();a.name=name;return a;};
 m.steel=material('Bunker grey-green steel',0x535f56);m.edge=material('Worn steel edges',0x89918b,.72,.62);m.dark=material('Graphite inset',0x252b2c,.35,.88);m.black=material('Rubber and shadow',0x101714,.05,.98);m.cloth=material('Worn wool blanket',0x555448,0,1);m.pillow=material('Canvas linen',0x7b7b69,0,1);m.rust=material('Restrained corrosion',0x624335,.18,.98);m.green=material('Phosphor indicator',0x74df95,0,.35);m.green.emissive.set(0x74df95);m.green.emissiveIntensity=.6;m.amber=material('Amber indicator',0xc1965c,.12,.5);m.amber.emissive.set(0xb87332);m.amber.emissiveIntensity=.4;
 const mesh=(geo,mat,x=0,y=0,z=0)=>{const o=new T.Mesh(geo,mat);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const B=(x,y,z,w,h,d,mat=m.steel)=>mesh(new T.BoxGeometry(w,h,d),mat,x,y,z);
 const C=(x,y,z,r,h,mat=m.steel,n=12)=>mesh(new T.CylinderGeometry(r,r,h,n),mat,x,y,z);
 const beam=(a,b,r=.025,mat=m.steel)=>{a=new T.Vector3(...a);b=new T.Vector3(...b);const v=b.clone().sub(a),o=mesh(new T.CylinderGeometry(r,r,v.length(),8),mat);o.position.copy(a.add(b).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return o;};
 const plate=(x,y,z,w,h,d,mat=m.steel,c=.045)=>{const s=new T.Shape();const pts=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];s.moveTo(...pts[0]);pts.slice(1).forEach(p=>s.lineTo(...p));s.closePath();return mesh(new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:false}),mat,x,y,z-d/2);};
 const bolt=(x,y,z)=>{const o=C(x,y,z,.015,.015,m.edge,6);o.rotation.x=Math.PI/2;};
 const wear=(x,y,z,w,h)=>{for(let i=0;i<7;i++){const q=i*.137;B(x-w/2+(q%1)*w,y-h/2+((i*.371)%1)*h,z,.012+(i%3)*.018,.007,.003,i%3?m.edge:m.rust);}};
 return {g,m,B,C,beam,plate,bolt,wear};
}

function finish(g,T){g.updateMatrixWorld(true);const bb=new T.Box3(),v=new T.Vector3();g.traverse(o=>{const a=o.isMesh&&o.geometry.attributes.position;if(a)for(let i=0;i<a.count;i++)bb.expandByPoint(v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld));});const c=bb.getCenter(new T.Vector3());g.children.forEach(o=>{o.position.x-=c.x;o.position.z-=c.z;o.position.y-=bb.min.y;});return g;}
export default function generate(T,variant=0){const {g,m,B,C,beam,plate,bolt,wear}=kit(T);g.name='Two occupied emergency bunks';
 for(const x of [-1.17,1.17])for(const z of [-.48,.48]){C(x,1.21,z,.035,2.42,m.steel);B(x,.027,z,.19,.054,.16,m.edge);}
 for(const y of [.44,1.66]){B(0,y,0,2.36,.12,1.03,m.steel);plate(0,y+.15,0,2.27,.20,.95,m.cloth,.065);B(-.75,y+.288,0,.47,.10,.70,m.pillow).rotation.z=-.055;beam([-1.17,y+.54,-.48],[1.17,y+.54,-.48],.026,m.steel);for(const x of [-1.17,1.17])beam([x,y+.20,-.48],[x,y+.20,.48],.028,m.steel);wear(0,y,.516,2.3,.10);}
 for(const x of [.61,1.07])beam([x,.10,.57],[x,2.05,.57],.025,m.edge);for(let y=.27;y<2.02;y+=.25)beam([.61,y,.57],[1.07,y,.57],.022,m.edge);
 // Broad cloth geometry follows the mattress; no texture stripes.
 for(const y of [.44,1.66]){
  const folded=(y>1&&variant===0)||(y<1&&variant===1);
  if(folded){const roll=new T.Mesh(new T.CylinderGeometry(.135,.135,.68,10),m.cloth);roll.rotation.x=Math.PI/2;roll.position.set(.54,y+.385,0);roll.castShadow=roll.receiveShadow=true;g.add(roll);for(const z of [-.27,.27])B(.54,y+.385,z,.23,.025,.034,m.dark);}
  else{
   const p=[],idx=[],xs=[-.48,-.18,.16,.52,.88],zs=[-.42,-.22,0,.23,.43];
   for(let j=0;j<zs.length;j++)for(let i=0;i<xs.length;i++)p.push(xs[i],y+.267+Math.sin(i*2.7+j*.7)*.019,zs[j]);
   for(let j=0;j<4;j++)for(let i=0;i<4;i++){const a=j*5+i;idx.push(a,a+5,a+1,a+1,a+5,a+6);}
   const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(p,3));geo.setIndex(idx);geo.computeVertexNormals();const cloth=m.pillow.clone();cloth.side=T.DoubleSide;cloth.name='fabric';const o=new T.Mesh(geo,cloth);o.castShadow=o.receiveShadow=true;g.add(o);
  }
 }
 // Boots are supported under the lower bed, inside its former footprint.
 for(const x of [-.65,-.39]){plate(x,.075,.05,.18,.13,.31,m.black,.035);plate(x,.20,-.035,.16,.27,.15,m.dark,.025);B(x,.337,-.035,.15,.012,.14,m.black);}
 plate(-1.07,1.30,-.21,.18,.31,.25,m.cloth,.025);beam([-1.10,1.45,-.21],[-1.10,1.66,-.21],.014,m.dark);
 beam([-1.10,.48,-.5],[1.10,1.6,-.5],.015,m.dark);return finish(g,T);}
