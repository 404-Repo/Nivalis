// Atlas-directed shelf silhouettes and supply variants; locally authored geometry.
// Metres, Y-up, front +Z. Real model surfaces; no remote assets.
function kit(T){
 const g=new T.Group(),m={};
 const material=(name,color,metalness=.5,roughness=.8)=>{const a=new T.MeshStandardMaterial({color,metalness,roughness});a.color.convertSRGBToLinear();a.name=name;return a;};
 m.steel=material('Bunker grey-green steel',0x535f56);m.edge=material('Worn steel edges',0x89918b,.72,.62);m.dark=material('Graphite inset',0x252b2c,.35,.88);m.black=material('Rubber and shadow',0x101714,.05,.98);m.cloth=material('Worn wool blanket',0x555448,0,1);m.pillow=material('Canvas linen',0x7b7b69,0,1);m.rust=material('Restrained corrosion',0x624335,.18,.98);m.green=material('Phosphor indicator',0x74df95,0,.35);m.green.emissive.set(0x74df95);m.green.emissiveIntensity=.6;m.amber=material('Amber indicator',0xc1965c,.12,.5);m.amber.emissive.set(0xb87332);m.amber.emissiveIntensity=.4;
 const mesh=(geo,mat,x=0,y=0,z=0)=>{const o=new T.Mesh(geo,mat);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const B=(x,y,z,w,h,d,mat=m.steel)=>mesh(new T.BoxGeometry(w,h,d),mat,x,y,z);
 const C=(x,y,z,r,h,mat=m.steel,n=12)=>mesh(new T.CylinderGeometry(r,r,h,n),mat,x,y,z);
 const beam=(a,b,r=.025,mat=m.steel)=>{a=new T.Vector3(...a);b=new T.Vector3(...b);const v=b.clone().sub(a),o=mesh(new T.CylinderGeometry(r,r,v.length(),8),mat);o.position.copy(a.add(b).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return o;};
 const plate=(x,y,z,w,h,d,mat=m.steel,c=.045)=>{const s=new T.Shape();const pts=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];s.moveTo(...pts[0]);pts.slice(1).forEach(p=>s.lineTo(...p));s.closePath();return mesh(new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:false}),mat,x,y,z-d/2);};
 const bolt=(x,y,z)=>{const o=C(x,y,z,.015,.015,m.edge,6);o.rotation.x=Math.PI/2;};
 const wear=(x,y,z,w,h)=>{for(let i=0;i<7;i++){const q=i*.137;B(x-w/2+(q%1)*w,y-h/2+((i*.371)%1)*h,z,.012+(i%3)*.018,.007,.003,i%3?m.edge:m.rust);}};
 return {g,m,B,C,beam,plate,bolt,wear};
}

function finish(g,T){g.updateMatrixWorld(true);const bb=new T.Box3(),v=new T.Vector3();g.traverse(o=>{const a=o.isMesh&&o.geometry.attributes.position;if(a)for(let i=0;i<a.count;i++)bb.expandByPoint(v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld));});const c=bb.getCenter(new T.Vector3());g.children.forEach(o=>{o.position.x-=c.x;o.position.z-=c.z;o.position.y-=bb.min.y;});return g;}
export default function generate(T,variant=0){const {g,m,B,C,beam,plate,bolt,wear}=kit(T);g.name='Bunker survival stores';
 for(const x of [-1.37,1.37])for(const z of [-.36,.36]){B(x,1.25,z,.075,2.5,.07,m.steel);B(x-.032,1.25,z+.035,.025,2.5,.06,m.edge);B(x,.025,z,.20,.05,.16,m.edge);}
 for(const y of [.16,.91,1.69]){B(0,y,0,2.78,.06,.78,m.steel);B(0,y-.055,.37,2.78,.06,.05,m.edge);}
 beam([-1.32,.2,-.36],[1.32,2.45,-.36],.015,m.dark);beam([1.32,.2,-.36],[-1.32,2.45,-.36],.015,m.dark);
 // Existing frame and three usable levels; supplies vary by role.
 const card=new T.MeshStandardMaterial({color:0x89765d,roughness:.97});card.color.convertSRGBToLinear();card.name='timber';
 const carton=(x,y,w=.54,h=.43)=>{plate(x,y+h/2,0,w,h,.48,card,.025);B(x,y+h/2,.244,.036,h,.009,m.pillow);B(x,y+h+.008,0,w,.016,.07,m.pillow);};
 const water=(x,y)=>{plate(x,y+.265,-.08,.46,.53,.41,m.steel,.065);C(x+.12,y+.555,-.08,.05,.055,m.black,8);B(x-.06,y+.602,-.08,.22,.040,.065,m.dark);for(const side of [-1,1])B(x-.06+side*.092,y+.561,-.08,.035,.072,.065,m.dark);B(x,y+.26,.136,.30,.037,.017,m.edge).rotation.z=.60;B(x,y+.26,.137,.30,.037,.017,m.edge).rotation.z=-.60;};
 const folded=(x,y,z)=>{for(let i=0;i<3;i++){const o=plate(x+(i%2)*.02,y+.035+i*.045,z,.61,.07,.48,m.cloth,.028);o.rotation.z=i===2?.023:0;}B(x,y+.169,z,.05,.018,.50,m.dark);};
 const toolcase=(x,y,w=.72)=>{plate(x,y+.16,0,w,.32,.46,m.dark,.045);for(const dx of [-w*.32,w*.32])B(x+dx,y+.14,.237,.045,.12,.028,m.edge);B(x,y+.34,0,.28,.026,.055,m.steel);};
 function reel(x,y){const o=new T.Group();o.position.set(x,y+.23,0);for(const z of [-.12,.12]){const disc=new T.Mesh(new T.CylinderGeometry(.22,.22,.025,14),m.steel);disc.rotation.x=Math.PI/2;disc.position.z=z;o.add(disc);}const spool=new T.Mesh(new T.CylinderGeometry(.185,.185,.23,14),m.black);spool.rotation.x=Math.PI/2;o.add(spool);const hub=new T.Mesh(new T.CylinderGeometry(.055,.055,.30,8),m.edge);hub.rotation.x=Math.PI/2;o.add(hub);o.traverse(q=>{q.castShadow=q.receiveShadow=true;});g.add(o);beam([x-.23,y+.015,.18],[x+.23,y+.015,.18],.018,m.steel);}
 if(variant===0){water(-.93,.19);water(-.33,.19);reel(.90,.19);carton(-.81,.94,.67,.38);folded(.70,.95,0);toolcase(.62,1.72,.94);}
 if(variant===1){toolcase(-.79,.19);carton(.46,.19,.88,.44);carton(-.91,.94,.55,.48);carton(-.21,.94,.67,.31);folded(.78,1.73,0);}
 if(variant===2){reel(-.80,.19);toolcase(.60,.19,.97);water(-.96,.94);folded(.55,.95,0);toolcase(-.56,1.72,.99);carton(.85,1.72,.43,.35);}
 return finish(g,T);}
