// Cardboard storage derived from the open carton in supply_stack.js.
// Self-contained 404 prop: metres, Y up, front +Z, centred and grounded.
export default function generate(T){
 const g=new T.Group();g.name='Corridor end / stacked cardboard cartons';
 const material=(name,color)=>{const m=new T.MeshStandardMaterial({color,roughness:1});m.color.convertSRGBToLinear();m.name=name;return m;};
 const card=material('Worn khaki cardboard',0x73654a),edge=material('Cardboard folded edges',0x514833),tape=material('Dull paper packing tape',0x96866a),ink=material('Faded carton ink',0x393c2d);
 function box(x,y,z,w,h,d,m){const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;}
 function sealed(x,y,z,w,h,d){box(x,y+h/2,z,w,h,d,card);box(x,y+h+.002,z,.07,.006,d+.003,tape);box(x,y+h*.7,z+d/2+.002,.07,h*.6,.006,tape);for(const side of [-1,1])box(x+side*w*.45,y+h/2,z+d/2+.004,.008,h*.88,.008,edge);for(let i=0;i<3;i++)box(x-w*.30,y+h*.56-i*.033,z+d/2+.007,w*.22,.013,.006,ink);}
 sealed(-.36,0,-.10,.76,.52,.68);sealed(-.38,.523,-.08,.59,.41,.56);
 const x=.42,z=.12,w=.55,d=.61;box(x,.016,z,w,.032,d,edge);
 for(const side of [-1,1]){box(x+side*(w/2-.01),.22,z,.022,.43,d,card);box(x,.22,z+side*(d/2-.01),w,.43,.022,card);const flap=box(x+side*(w/2+.07),.446,z,.17,.013,d-.035,card);flap.rotation.z=-side*.30;}
 box(x,.07,z,.45,.07,.49,card);
 g.updateMatrixWorld(true);const bounds=new T.Box3().setFromObject(g),center=bounds.getCenter(new T.Vector3());for(const child of g.children){child.position.x-=center.x;child.position.z-=center.z;child.position.y-=bounds.min.y;}return g;
}
