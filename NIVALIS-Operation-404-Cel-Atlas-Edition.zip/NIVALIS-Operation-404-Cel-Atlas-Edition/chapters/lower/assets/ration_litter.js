// Extends the cans, cases, muted materials and cables in references/basement-props-reference.png.
// Authored as a self-contained 404-style prop; wear is applied by the engine.
// Metres, Y-up, front +Z. Real model surfaces; no remote assets.
function kit(T){
 const g=new T.Group(),m={};
 const material=(name,color,metalness=.5,roughness=.8)=>{const a=new T.MeshStandardMaterial({color,metalness,roughness});a.color.convertSRGBToLinear();a.name=name;return a;};
 m.steel=material('Bunker grey-green steel',0x535f56);m.edge=material('Worn steel edges',0x89918b,.72,.62);m.dark=material('Graphite inset',0x252b2c,.35,.88);m.black=material('Rubber and shadow',0x101714,.05,.98);m.cloth=material('Worn wool blanket',0x555448,0,1);m.pillow=material('Canvas linen',0x7b7b69,0,1);m.rust=material('Restrained corrosion',0x624335,.18,.98);m.green=material('Phosphor indicator',0x74df95,0,.35);m.green.emissive.set(0x74df95);m.green.emissiveIntensity=.6;m.amber=material('Amber indicator',0xc1965c,.12,.5);m.amber.emissive.set(0xb87332);m.amber.emissiveIntensity=.4;
 const mesh=(geo,mat,x=0,y=0,z=0)=>{const o=new T.Mesh(geo,mat);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;};
 const B=(x,y,z,w,h,d,mat=m.steel)=>mesh(new T.BoxGeometry(w,h,d),mat,x,y,z);
 const C=(x,y,z,r,h,mat=m.steel,n=12)=>mesh(new T.CylinderGeometry(r,r,h,n),mat,x,y,z);
 const beam=(a,b,r=.025,mat=m.steel)=>{a=new T.Vector3(...a);b=new T.Vector3(...b);const v=b.clone().sub(a),o=mesh(new T.CylinderGeometry(r,r,v.length(),8),mat);o.position.copy(a.add(b).multiplyScalar(.5));o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());return o;};
 const plate=(x,y,z,w,h,d,mat=m.steel,c=.045)=>{const s=new T.Shape();const pts=[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]];s.moveTo(...pts[0]);pts.slice(1).forEach(p=>s.lineTo(...p));s.closePath();return mesh(new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:false}),mat,x,y,z-d/2);};
 const bolt=(x,y,z)=>{const o=C(x,y,z,.015,.015,m.edge,6);o.rotation.x=Math.PI/2;};
 const wear=(x,y,z,w,h)=>{for(let i=0;i<7;i++){const q=i*.137;B(x-w/2+(q%1)*w,y-h/2+((i*.371)%1)*h,z,.012+(i%3)*.018,.007,.003,i%3?m.edge:m.rust);}};
 return {g,m,B,C,beam,plate,bolt,wear};
}

function finish(g,T){g.updateMatrixWorld(true);const bb=new T.Box3(),v=new T.Vector3();g.traverse(o=>{const a=o.isMesh&&o.geometry.attributes.position;if(a)for(let i=0;i<a.count;i++)bb.expandByPoint(v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld));});const c=bb.getCenter(new T.Vector3());g.children.forEach(o=>{o.position.x-=c.x;o.position.z-=c.z;o.position.y-=bb.min.y;});return g;}
export default function generate(T,variant=0){const {g,m,B,C,mesh}=kit(T);g.name='Discarded rations and paper';
 const paper=new T.MeshStandardMaterial({color:0x68604d,roughness:1});paper.color.convertSRGBToLinear();
 function tin(x,z,r,h,angle=0){const o=C(x,h/2,z,r,h,m.steel,14);o.rotation.z=angle;const rim=new T.Mesh(new T.TorusGeometry(r,.006,5,16),m.edge);rim.rotation.x=Math.PI/2;rim.position.set(x,h+.004,z);g.add(rim);C(x,h-.006,z,r*.87,.012,m.black,14);}
 tin(-.27,-.12,.095,.13);if(variant!==1)tin(.22,.13,.071,.065);const crushed=C(.12,.057,-.23,.07,.11,m.steel,10);crushed.scale.x=1.30;crushed.scale.z=.63;crushed.rotation.z=.20;
 for(let j=0;j<(variant===2?2:variant===1?4:3);j++){const geo=new T.PlaneGeometry(.23+j*.015,.16,3,2),a=geo.attributes.position;for(let i=0;i<a.count;i++)a.setZ(i,.008+Math.sin(i*1.7+j)*.018);geo.computeVertexNormals();const mat=paper.clone();mat.side=T.DoubleSide;const p=new T.Mesh(geo,mat);p.rotation.x=-Math.PI/2;p.rotation.z=j*.62;p.position.set(-.35+j*.21,.024,.27+(j%2)*.11);p.receiveShadow=true;g.add(p);}
 B(-.1,.02,.03,.23,.025,.17,m.cloth).rotation.y=.45;return finish(g,T);}
