import assert from 'node:assert/strict';
import {createMission,energize,isolate,SOLUTION,circuit,rotate,routingHint,POWER_HINTS} from '../engine/mission.js';
import {advanceShutdown,shutdownState,SHUTDOWN_END} from '../engine/shutdown.js';

// Both prerequisite orders work; neither a note nor a hint is a hidden gate.
for(const cartridgeFirst of [false,true]){
 const m=createMission();if(cartridgeFirst)m.cartridge=true;
 m.breakers=[true,true,true,true];assert(!energize(m).ok);assert(!m.power);
 m.breakers=[true,true,true,false];assert(energize(m).ok);
 if(!cartridgeFirst){assert(!isolate(m).ok);m.cartridge=true;}
 assert(!isolate(m).ok);assert(!m.isolated);assert.deepEqual(advanceShutdown(m,20),[]);
 m.tiles=[...SOLUTION];assert(isolate(m).ok);assert(!m.readNote&&m.powerHint===0&&m.routingHint===0);
 const cues=[];for(let frame=0;frame<600;frame++){
  cues.push(...advanceShutdown(m,1/60));const s=shutdownState(m);
  if(s.elapsed<4.6)assert(!s.patrolsDown);
  if(s.elapsed<6.3)assert(s.quiet&&!s.warden&&!s.alarm);
  if(s.elapsed>=6.3&&s.elapsed<7.6)assert(s.warden&&!s.quiet&&!s.alarm);
 }
 assert.deepEqual(cues,['crash-near','crash-far','warden','alarm']);
 assert(shutdownState(m).complete&&shutdownState(m).patrolsDown&&shutdownState(m).alarm);
 assert.equal(m.shutdownTime,SHUTDOWN_END);assert.deepEqual(advanceShutdown(m,50),[]);
}
const fresh=createMission();assert(!shutdownState(fresh).warden&&!shutdownState(fresh).patrolsDown);
const resetAgain=createMission();assert.deepEqual(resetAgain,fresh);
const jumped=createMission();jumped.isolated=true;assert.deepEqual(advanceShutdown(jumped,20),['crash-near','crash-far','warden','alarm']);

// Guided hints identify a junction but never mutate or auto-complete the board.
let turns=0;while(!circuit(fresh.tiles).valid&&turns<100){
 const before=[...fresh.tiles],hint=routingHint(fresh.tiles);
 assert.deepEqual(fresh.tiles,before);assert(hint.cell>=0&&hint.cell<25);
 fresh.tiles[hint.cell]=rotate(fresh.tiles[hint.cell]);turns++;
}
assert(circuit(fresh.tiles).valid);assert(turns>0&&turns<100);
assert.equal(routingHint(fresh.tiles).cell,-1);assert.equal(POWER_HINTS.length,3);
assert(!fresh.isolated,'Hints must not commit the shutdown');
console.log('PASS: either prerequisite order, recoverable overload, optional non-mutating hints, successful guided route, ordered one-shot shutdown cues and clean reset.');
