import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {CHAPTERS,cleanProgress,cleanSettings,newProgress,advanceProgress} from '../campaign-state.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let p=newProgress();
assert.equal(p.chapter,0);assert.equal(p.complete,false);
assert.throws(()=>advanceProgress(p,1,'SKIP'));
p=advanceProgress(p,0,'GHOST / NO ALERTS');assert.equal(p.chapter,1);assert.equal(p.reports[0],'GHOST / NO ALERTS');
assert.throws(()=>advanceProgress(p,0,'DUPLICATE'));
p=advanceProgress(p,1,'COMMAND CORE OFFLINE');assert.equal(p.chapter,2);assert.equal(p.complete,false);
p=advanceProgress(p,2,'FAILSAFE NEUTRALIZED');assert.equal(p.complete,true);assert.throws(()=>advanceProgress(p,2,'DUPLICATE'));
assert.deepEqual(cleanProgress(JSON.parse(JSON.stringify(p))),p);
for(const invalid of [null,{}, {version:2,chapter:0}, {version:1,chapter:3},{version:1,chapter:-1},{version:1,chapter:'1'}])assert.equal(cleanProgress(invalid),null);
assert.equal(cleanProgress({version:1,chapter:0,complete:true}).complete,false);
assert.equal(cleanSettings({sensitivity:99,music:-4,quality:'ultra',motion:'yes'}).sensitivity,2);
assert.equal(cleanSettings({music:-4}).music,0);assert.equal(cleanSettings({quality:'ultra'}).quality,'balanced');
for(const c of CHAPTERS){
 const source=await readFile(path.join(root,'chapters',c.key,'main.js'),'utf8');
 assert(source.includes('campaign.attach('));assert(source.includes('campaign.disposed'));
 const html=await readFile(path.join(root,'dist/chapters',c.key+'.html'),'utf8');
 assert(html.includes(`data-nivalis-chapter="${c.key}"`));assert(html.includes('html[data-campaign=true] #menu'));
 const map=JSON.parse(html.match(/<script type="importmap">(.*?)<\/script>/s)[1]).imports;
 assert(map['nivalis/engine/campaign-bridge.js']);
 for(const [name,uri] of Object.entries(map)){
  const js=Buffer.from(uri.split(',')[1],'base64').toString();
  for(const m of js.matchAll(/\bfrom\s+["'](nivalis\/[^"']+)["']/g))assert(map[m[1]],`${name}: missing ${m[1]}`);
 }
 const end=Buffer.from(map['nivalis/engine/end-screen.js'].split(',')[1],'base64').toString();assert(end.includes('campaign.complete'));
}
async function syntax(dir){for(const e of await readdir(dir,{withFileTypes:true})){if(['dist','vendor','.git','.openai'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())await syntax(p);else if(/\.(js|mjs)$/.test(e.name))execFileSync(process.execPath,['--check',p],{stdio:'pipe'});}}
await syntax(root);
const portable=await readFile(path.join(root,'PLAY.html'),'utf8');
assert((await readFile(path.join(root,'index.html'),'utf8')).includes('data-chapter-base="./dist/chapters/"'));
assert((await readFile(path.join(root,'dist/index.html'),'utf8')).includes('data-chapter-base="./chapters/"'));
assert(!/<script[^>]*\ssrc=/.test(portable));assert(!/<link[^>]*rel="stylesheet"/.test(portable));assert(portable.includes('window.__CHAPTERS__='));
console.log('PASS: chapter ordering, duplicate completion, checkpoints, corrupt saves, setting bounds, three embedded module graphs, portable assets and source syntax.');
