import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

class Surface extends EventTarget {
  captures=new Set();
  setPointerCapture(id){this.captures.add(id);}
  hasPointerCapture(id){return this.captures.has(id);}
  releasePointerCapture(id){this.captures.delete(id);}
}
function send(target,type,values={}) {
  const event=new Event(type,{cancelable:true});
  Object.assign(event,{pointerId:1,pointerType:'touch',clientX:600,clientY:300},values);
  target.dispatchEvent(event);
  return event;
}
let sharedSource=null;
for(const chapter of ['compound','lower','warden']) {
  const source=await readFile(new URL(`../chapters/${chapter}/engine/touch-look.js`,import.meta.url),'utf8');
  if(sharedSource!==null)assert.equal(source,sharedSource,'Chapter touch controllers must stay consistent');
  sharedSource=source;
  const {createTouchLook}=await import(`../chapters/${chapter}/engine/touch-look.js`);
  const root=new Surface(),scene=new Surface(),pad=new Surface(),moves=[];
  let enabled=true;
  const control=createTouchLook({surfaces:[scene,pad],root,active:()=>enabled,accept:e=>e.clientX>350,look:(x,y)=>moves.push([x,y])});

  // Both initial directions work without a preparatory gesture, at original sensitivity.
  for(const delta of [30,-30,30]) {
    assert(send(pad,'pointerdown').defaultPrevented);
    assert(send(root,'pointermove',{clientX:600+delta}).defaultPrevented);
    assert.deepEqual(moves.at(-1),[delta,0]);
    send(root,'pointerup');assert(!pad.hasPointerCapture(1));
  }
  send(scene,'pointerdown');send(root,'pointermove',{clientX:570});send(root,'pointermove',{clientX:630,clientY:320});
  assert.deepEqual(moves.slice(-2),[[-30,0],[60,20]],'Reversal uses the previous contact position');

  // A joystick/action finger cannot steal or release the look finger.
  send(pad,'pointerdown',{pointerId:2,clientX:800});
  const length=moves.length;
  send(root,'pointermove',{pointerId:2,clientX:810});send(root,'pointerup',{pointerId:2});send(root,'pointercancel',{pointerId:2});
  assert.equal(moves.length,length);
  send(root,'pointermove',{clientX:650,clientY:320});assert.deepEqual(moves.at(-1),[20,0]);

  for(const kind of ['pointercancel','lostpointercapture','blur']) {
    if(kind==='lostpointercapture')send(scene,kind);else send(root,kind);
    const n=moves.length;send(root,'pointermove',{clientX:900});assert.equal(moves.length,n,kind+' must release look');
    send(scene,'pointerdown',{clientX:750});send(root,'pointermove',{clientX:780});assert.deepEqual(moves.at(-1),[30,0]);
  }
  enabled=false;send(root,'pointermove',{clientX:900});const paused=moves.length;
  enabled=true;send(root,'pointermove',{clientX:950});assert.equal(moves.length,paused,'Resume requires a new contact');
  send(scene,'pointerdown',{clientX:400});send(root,'pointermove',{clientX:425});assert.deepEqual(moves.at(-1),[25,0],'Canvas look has no gap near centre');
  control.reset();

  // Native touch gestures are claimed on contact, not only after a leftward move.
  assert(send(pad,'touchstart',{changedTouches:[{clientX:600}]}).defaultPrevented);
  assert(send(pad,'touchmove',{changedTouches:[{clientX:650}]}).defaultPrevented);
  assert(!send(scene,'touchstart',{changedTouches:[{clientX:100}]}).defaultPrevented);
  enabled=false;assert(!send(pad,'touchstart',{changedTouches:[{clientX:600}]}).defaultPrevented);enabled=true;
  assert(!send(scene,'pointerdown',{pointerType:'mouse'}).defaultPrevented,'Desktop mouse input stays separate');
  send(scene,'pointerdown');control.dispose();const disposed=moves.length;
  send(root,'pointermove',{clientX:900});send(pad,'pointerdown');assert.equal(moves.length,disposed);assert(!scene.hasPointerCapture(1));
  console.log(`PASS: ${chapter}: fresh right/left gestures, reversal, multi-touch ownership, cancel/capture loss, pause, native gesture blocking and disposal.`);
}

// Touch-generated mouse compatibility events must never enter trackpad look.
const oldWindow=globalThis.window,oldDocument=globalThis.document;
try {
  for(const chapter of ['compound','lower','warden']) {
    const moves=[];
    globalThis.window={name:'nivalis-campaign',parent:{__NIVALIS_CAMPAIGN__:{canLook:()=>true}}};
    globalThis.document={addEventListener(){},querySelector:()=>null,getElementById:()=>null,createElement:()=>({addEventListener(){}})};
    const {campaign}=await import(`../chapters/${chapter}/engine/campaign-bridge.js`);
    campaign.attach({look:(x,y)=>moves.push([x,y])});
    const event={target:{matches:()=>true},clientX:500,clientY:300};
    campaign.look(event);campaign.look({...event,clientX:550,sourceCapabilities:{firesTouchEvents:true}});
    assert.equal(moves.length,0,'Synthetic touch mouse movement must be ignored');
    campaign.look({...event,clientX:530});assert.deepEqual(moves,[[30,0]],'Real trackpad movement must still work');
  }
} finally {globalThis.window=oldWindow;globalThis.document=oldDocument;}
console.log('PASS: touch-generated mouse events are ignored while campaign trackpad look remains responsive.');
