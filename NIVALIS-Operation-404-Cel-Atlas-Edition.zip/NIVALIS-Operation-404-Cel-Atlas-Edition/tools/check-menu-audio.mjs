import assert from 'node:assert/strict';
import {CassetteDrone} from '../title-audio.js';
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
function voice(resume){const v=Object.create(CassetteDrone.prototype);v.generation=0;v.playbackRequested=false;v.gains=[];v.setVolume=n=>v.gains.push(n);v.ctx={state:'suspended',resume,suspend:async()=>{v.ctx.state='suspended';}};return v;}
// A browser may unblock an earlier autoplay request after START or mute.
const blocked=deferred(),late=voice(()=>blocked.promise);
const attempting=late.resume(40),stopping=late.pause();
late.ctx.state='running';blocked.resolve();await attempting;
assert.equal(late.ctx.state,'suspended');assert.deepEqual(late.gains,[0]);await stopping;
// A rapid return to pause must invalidate the old delayed suspension.
const rapid=voice(async()=>{rapid.ctx.state='running';});
await rapid.resume(40);const pendingPause=rapid.pause();await rapid.resume(20);await pendingPause;
assert.equal(rapid.ctx.state,'running');assert.equal(rapid.gains.at(-1),20);
// Multiple pending autoplay retries may resolve out of order: newest level wins.
const a=deferred(),b=deferred();let n=0;const ordered=voice(()=>++n===1?a.promise:b.promise);
const old=ordered.resume(40),latest=ordered.resume(12);ordered.ctx.state='running';b.resolve();await latest;a.resolve();await old;
assert.deepEqual(ordered.gains,[12]);
console.log('PASS: late autoplay cannot leak into gameplay or mute; rapid pause/resume and pending volume changes remain ordered.');
