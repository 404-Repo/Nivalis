// Acceptance checks for the Atlas-directed art pass against the prior Cel Edition.
// No browser, network, gameplay shortcuts or baseline updates are required.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
process.chdir(root);
const fixture=name=>JSON.parse(fs.readFileSync(path.join(root,'tools/fixtures',name),'utf8'));
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const protectedSources=fixture('art-protected-source.json');
for(const [file,expected] of Object.entries(protectedSources))assert.equal(hash(file),expected,`Gameplay or protected presentation changed: ${file}`);
console.log(`PASS: ${Object.keys(protectedSources).length} protected gameplay, input, audio, UI and renderer files unchanged.`);

const {applyHeroFinish}=await import('../chapters/warden/engine/hero-finish.js');
const sentinel={};
assert.equal(applyHeroFinish(sentinel,'rifle'),sentinel,'The carbine must retain the shared clean finish in Warden');

const {results}=await import('./inspect-art-placements.mjs');
const baseline=fixture('art-baseline-placements.json');
const placement=p=>({asset:p.asset,position:p.position,scale:p.scale});
for(const chapter of ['compound','lower','warden']){
  const now=results[chapter],before=baseline[chapter];
  assert.deepEqual(now.placements.map(placement),before.placements.map(placement),`${chapter}: prop positions or scales changed`);
  for(const key of ['counts','colliders','surfaces','ramps','items'])if(before[key])assert.deepEqual(now[key],before[key],`${chapter}: ${key} changed`);
  console.log(`PASS: ${chapter}: ${now.placements.length} fixed placements, ${now.colliders.length} unchanged colliders and traversal/objective data.`);
}
const key=p=>JSON.stringify(placement(p));
const compound=new Map(results.compound.placements.map(p=>[key(p),p.variant]));
for(const p of results.warden.placements)if(compound.has(key(p)))assert.equal(p.variant,compound.get(key(p)),`Return-trip variant drift: ${p.asset}`);
for(const file of fs.readdirSync('chapters/compound/assets'))assert.equal(hash('chapters/compound/assets/'+file),hash('chapters/warden/assets/'+file),`Shared model drift: ${file}`);
for(const [chapter,asset,count] of [['compound','boulder',3],['compound','barricade',3],['compound','cargo_module',3],['lower','crew_bunk',2],['lower','supply_stack',3]]){
  const variants=new Set(results[chapter].placements.filter(p=>p.asset===asset).map(p=>p.variant));
  assert.equal(variants.size,count,`${chapter}: ${asset} variants not all placed`);
}
for(const chapter of ['lower','warden'])assert.equal(hash('chapters/compound/engine/cel-art-finish.js'),hash('chapters/'+chapter+'/engine/cel-art-finish.js'),'Shared cel finish drift');
console.log('PASS: return-trip models and cosmetic variants match; selected variations are present in the levels.');

const {applyCelArtFinish}=await import('../chapters/compound/engine/cel-art-finish.js');
const T=globalThis.THREE,inventory=fixture('art-baseline-inventory.json').records;
const variants={boulder:3,barricade:3,supply_crate:3,cargo_module:3,cryo_tank:3,crew_bunk:2,supply_stack:3,ration_litter:3,survival_shelf:3};
let checked=0;
for(const chapter of ['compound','lower','warden'])for(const file of fs.readdirSync(`chapters/${chapter}/assets`).filter(f=>f.endsWith('.js'))){
  const asset=file.slice(0,-3),before=inventory.find(r=>r.chapter===chapter&&r.asset===asset&&r.variant===0);
  const generate=(await import(pathToFileURL(path.join(root,'chapters',chapter,'assets',file)))).default;
  for(let variant=0;variant<(variants[asset]||1);variant++){
    const g=generate(T,variant);assert(g.isGroup);g.updateMatrixWorld(true);
    const box=new T.Box3(),v=new T.Vector3();let triangles=0;
    g.traverse(o=>{if(!o.isMesh)return;const a=o.geometry.attributes.position;triangles+=(o.geometry.index?.count||a.count)/3;
      for(let i=0;i<a.count;i++){v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld);assert(v.toArray().every(Number.isFinite),`${asset}: invalid vertex`);box.expandByPoint(v);}
    });
    assert(Math.abs(box.min.y)<.002,`${asset}: floating base`);
    const centre=box.getCenter(new T.Vector3());assert(Math.abs(centre.x)<.002&&Math.abs(centre.z)<.002,`${asset}: off-centre`);
    const dimensions=box.getSize(new T.Vector3()).toArray();
    for(let i=0;i<3;i++){
      if(asset==='ration_litter'||asset==='rifle')assert(dimensions[i]<=before.dimensions[i]+.002,`${asset}: enlarged envelope`);
      else assert(Math.abs(dimensions[i]-before.dimensions[i])<.001,`${asset}: changed scenery envelope`);
    }
    assert(triangles<Math.max(before.triangles*2,4000),`${asset}: unexpected geometry growth`);
    // The accepted snow bevels may contract a cap's rotated bounds, but never
    // expand the authored scenery envelope or change its support plane.
    applyCelArtFinish(g,asset,variant);g.updateMatrixWorld(true);
    const finished=new T.Box3();g.traverse(o=>{if(!o.isMesh)return;const a=o.geometry.attributes.position;for(let i=0;i<a.count;i++)finished.expandByPoint(v.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld));});
    for(const axis of ['x','y','z'])assert(finished.min[axis]>=box.min[axis]-.002&&finished.max[axis]<=box.max[axis]+.002,`${asset}: finish exceeds scenery bounds`);
    g.traverse(o=>{if(!o.isMesh)return;for(const name of ['position','normal'])assert(Array.from(o.geometry.attributes[name].array).every(Number.isFinite),`${asset}: invalid finished ${name}`);});
    if(asset==='ration_bar')assert(g.getObjectByName('wrapper-print'),'Missing live Chocobar print anchor');
    checked++;
  }
}
console.log(`PASS: ${checked} asset variants have finite, centred, grounded geometry and retained scenery bounds.`);
