import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {pathToFileURL} from 'node:url';
const root=path.resolve(process.argv[2]||'.');vm.runInThisContext(fs.readFileSync(path.join(root,'chapters/compound/vendor/three.min.js'),'utf8'));const T=globalThis.THREE;
const context=new Proxy({measureText:s=>({width:s.length*9}),createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),getImageData:(x,y,w,h)=>({data:new Uint8ClampedArray(w*h*4)}),createRadialGradient:()=>({addColorStop(){}}),createLinearGradient:()=>({addColorStop(){}})},{get:(t,k)=>k in t?t[k]:()=>{},set:(t,k,v)=>(t[k]=v,true)});
globalThis.document={createElement:()=>({getContext:()=>context})};globalThis.window={};
const makeSign=(_text,{width=1,height=1}={})=>new T.Mesh(new T.PlaneGeometry(width,height),new T.MeshBasicMaterial({map:new T.Texture()}));
const emptyMesh=()=>new T.Mesh(new T.PlaneGeometry(.1,.1),new T.MeshBasicMaterial());
const bakeStatic=g=>g;
const results={method:'Execute unmodified placement bodies with original generators; identity baking preserves tags. Canvas drawing/light updates are stubbed. Counts exclude gameplay-spawned enemies, cameras, and custom geometry, which are separately catalogued.'};
for(const chapter of ['compound','warden']){
 const ASSET=async(name,{variant=0}={})=>{const g=(await import(pathToFileURL(path.join(root,'chapters',chapter,'assets',name+'.js')))).default(T,variant);g.userData.audit={asset:name,variant};return g;};
 async function moduleBody(file,args,names){const src=fs.readFileSync(path.join(root,'chapters',chapter,'engine',file),'utf8').replace(/^import .*;\s*$/gm,'').replace(/export /g,'');return await new Function(...Object.keys(args),src+';return '+names+';')(...Object.values(args));}
 const {drawCelUplink}=await import(pathToFileURL(path.join(root,'chapters',chapter,'engine/uplink-display.js')));
 const scene=new T.Scene(),build=await moduleBody('level.js',{THREE:T,ASSET,bakeStatic,makeSign,drawCelUplink},'buildLevel'),level=await build(scene,()=>{},{wardenEncounter:chapter==='warden'});
 const human=await moduleBody('human_traces.js',{THREE:T,ASSET,bakeStatic,makeSign,campaign:{},makeSprayDust:emptyMesh,makeHandpaintedEye:()=>new T.Texture(),makeInteriorDecal:emptyMesh},'buildHumanTraces');await human(scene,level);
 scene.updateMatrixWorld(true);const placements=[];scene.traverse(o=>{if(o.userData.audit)placements.push({...o.userData.audit,position:o.getWorldPosition(new T.Vector3()).toArray(),scale:o.getWorldScale(new T.Vector3()).toArray()});});
 results[chapter]={placements,counts:placements.reduce((a,p)=>(a[p.asset]=(a[p.asset]||0)+1,a),{}),colliders:level.colliders,surfaces:level.surfaces,ramps:level.ramps};
}
const funcs={};for(const [alias,name]of Object.entries({litterAsset:'ration_litter',stockAsset:'supply_stack',cartonsAsset:'cardboard_cartons',sparesAsset:'maintenance_spares',consoleAsset:'bunker_console',breakerAsset:'breaker_cabinet',shelfAsset:'survival_shelf',bunkAsset:'crew_bunk',cartridgeAsset:'service_cartridge'})){
 const fn=(await import(pathToFileURL(path.join(root,'chapters/lower/assets',name+'.js')))).default;funcs[alias]=(T,v=0)=>{const g=fn(T,v);g.userData.audit={asset:name,variant:v};return g;};
}
const src=fs.readFileSync(path.join(root,'chapters/lower/engine/basement.js'),'utf8').replace(/^import .*;\s*$/gm,'').replace('export function','function');
const {makeCelSign}=await import(pathToFileURL(path.join(root,'chapters/lower/engine/signage.js')));
const {paintBunkerSurfaces,enhancePropReadability}=await import(pathToFileURL(path.join(root,'chapters/lower/engine/cel-art-finish.js')));
const args={THREE:T,makeCelSign,paintBunkerSurfaces,enhancePropReadability,...funcs,bakeStatic,applySurfacePilot:()=>{},makeServiceLift:()=>({shell:new T.Group(),shaft:new T.Group(),unlock(){}}),lampLevel:()=>1,nearbyBallast:()=>1,emergencyPulse:()=>1,shutdownState:()=>({})};
const create=new Function(...Object.keys(args),src+';return createBasement;')(...Object.values(args)),scene=new T.Scene(),level=create(scene);scene.updateMatrixWorld(true);const placements=[];
scene.traverse(o=>{if(o.userData.audit)placements.push({...o.userData.audit,position:o.getWorldPosition(new T.Vector3()).toArray(),scale:o.getWorldScale(new T.Vector3()).toArray()});});
results.lower={placements,counts:placements.reduce((a,p)=>(a[p.asset]=(a[p.asset]||0)+1,a),{}),colliders:level.colliders,items:level.items};
if(process.argv[3])fs.writeFileSync(process.argv[3],JSON.stringify(results,null,2));
export {results};
