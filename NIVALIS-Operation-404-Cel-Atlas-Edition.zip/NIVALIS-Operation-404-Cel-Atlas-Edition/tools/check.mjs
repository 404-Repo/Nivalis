// Run the supported release checks without a package installation.
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const run=(command,args)=>execFileSync(command,args,{cwd:root,stdio:'inherit'});
for(const file of ['tools/check-campaign.mjs','tools/check-menu-audio.mjs','tools/check-touch-look.mjs','tools/check-art.mjs','chapters/lower/tools/check.mjs'])run(process.execPath,[file]);
run('python3',['tools/test_privacy.py']);
run('python3',['tools/check_privacy.py']);
console.log('PASS: complete release checks.');
