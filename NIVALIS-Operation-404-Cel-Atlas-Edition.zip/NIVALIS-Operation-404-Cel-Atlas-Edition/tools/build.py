#!/usr/bin/env python3
"""Build the uploadable static site and the completely embedded PLAY.html."""
from pathlib import Path
import base64, json, re, shutil, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist'
DIST.mkdir(exist_ok=True)
(DIST/'chapters').mkdir(exist_ok=True)
chapters={}
for key in ['compound','lower','warden']:
    output=DIST/'chapters'/f'{key}.html'
    subprocess.run([sys.executable,str(ROOT/'tools/bundle.py'),str(ROOT/'chapters'/key),str(output)],check=True)
    chapters[key]=base64.b64encode(output.read_bytes()).decode()
for name in ['index.html','style.css','campaign.js','campaign-state.js','title-audio.js','assets']:
    source=ROOT/name;dest=DIST/name
    if source.is_dir(): shutil.copytree(source,dest,dirs_exist_ok=True)
    elif name=='index.html': dest.write_text(source.read_text().replace('data-chapter-base="./dist/chapters/"','data-chapter-base="./chapters/"'))
    else: shutil.copy2(source,dest)
# Include attribution in the standalone web upload as well as the source archive.
shutil.copytree(ROOT/'licenses',DIST/'licenses',dirs_exist_ok=True)
shutil.copy2(ROOT/'THIRD_PARTY_NOTICES.txt',DIST/'THIRD_PARTY_NOTICES.txt')
(DIST/'.nojekyll').write_text('')
# Preserve the legacy /game/ entrypoint while the campaign itself lives at root.
(DIST/'game').mkdir(exist_ok=True)
(DIST/'game/index.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>NIVALIS: OPERATION 404</title><meta http-equiv="refresh" content="0;url=../"><a href="../">PLAY NIVALIS: OPERATION 404</a></html>')
html=(ROOT/'index.html').read_text()
css=(ROOT/'style.css').read_text()
def embed_font(match):
    asset=ROOT/match[1]
    return "url('data:font/ttf;base64,"+base64.b64encode(asset.read_bytes()).decode()+"')"
css=re.sub(r"url\('([^']+)'\)",embed_font,css)
html=html.replace('<link rel="stylesheet" href="./style.css">','<style>'+css+'</style>')
state='data:text/javascript;base64,'+base64.b64encode((ROOT/'campaign-state.js').read_bytes()).decode()
js=(ROOT/'campaign.js').read_text().replace("'./campaign-state.js'",json.dumps(state))
title_audio='data:text/javascript;base64,'+base64.b64encode((ROOT/'title-audio.js').read_bytes()).decode()
js=js.replace("'./title-audio.js'",json.dumps(title_audio))
js=re.sub(r'</script',r'<\/script',js,flags=re.I)
bootstrap='<script>window.__CHAPTERS__='+json.dumps(chapters,separators=(',',':'))+';</script>\n<script type="module">'+js+'</script>'
html=re.sub(r'<script type="module" src="\./campaign\.js(?:\?[^"]*)?"></script>',lambda _:bootstrap,html)
(ROOT/'PLAY.html').write_text(html)
print(f'Campaign build: dist/ and PLAY.html ({len(html):,} bytes).')

# Do not accept a build that exposes local metadata or credentials.
subprocess.run([sys.executable,str(ROOT/'tools/check_privacy.py')],check=True)
